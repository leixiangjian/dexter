package com.cornu.report.service;

import java.text.SimpleDateFormat;
import java.util.*;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.security.authentication.encoding.MessageDigestPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSONObject;
import com.cornu.report.dao.bean.AgentAccountInfoEntity;
import com.cornu.report.dao.bean.AgentEntity;
import com.cornu.report.dao.bean.AppDayBookEntity;
import com.cornu.report.dao.bean.AppEntity;
import com.cornu.report.dao.bean.CashEntity;
import com.cornu.report.dao.bean.ChannelEntity;
import com.cornu.report.dao.bean.DayBookEntity;
import com.cornu.report.dao.bean.DevEntity;
import com.cornu.report.dao.bean.GlobalDayBookEntity;
import com.cornu.report.dao.bean.LogEntity;
import com.cornu.report.dao.bean.RebateEntity;
import com.cornu.report.dao.bean.TransactionEntity;
import com.cornu.report.dao.bean.WhiteEntity;
import com.cornu.report.dao.mapper.ApiMapper;
import com.cornu.report.dao.mapper.MigrateMapper;
import com.cornu.report.utils.DateUtil;

import static org.springframework.data.mongodb.core.query.Criteria.where;

@Service("migrateDataService")
public class MigrateDataService {
	private static final Logger LOG = LoggerFactory.getLogger(MigrateDataService.class);
	@Autowired
	MongoTemplate mongoTemplate;

	@Autowired(required = true)
	@Qualifier(value = "migrateMapper")
	MigrateMapper migrateMapper;
	
	@Autowired(required = true)
	@Qualifier(value = "apiMapper")
	ApiMapper apiMapper;

	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public void migrateAgent() throws Exception {
		List<AgentEntity> agentEntitys =  mongoTemplate.findAll(AgentEntity.class, "agent");
		List<AgentAccountInfoEntity> agentAccountInfoEntitys =  mongoTemplate.findAll(AgentAccountInfoEntity.class, "agent_account_info");
		MessageDigestPasswordEncoder messageDigestPasswordEncoder = new MessageDigestPasswordEncoder("MD5");
		
		for (AgentEntity agentEntity : agentEntitys) {
			Map<String, Object> agentMap = new HashMap<String, Object>();
			String aid = agentEntity.getAid();
			agentMap.put("aid", aid);

			String acode = agentEntity.getAcode();
			agentMap.put("acode", acode);

			String bankName = agentEntity.getBankname();
			agentMap.put("bankName", bankName);

			String cardno = agentEntity.getCardno();
			agentMap.put("cardno", cardno);

			String channelcd = agentEntity.getChannelcd();
			if(StringUtils.isNotBlank(channelcd) && channelcd.equals("null")){
				channelcd = null;
			}
			agentMap.put("channelcd", channelcd);

			long ctime = agentEntity.getCtime();
			agentMap.put("ctime", ctime);

			Date agent_crtdate = new Date(ctime * 1000);
			agentMap.put("agent_crtdate", agent_crtdate);

			String from = agentEntity.getFrom();
			agentMap.put("from", from);

			String ip = agentEntity.getIp();
			agentMap.put("ip", ip);

			String level = agentEntity.getLevel();
			agentMap.put("level", level);

			long mtime = agentEntity.getMtime();
			agentMap.put("mtime", mtime);

			Date agent_moddate = new Date(mtime * 1000);
			agentMap.put("agent_moddate", agent_moddate);

			String phone = agentEntity.getPhone();
			agentMap.put("phone", phone);
			
			String username = agentEntity.getUsername();
			agentMap.put("username", username);

			String passwd = agentEntity.getPasswd();
			boolean isFind = false;
			String salt = null;
            for(AgentAccountInfoEntity agentAccountInfoEntity:agentAccountInfoEntitys){
            	String agentPasswd = agentAccountInfoEntity.getPasswd();
            	String agentPhone = agentAccountInfoEntity.getPhone();
            	if(agentPhone.equals(phone)){
            		salt = getSalt();
            		passwd = messageDigestPasswordEncoder.encodePassword(agentPasswd, salt);
            		isFind = true;
            		break;
            	}
            }
            if(!isFind){
            	LOG.info("没有破解密码的phone:{}",phone);
            }

			agentMap.put("passwd", passwd);

			
			String status = agentEntity.getStatus();
			agentMap.put("status", status);

			String ticount = agentEntity.getTicount();
			agentMap.put("ticount", ticount);

			String tincome = agentEntity.getTincome();
			agentMap.put("tincome", tincome);

			String tocount = agentEntity.getTocount();
			agentMap.put("tocount", tocount);

			String ttake = agentEntity.getTtake();
			agentMap.put("ttake", ttake);
			
			agentMap.put("salt", salt);
			
			
			String isValid = agentEntity.getIsValid();
			agentMap.put("isValid", isValid);
			
			long validTime = agentEntity.getValidTime();
			agentMap.put("validTime", validTime);

			Date agent_validdate = new Date(validTime * 1000);
			agentMap.put("agent_validdate", agent_validdate);

			String roletype = agentEntity.getRoletype();
			agentMap.put("roletype", roletype);

			String p_channelcd = agentEntity.getP_channelcd();
			agentMap.put("p_channelcd", p_channelcd);

			String channel_total_income = agentEntity.getChannel_total_income();
			agentMap.put("channel_total_income", channel_total_income);

			String channel_income_count = agentEntity.getChannel_income_count();
			agentMap.put("channel_income_count", channel_income_count);

			String headman_total_income = agentEntity.getHeadman_total_income();
			agentMap.put("headman_total_income", headman_total_income);

			String headman_income_count = agentEntity.getHeadman_income_count();
			agentMap.put("headman_income_count", headman_income_count);

			String validagent_total_income = agentEntity.getValidagent_total_income();
			agentMap.put("validagent_total_income", validagent_total_income);

			String validagent_income_count = agentEntity.getValidagent_income_count();
			agentMap.put("validagent_income_count", validagent_income_count);

			String validreguser_total_income = agentEntity.getValidreguser_total_income();
			agentMap.put("validreguser_total_income", validreguser_total_income);

			String validreguser_income_count = agentEntity.getValidreguser_income_count();
			agentMap.put("validreguser_income_count", validreguser_income_count);

			String last_withdraw_balance = agentEntity.getLast_withdraw_balance();
			agentMap.put("last_withdraw_balance", last_withdraw_balance);

			Long last_withdraw_time = agentEntity.getLast_withdraw_time();
			agentMap.put("last_withdraw_time", last_withdraw_time);

			Date agent_lastwithdrawdate = new Date(last_withdraw_time * 1000);
			agentMap.put("agent_lastwithdrawdate", agent_lastwithdrawdate);

			String branchbankname = agentEntity.getBranchbankname();
			agentMap.put("branchbankname", branchbankname);
			
			String tincome_new = agentEntity.getTincome_new();
			agentMap.put("tincome_new", tincome_new);
			
			String channel_total_income_new = agentEntity.getChannel_total_income_new();
			agentMap.put("channel_total_income_new", channel_total_income_new);
			
			String headman_total_income_new = agentEntity.getHeadman_total_income_new();
			agentMap.put("headman_total_income_new", headman_total_income_new);
			
			String ttake_new = agentEntity.getTtake_new();
			agentMap.put("ttake_new", ttake_new);

			try {
				migrateMapper.addAgent(agentMap);
			} catch(DuplicateKeyException e){
				migrateMapper.updateAgent(agentMap);
			}
			
			try {
				migrateMapper.addSysUser(agentMap);
			} catch(DuplicateKeyException e){
				migrateMapper.updateSysUser(agentMap);
			}
		}

		LOG.info("迁移完成:migrateAgentData");
	}

	public void migrateApp() throws Exception {
		List<AppEntity> appEntitys =  mongoTemplate.findAll(AppEntity.class, "app");
		for (AppEntity appEntity : appEntitys) {
			Map<String, Object> appMap = new HashMap<String, Object>();
			String appid = appEntity.getAppid();
			appMap.put("appid", appid);
			
			String did = appEntity.getDid();
			appMap.put("did", did);
			
			String applogo = appEntity.getApplogo();
			appMap.put("applogo", applogo);
			
			String appname = appEntity.getAppname();
			appMap.put("appname", appname);
			
			long apptime = appEntity.getApptime();
			appMap.put("apptime", apptime);
			
			long ctime = appEntity.getCtime();
			appMap.put("ctime", ctime);
			
			String desc = appEntity.getDesc();
			appMap.put("desc", desc);
			
			String dlink = appEntity.getDlink();
			appMap.put("dlink", dlink);
			
			long ftrade = appEntity.getFtrade();
			appMap.put("ftrade", ftrade);
			
			String ip = appEntity.getIp();
			appMap.put("ip", ip);
			
			String language = appEntity.getLanguage();
			appMap.put("language", language);
			
			int level = appEntity.getLevel();
			appMap.put("level",  level);
			
			long mtime = appEntity.getMtime();
			appMap.put("mtime",  mtime);
			
			double proportion = appEntity.getProportion();
			appMap.put("proportion",  proportion);
			
			double rate = appEntity.getRate();
			appMap.put("rate",  rate);
			
			double rltimeret = appEntity.getRltimeret();
			appMap.put("rltimeret",  (long)rltimeret);
			
			String size = appEntity.getSize();
			appMap.put("appsize", size);
			
			double status = appEntity.getStatus();
			appMap.put("status",Long.toString((long)status));
			
			String system = appEntity.getSystem();
			appMap.put("appsystem", system);
			
			String version = appEntity.getVersion();
			appMap.put("appversion", version);
			
			long pic_type = appEntity.getPic_type();
			appMap.put("pic_type", (long)pic_type);
			
			String backgroud = appEntity.getBackgroud();
			appMap.put("backgroud", backgroud);
			
			String spread = appEntity.getSpread();
			appMap.put("spread", spread);
			
			long t_agent_income = appEntity.getT_agent_income();
			appMap.put("t_agent_income",t_agent_income);
			
			long t_cornu_income = appEntity.getT_cornu_income();
			appMap.put("t_cornu_income", t_cornu_income);
			
			long t_cornu_recieve = appEntity.getT_cornu_recieve();
			appMap.put("t_cornu_recieve", t_cornu_recieve);
			
			long t_total_income = appEntity.getT_total_income();
			appMap.put("t_total_income",t_total_income);
			
			long ticount = appEntity.getTicount();
			appMap.put("ticount", ticount);
			
			long trcount = appEntity.getTrcount();
			appMap.put("trcount",trcount);
			try {
				migrateMapper.addApp(appMap);
			} catch(DuplicateKeyException e){
				migrateMapper.updateApp(appMap);
			}catch (Exception e) {
				LOG.error("迁移代理人数据异常", e);
			}
		}
		
		LOG.info("迁移完成:migrateApp");
	}

	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public void migrateAppDayBook() throws Exception {
		List<AppDayBookEntity> appDayBookEntitys = mongoTemplate.findAll(AppDayBookEntity.class, "app_day_book");
		
		migrateMapper.deleteAppDayBook(null);
		
		for(AppDayBookEntity appDayBookEntity : appDayBookEntitys){
			Map<String,Object> map =new HashMap<String,Object>();
			String appid = appDayBookEntity.getAppid();
			map.put("appid", appid);
			
			long ctime = appDayBookEntity.getCtime();
			map.put("ctime", ctime);
			
			String day = appDayBookEntity.getDay();
			map.put("day", day);
			
			long dayForAgent = appDayBookEntity.getDay_for_agent();
			map.put("day_for_agent", dayForAgent);
			
			long dayForSelf = appDayBookEntity.getDay_for_self();
			map.put("day_for_self", dayForSelf);
			
			long dayRebateMoney = appDayBookEntity.getDay_rebate_money();
			map.put("day_rebate_money", dayRebateMoney);
			
			long dayRechargeMoney = appDayBookEntity.getDay_recharge_money();
			map.put("day_recharge_money", dayRechargeMoney);
			
			long dayTotalCount = appDayBookEntity.getDay_total_count();
			map.put("day_total_count", dayTotalCount);
			
			long mtime = appDayBookEntity.getMtime();
			map.put("mtime", mtime);
			
			try{
				migrateMapper.addAppDayBook(map);
			}catch(Exception e){
				LOG.error("迁移AppDayBook数据异常",e);
			}
		}
		
		LOG.info("迁移完成:migrateAppDayBook");
	}

	public void migrateCash() throws Exception {
		List<CashEntity> cashEntitys = mongoTemplate.findAll(CashEntity.class, "cash");
		
		for(CashEntity cashEntity : cashEntitys){
			Map<String,Object> map =new HashMap<String,Object>();
			String aid = cashEntity.getAid();
			map.put("aid", aid);
			
			long amount = cashEntity.getAmount();
			map.put("amount", amount);
			
			String cid = cashEntity.getCid();
			map.put("cid", cid);
			
			long ctime = cashEntity.getCtime();
			map.put("ctime", ctime);
			
			long mtime = cashEntity.getMtime();
			map.put("mtime", mtime);
			
			double status = cashEntity.getStatus();
			map.put("status", (long)status);
			
			String extra = cashEntity.getExtra();
			map.put("extra", extra);
			
			Date cDate = new Date(ctime * 1000);
			map.put("cDate", cDate);
			
			Date mDate = new Date(mtime * 1000);
			map.put("mDate", mDate);
			
			Long final_amount = cashEntity.getFinal_amount();
			map.put("final_amount",final_amount);
			
			Long current_amount = cashEntity.getCurrent_amount();
			map.put("current_amount",current_amount);
			
			try {
				migrateMapper.addCash(map);
			} catch(DuplicateKeyException e){
				migrateMapper.updateCash(map);
			}catch (Exception e) {
				LOG.error("迁移cash数据异常", e);
			}
		}
		
		
		LOG.info("迁移完成:migrateCash");
	}

	public void migrateChannel() throws Exception {
		List<ChannelEntity> channelEntitys = mongoTemplate.findAll(ChannelEntity.class, "channel_info");
		
		for(ChannelEntity channelEntity : channelEntitys){
			Map<String,Object> map =new HashMap<String,Object>();
			String channelcd = channelEntity.getChannelcd();
			map.put("channelcd", channelcd);
			
			String channelname = channelEntity.getChannelname();
			map.put("channelname", channelname);
			
			try {
				migrateMapper.addChannel(map);
			} catch(DuplicateKeyException e){
				migrateMapper.updateChannel(map);
			}catch (Exception e) {
				LOG.error("迁移channel数据异常", e);
			}
		}
		
		LOG.info("迁移完成:migrateChannel");
	}

	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public void migrateDayBook() throws Exception {
        List<DayBookEntity> dayBookEntitys = mongoTemplate.findAll(DayBookEntity.class, "day_book");
		
		migrateMapper.deleteDayBook(null);
		for(DayBookEntity dayBookEntity : dayBookEntitys){
			Map<String,Object> map =new HashMap<String,Object>();
			String aid = dayBookEntity.getAid();
			map.put("aid", aid);
			
			String appid = dayBookEntity.getAppid();
			map.put("appid", appid);
			
			long ctime = dayBookEntity.getCtime();
			map.put("ctime", ctime);
			
			String day = dayBookEntity.getDay();
			map.put("day", day);
			
			long day_for_agent = dayBookEntity.getDay_for_agent();
			map.put("day_for_agent",day_for_agent);
			
			long day_for_self = dayBookEntity.getDay_for_self();
			map.put("day_for_self", day_for_self);
			
			long day_rebate_money = dayBookEntity.getDay_rebate_money();
			map.put("day_rebate_money", day_rebate_money);
			
			long day_recharge_money = dayBookEntity.getDay_recharge_money();
			map.put("day_recharge_money", day_recharge_money);
			
			long day_total_count = dayBookEntity.getDay_total_count();
			map.put("day_total_count", day_total_count);
			
			long mtime = dayBookEntity.getMtime();
			map.put("mtime", mtime);
			
			try{
				migrateMapper.addDayBook(map);
			}catch(Exception e){
				LOG.error("迁移DayBook数据异常",e);
			}
		}
		LOG.info("迁移完成:migrateDayBook");
	}

	public void migrateDev() throws Exception {
		List<DevEntity> devEntitys  = mongoTemplate.findAll(DevEntity.class, "dev");
		
		for(DevEntity devEntity:devEntitys){
			Map<String,Object> map =new HashMap<String,Object>();
			
			long ctime = devEntity.getCtime();
			map.put("ctime", ctime);
			
			String desc = devEntity.getDesc();
			map.put("desc", desc);
			
			String did = devEntity.getDid();
			map.put("did", did);
			
			String ip = devEntity.getIp();
			map.put("ip", ip);
			
			long mtime = devEntity.getMtime();
			map.put("mtime", mtime);
			
			String phone = devEntity.getPhone();
			map.put("phone", phone);
			
			long status = devEntity.getStatus();
			map.put("status", status);
			
			String stoken = devEntity.getStoken();
			map.put("stoken", stoken);
			
			String uname = devEntity.getUname();
			map.put("uname", uname);
			
			try {
				migrateMapper.addDev(map);
			} catch(DuplicateKeyException e){
				migrateMapper.updateDev(map);
			}catch (Exception e) {
				LOG.error("迁移dev数据异常", e);
			}
		}
		LOG.info("迁移完成:migrateDev");
	}

	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public void migrateGlobalDayBook() throws Exception {
		List<GlobalDayBookEntity> globalDayBookEntitys = mongoTemplate.findAll(GlobalDayBookEntity.class, "global_day_book");
		
		migrateMapper.deleteGlobalDayBook(null);
		for(GlobalDayBookEntity globalDayBookEntity : globalDayBookEntitys){
			Map<String,Object> map =new HashMap<String,Object>();
			long ctime = globalDayBookEntity.getCtime();
			map.put("ctime", ctime);
			
			String day = globalDayBookEntity.getDay();
			map.put("day", day);
			
			long day_for_agent = globalDayBookEntity.getDay_for_agent();
			map.put("day_for_agent", day_for_agent);
			
			long day_for_self = globalDayBookEntity.getDay_for_self();
			map.put("day_for_self", day_for_self);
			
			long day_rebate_money = globalDayBookEntity.getDay_rebate_money();
			map.put("day_rebate_money", day_rebate_money);
			
			long day_recharge_money = globalDayBookEntity.getDay_recharge_money();
			map.put("day_recharge_money", day_recharge_money);
			
			long day_total_count = globalDayBookEntity.getDay_total_count();
			map.put("day_total_count", day_total_count);
			
			long mtime = globalDayBookEntity.getMtime();
			map.put("mtime", mtime);
			
			try {
				migrateMapper.addGlobalDayBook(map);
			} catch (Exception e) {
				LOG.error("迁移GlobalDayBook数据异常", e);
			}
			
		}
		LOG.info("迁移完成:migrateGlobalDayBook");
	}

	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public void migrateLog() throws Exception {
		List<LogEntity> logEntitys = mongoTemplate.findAll(LogEntity.class, "log");
		
		migrateMapper.deleteLog(null);
		for(LogEntity logEntity : logEntitys){
			Map<String,Object> map =new HashMap<String,Object>();
			
			long ctime = logEntity.getCtime();
			map.put("ctime", ctime);
			
			String id = logEntity.getId();
			map.put("id", id);
			
			String info = logEntity.getInfo();
			map.put("info", info);
			
			String  ip = logEntity.getIp();
			map.put("ip", ip);
			
			String msg = logEntity.getMsg();
			map.put("msg", msg);
			
			long mtime = logEntity.getMtime();
			map.put("mtime", mtime);
			
			String op_phone = logEntity.getOp_phone();
			map.put("op_phone", op_phone);
			
			int oper = logEntity.getOper();
			map.put("oper", oper);
			
			int type = logEntity.getType();
			map.put("type", type);
			
			try {
				migrateMapper.addLog(map);
			} catch (Exception e) {
				LOG.error("迁移Logk数据异常", e);
			}
			
		}
		
		LOG.info("迁移完成:migrateLog");
	}

	public void migrateRebate() throws Exception {
		List<RebateEntity> rebateEntitys  = mongoTemplate.findAll(RebateEntity.class, "rebate");
		
		for(RebateEntity rebateEntity : rebateEntitys){
			Map<String,Object> map =new HashMap<String,Object>();
			String aid = rebateEntity.getAid();
			map.put("aid", aid);
			
			String appid = rebateEntity.getAppid();
			map.put("appid", appid);
			
			String appname = rebateEntity.getAppname();
			map.put("appname", appname);
			
			long ctime = rebateEntity.getCtime();
			map.put("ctime", ctime);
			
			String desc = rebateEntity.getDesc();
			map.put("appdesc", desc);
			
			long mtime = rebateEntity.getMtime();
			map.put("mtime", mtime);
			
			String rid = rebateEntity.getRid();
			map.put("rid", rid);
			
			String rtype = rebateEntity.getRtype();
			map.put("rtype", rtype);
			
			String status = rebateEntity.getStatus();
			map.put("status", status);
			
			String ticount = rebateEntity.getTicount();
			map.put("ticount", ticount);
			
			String tincome = rebateEntity.getTincome();
			map.put("tincome", tincome);
			
			String vcode = rebateEntity.getVcode();
			map.put("vcode", vcode);
			
			try {
				migrateMapper.addRebate(map);
			} catch(DuplicateKeyException e){
				migrateMapper.updateRebate(map);
			}catch (Exception e) {
				LOG.error("迁移Rebate数据异常", e);
			}
		}
		
		LOG.info("迁移完成:migrateRebate");
	}

	/*@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)*/
	public void migrateTransaction() throws Exception {
		//List<TransactionEntity> transactionEntitys = mongoTemplate.findAll(TransactionEntity.class, "transaction");
		/*migrateMapper.deleteTransaction(null);*/

		int pageSize = 500;
		Query queryOne = new Query();
		queryOne.with(new Sort(new Sort.Order(Sort.Direction.DESC, "ctime")));
		queryOne.skip(0).limit(pageSize);
		List<TransactionEntity> transactionEntitys = mongoTemplate.find(queryOne, TransactionEntity.class, "transaction");

		int i=1;
		while( transactionEntitys != null && transactionEntitys.size() > 0) {
			LOG.info("迁移Transaction数据, i={}, transactionEntitys.size()={}", i, transactionEntitys.size());

			for (TransactionEntity transactionEntity : transactionEntitys) {
				Map<String, Object> map = new HashMap<String, Object>();

				String aid = transactionEntity.getAid();
				map.put("aid", aid);

				String appid = transactionEntity.getAppid();
				map.put("appid", appid);

				long ctime = transactionEntity.getCtime();
				map.put("ctime", ctime);

				if(ctime > 0){
					Date tr_crtdate = new Date(ctime * 1000);
					map.put("tr_crtdate", tr_crtdate);
				}

				double day_for_agent = transactionEntity.getDay_for_agent();
				map.put("day_for_agent", day_for_agent);

				String did = transactionEntity.getDid();
				map.put("did", did);

				String ip = transactionEntity.getIp();
				map.put("ip", ip);

				long mtime = transactionEntity.getMtime();
				map.put("mtime", mtime);

				if(mtime > 0){
					Date tr_moddate = new Date(mtime * 1000);
					map.put("tr_moddate", tr_moddate);
				}

				String oid = transactionEntity.getOid();
				map.put("oid", oid);

				long otime = transactionEntity.getOtime();
				if(String.valueOf(otime).length() > 10){
					otime = otime / 1000;
				}
				map.put("otime", otime);

				if(otime > 0){
					Date tr_order_date = new Date(otime * 1000);
					map.put("tr_order_date", tr_order_date);
				}

				long recharge = transactionEntity.getRecharge();
				map.put("recharge", recharge);

				String retrade = transactionEntity.getRetrade();
				map.put("retrade", retrade);

				String status = transactionEntity.getStatus();
				map.put("status", status);

				String uid = transactionEntity.getUid();
				map.put("uid", uid);

				String uname = transactionEntity.getUname();
				map.put("uname", uname);

				String isValid = transactionEntity.getIsValid();
				if(StringUtils.isNotBlank(isValid)){
					map.put("isValid", isValid);
				}

				Long validTime = transactionEntity.getValidTime();
				map.put("validTime", validTime);

				if(validTime > 0){
					Date tr_validdate = new Date(validTime * 1000);
					map.put("tr_validdate", tr_validdate);
				}

				String channelcd = transactionEntity.getChannelcd();
				if(StringUtils.isNotBlank(channelcd)){
					map.put("channelcd", channelcd);
				}

				try {
					migrateMapper.addTransaction(map);
				} catch (DuplicateKeyException e) {
					//LOG.warn("迁移Transaction数据, 数据已存在, map={}", map);
				} catch (Exception ex) {
					LOG.error("迁移Transaction数据异常", ex);
				}
			}

			++i;
			Query query = new Query();
			query.with(new Sort(new Sort.Order(Sort.Direction.DESC, "ctime")));
			query.skip((i - 1) * 500).limit(pageSize);
			transactionEntitys = mongoTemplate.find(query, TransactionEntity.class, "transaction");
		}
		LOG.info("迁移完成:migrateTransaction");

	}

	public void migrateWhite() throws Exception {
		List<WhiteEntity> whiteEntitys  = mongoTemplate.findAll(WhiteEntity.class, "white");
		for(WhiteEntity whiteEntity : whiteEntitys){
			Map<String,Object> map =new HashMap<String,Object>();
			long ctime = whiteEntity.getCtime();
			map.put("ctime", ctime);
			
			long mtime = whiteEntity.getMtime();
			map.put("mtime", mtime);
			
			String phone = whiteEntity.getPhone();
			map.put("phone", phone);
			
			long status = whiteEntity.getStatus();
			map.put("status", status);
			
			try {
				migrateMapper.addWhite(map);
			} catch(DuplicateKeyException e){
				migrateMapper.updateWhite(map);
			}catch (Exception e) {
				LOG.error("迁移white数据异常", e);
			}
		}
		
		LOG.info("迁移完成:migrateWhite");
	}
	
	protected String getSalt()
	{
		Random r = new Random();
		return DigestUtils.sha512Hex(String.valueOf(r.nextLong()));
	}

	//@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public void migrateChannelIncome() throws Exception {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
		//migrateMapper.deleteChannelIncome(null);

		int pageSize = 500;
		Query queryOne = new Query();
		queryOne.with(new Sort(new Sort.Order(Sort.Direction.DESC, "ctime")));
		queryOne.skip(0).limit(pageSize);
		List<TransactionEntity> transactionEntitys = mongoTemplate.find(queryOne, TransactionEntity.class, "channel_income");

		int i=1;
		while( transactionEntitys != null && transactionEntitys.size() > 0){
			LOG.info("迁移ChannelIncome数据, i={}, transactionEntitys.size()={}", i, transactionEntitys.size());

			for(TransactionEntity transactionEntity : transactionEntitys){
				Map<String,Object> map =new HashMap<String,Object>();

				String channel_member_aid = null;
				String channelcd = transactionEntity.getChannelcd();
				List<String> roletypes = new ArrayList<String>();
				roletypes.add("2");
				roletypes.add("3");

				Map<String, Object> queryParams = new HashMap<String, Object>();
				queryParams.put("roletypes", roletypes);
				queryParams.put("channelcd", channelcd);
				AgentEntity agentEntity = queryAgentInfo(queryParams);
				if(agentEntity != null){
					channel_member_aid = agentEntity.getAid();
				}
				map.put("channel_member_aid", channel_member_aid);

				map.put("channelcd", channelcd);
				double channel_income = transactionEntity.getChannel_income();
				map.put("channel_income", channel_income);

				String aid = transactionEntity.getAid();
				map.put("aid", aid);

				String appid = transactionEntity.getAppid();
				map.put("appid", appid);

				long ctime = transactionEntity.getCtime();
				map.put("ctime", ctime);

				Date ci_crtdate = new Date(ctime * 1000);
				map.put("ci_crtdate", ci_crtdate);

				double day_for_agent = transactionEntity.getDay_for_agent();
				map.put("day_for_agent", day_for_agent);

				String did = transactionEntity.getDid();
				map.put("did", did);

				String ip = transactionEntity.getIp();
				map.put("ip", ip);

				long mtime = transactionEntity.getMtime();
				map.put("mtime", mtime);

				Date ci_moddate = new Date(mtime * 1000);
				map.put("ci_moddate", ci_moddate);

				String oid = transactionEntity.getOid();
				map.put("oid", oid);

				long otime = transactionEntity.getOtime();
				map.put("otime", otime);

				long recharge = transactionEntity.getRecharge();
				map.put("recharge", recharge);

				String retrade = transactionEntity.getRetrade();
				map.put("retrade", retrade);

				String status = transactionEntity.getStatus();
				map.put("status", status);

				String uid = transactionEntity.getUid();
				map.put("uid", uid);

				String uname = transactionEntity.getUname();
				map.put("uname", uname);

				Date ci_order_date = new Date(otime * 1000);
				map.put("ci_order_date", ci_order_date);

				try {
					migrateMapper.addChannelIncome(map);
				}catch (DuplicateKeyException e){
					//LOG.warn("迁移ChannelIncome数据, 数据已存在, map={}", map);
				}catch (Exception ex) {
					LOG.error("迁移ChannelIncome数据异常", ex);
				}
			}

			++i;
			Query query = new Query();
			query.with(new Sort(new Sort.Order(Sort.Direction.DESC, "ctime")));
			query.skip((i-1) * 500).limit(pageSize);
			transactionEntitys = mongoTemplate.find(query, TransactionEntity.class, "channel_income");
		}

		/*Query queryAll = new Query();
		queryAll.with(new Sort(new Sort.Order(Sort.Direction.ASC, "ctime")));
		Long tmpCount = mongoTemplate.count(queryAll, TransactionEntity.class, "channel_income");

		int allCount = Integer.parseInt(tmpCount.toString());
		int pageSize = 1000;
		int pageCount = allCount / 1000;

		for(int i=1; i<=pageCount+1; i++){
			Query query = new Query();
			query.with(new Sort(new Sort.Order(Sort.Direction.ASC, "ctime")));
			query.skip((i-1) * 1000).limit(pageSize);
			List<TransactionEntity> transactionEntitys = mongoTemplate.find(query, TransactionEntity.class, "channel_income");

			for(TransactionEntity transactionEntity : transactionEntitys){
				Map<String,Object> map =new HashMap<String,Object>();

				String channel_member_aid = null;
				String channelcd = transactionEntity.getChannelcd();
				List<String> roletypes = new ArrayList<String>();
				roletypes.add("2");
				roletypes.add("3");

				Map<String, Object> queryParams = new HashMap<String, Object>();
				queryParams.put("roletypes", roletypes);
				queryParams.put("channelcd", channelcd);
				AgentEntity agentEntity = queryAgentInfo(queryParams);
				if(agentEntity != null){
					channel_member_aid = agentEntity.getAid();
				}
				map.put("channel_member_aid", channel_member_aid);

				map.put("channelcd", channelcd);
				double channel_income = transactionEntity.getChannel_income();
				map.put("channel_income", channel_income);

				String aid = transactionEntity.getAid();
				map.put("aid", aid);

				String appid = transactionEntity.getAppid();
				map.put("appid", appid);

				long ctime = transactionEntity.getCtime();
				map.put("ctime", ctime);

				double day_for_agent = transactionEntity.getDay_for_agent();
				map.put("day_for_agent", day_for_agent);

				String did = transactionEntity.getDid();
				map.put("did", did);

				String ip = transactionEntity.getIp();
				map.put("ip", ip);

				long mtime = transactionEntity.getMtime();
				map.put("mtime", mtime);

				String oid = transactionEntity.getOid();
				map.put("oid", oid);

				long otime = transactionEntity.getOtime();
				map.put("otime", otime);

				long recharge = transactionEntity.getRecharge();
				map.put("recharge", recharge);

				String retrade = transactionEntity.getRetrade();
				map.put("retrade", retrade);

				String status = transactionEntity.getStatus();
				map.put("status", status);

				String uid = transactionEntity.getUid();
				map.put("uid", uid);

				String uname = transactionEntity.getUname();
				map.put("uname", uname);

				Date ci_order_date = new Date(otime * 1000);
				map.put("ci_order_date", ci_order_date);

				String ci_order_date_str = simpleDateFormat.format(ci_order_date);
				map.put("ci_order_date_str", ci_order_date_str);

				try {
					migrateMapper.addChannelIncome(map);
				}catch (DuplicateKeyException e){
					LOG.warn("迁移ChannelIncome数据, 数据已存在, map={}", map);
				}catch (Exception ex) {
					LOG.error("迁移ChannelIncome数据异常", ex);
				}
			}

		}*/
		LOG.info("迁移完成:migrateChannelIncome");
	}

	/**
	 * 查询代理信息
	 * @param params
	 * @return
	 */
	private AgentEntity queryAgentInfo(Map<String, Object> params){
		String channelcd = (String)params.get("channelcd");
		List<String> roletypes = (List<String>)params.get("roletypes");
		Query agentQuery = new Query();
		agentQuery.addCriteria(Criteria.where("channelcd").is(channelcd));
		agentQuery.addCriteria(Criteria.where("roletype").in(roletypes));
		AgentEntity agentEntity = mongoTemplate.findOne(agentQuery, AgentEntity.class, "agent");
		if(agentEntity == null){
			return null;
		}

		return agentEntity;
	}


	//@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public void migrateHeadmanIncome() throws Exception {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
		//migrateMapper.deleteHeadmanIncome(null);

		int pageSize = 500;
		Query queryOne = new Query();
		queryOne.with(new Sort(new Sort.Order(Sort.Direction.DESC, "ctime")));
		queryOne.skip(0).limit(pageSize);
		List<TransactionEntity> transactionEntitys = mongoTemplate.find(queryOne, TransactionEntity.class, "headman_income");

		int i=1;
		while( transactionEntitys != null && transactionEntitys.size() > 0){
			LOG.info("迁移HeadmanIncome数据, i={}, transactionEntitys.size()={}", i, transactionEntitys.size());

			for (TransactionEntity transactionEntity : transactionEntitys) {
				Map<String, Object> map = new HashMap<String, Object>();

				String member_channelcd = transactionEntity.getMember_channelcd();
				map.put("member_channelcd", member_channelcd);

				String headman_channelcd = transactionEntity.getHeadman_channelcd();
				map.put("headman_channelcd", headman_channelcd);

				double headman_income = transactionEntity.getHeadman_income();
				map.put("headman_income", headman_income);

				String headman_aid = transactionEntity.getHeadman_aid();
				map.put("headman_aid", headman_aid);

				String aid = transactionEntity.getAid();
				map.put("aid", aid);

				String appid = transactionEntity.getAppid();
				map.put("appid", appid);

				long ctime = transactionEntity.getCtime();
				map.put("ctime", ctime);

				Date hi_crtdate = new Date(ctime * 1000);
				map.put("hi_crtdate", hi_crtdate);

				double day_for_agent = transactionEntity.getDay_for_agent();
				map.put("day_for_agent", day_for_agent);

				String did = transactionEntity.getDid();
				map.put("did", did);

				String ip = transactionEntity.getIp();
				map.put("ip", ip);

				long mtime = transactionEntity.getMtime();
				map.put("mtime", mtime);

				Date hi_moddate = new Date(mtime * 1000);
				map.put("hi_moddate", hi_moddate);

				String oid = transactionEntity.getOid();
				map.put("oid", oid);

				long otime = transactionEntity.getOtime();
				map.put("otime", otime);

				long recharge = transactionEntity.getRecharge();
				map.put("recharge", recharge);

				String retrade = transactionEntity.getRetrade();
				map.put("retrade", retrade);

				String status = transactionEntity.getStatus();
				map.put("status", status);

				String uid = transactionEntity.getUid();
				map.put("uid", uid);

				String uname = transactionEntity.getUname();
				map.put("uname", uname);

				Date hi_order_date = new Date(otime * 1000);
				map.put("hi_order_date", hi_order_date);

				try {
					migrateMapper.addHeadmanIncome(map);
				} catch (DuplicateKeyException e){
					//LOG.warn("迁移HeadmanIncome数据, 数据已存在, map={}", map);
				} catch (Exception e) {
					LOG.error("迁移HeadmanIncome数据异常", e);
				}
			}

			++i;
			Query query = new Query();
			query.with(new Sort(new Sort.Order(Sort.Direction.DESC, "ctime")));
			query.skip((i-1) * 500).limit(pageSize);
			transactionEntitys = mongoTemplate.find(query, TransactionEntity.class, "headman_income");
		}

		LOG.info("迁移完成:migrateHeadmanIncome");
	}
	
	
	public void migrateAccountReport() throws Exception {
		
		Map<String, Object> paramMap = new HashMap<String, Object>();
		
		try {
			//获取当前期周二
			//获取当前日期0点
			Date currentDate = DateUtil.parseTimestamp(DateUtil.Format(new Date(), "yyyy-MM-dd") + " 00:00:00");
			
			Date tuesday = DateUtil.getTuesday(currentDate, 0);	
			if(currentDate.getTime() < tuesday.getTime()){
				
				tuesday = DateUtil.getTuesday(currentDate, -7);
				
			}
			
//			paramMap.put("startDate", DateUtil.format(tuesday));
//			paramMap.put("endDate", DateUtil.format(new Date()));
			paramMap.put("endDate", DateUtil.format(tuesday));
			
			List<Map<String, Object>> accountList = apiMapper.queryAccountReportCurrentList(paramMap);
			
			for (Map<String, Object> map : accountList) {
				try {
					
					map.put("AR_START_DATE", paramMap.get("startDate"));
					map.put("AR_END_DATE", paramMap.get("endDate"));
					migrateMapper.saveAccountReportCurrent(map);
					
				} catch (Exception e) {
					
					LOG.info("更新财务对账当期数据异常:{}", JSONObject.toJSONString(map), e);
					migrateMapper.updateAccountReportCurrent(map);
					
				}
			}
			
		} catch (DuplicateKeyException e) {
			LOG.info("添加财务对账当期数据查询异常:{},{}", paramMap.get("startDate"), paramMap.get("endDate"));
		}
		
		LOG.info("迁移完成:migrateAccountReport");
	}

}
