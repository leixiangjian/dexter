package com.cornu.report.api;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cornu.report.response.ResponseObj;
import com.cornu.report.service.api.ApiService;

import io.swagger.annotations.*;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.*;

@Controller
@Api("基本数据统计API")
public class StatBasicDataApi extends BaseApi{
    private static final Logger LOG = LoggerFactory.getLogger(StatBasicDataApi.class);

    @Autowired(required = true)
    @Qualifier(value = "apiService")
    ApiService apiService;

    @ResponseBody
    @RequestMapping(value = "/getBasic", method=RequestMethod.POST)
    @ApiOperation(value="统计基本数据接口", notes="统计基本数据")
    @ApiImplicitParams({
    	 @ApiImplicitParam(paramType="query",name="beginDate",dataType="String",required=true,value="格式:YYYY-MM-DD"),
         @ApiImplicitParam(paramType="query",name="endDate",dataType="String",required=true,value="格式:YYYY-MM-DD"),
         @ApiImplicitParam(paramType="query",name="channelcds",dataType="String",required=true,value="格式:channelcd1,channelcd2,……")
    })
    @ApiResponses({
            @ApiResponse(code=400,message="测试"),
            @ApiResponse(code=404,message="测试")
    })
    public ResponseObj getBasic(HttpServletRequest request, HttpServletResponse response) throws Exception {
        ResponseObj resObj = new ResponseObj();
        resObj.setResCode(ResponseObj.SUCCESS);
        String beginDate = null;
        String endDate = null;
        String[] channelcds = null;
        String[] appids = null;
        Map<String, Object> params = new HashMap<String, Object>();

        if(request.getParameter("beginDate")!=null){
            beginDate = request.getParameter("beginDate");
        }else{
            resObj.setResCode(ResponseObj.FAILED);
            resObj.setResMsg("beginDate参数不能为空");
            LOG.error("getBasic, beginDate参数不能为空");
            return resObj;
        }

        if(request.getParameter("endDate")!=null){
            endDate = request.getParameter("endDate");
        }else{
            resObj.setResCode(ResponseObj.FAILED);
            resObj.setResMsg("endDate参数不能为空");
            LOG.error("getBasic, endDate参数不能为空");
            return resObj;
        }

        if(request.getParameter("channelcds")!=null){
            channelcds = StringUtils.splitByWholeSeparator(request.getParameter("channelcds"), ",");
        }else{
            resObj.setResCode(ResponseObj.FAILED);
            resObj.setResMsg("channelcds参数不能为空");
            LOG.error("getBasic, channelcds参数不能为空");
            return resObj;
        }

        if(request.getParameter("appids")!=null){
            appids = StringUtils.splitByWholeSeparator(request.getParameter("appids"), ",");
            params.put("appids", appids);
        }

        params.put("beginDate", beginDate);
        params.put("endDate", endDate);
        params.put("channelcds", channelcds);

        Map<String, Object> basicDataMap = apiService.queryBasicData(params);

        resObj.setResData(basicDataMap);

        return resObj;
    }

    @ResponseBody
    @RequestMapping(value = "/getAgentDetailData", method=RequestMethod.POST)
    @ApiOperation(value="统计代理员详细数据接口", notes="统计代理员详细数据接口")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType="query",name="beginDate",dataType="String",required=true,value="格式:YYYY-MM-DD"),
            @ApiImplicitParam(paramType="query",name="endDate",dataType="String",required=true,value="格式:YYYY-MM-DD"),
            @ApiImplicitParam(paramType="query",name="aid",dataType="String",required=true,value="格式:8272154589904326666")
    })
    @ApiResponses({
            @ApiResponse(code=400,message="测试"),
            @ApiResponse(code=404,message="测试")
    })
    public ResponseObj getAgentDetailData(HttpServletRequest request, HttpServletResponse response) throws Exception {
        ResponseObj resObj = new ResponseObj();
        resObj.setResCode(ResponseObj.SUCCESS);
        String beginDate = null;
        String endDate = null;
        String aid = null;
        Map<String, Object> params = new HashMap<String, Object>();

        if(request.getParameter("beginDate")!=null){
            beginDate = request.getParameter("beginDate");
        }else{
            resObj.setResCode(ResponseObj.FAILED);
            resObj.setResMsg("beginDate参数不能为空");
            LOG.error("getAgentDetailData, beginDate参数不能为空");
            return resObj;
        }

        if(request.getParameter("endDate")!=null){
            endDate = request.getParameter("endDate");
        }else{
            resObj.setResCode(ResponseObj.FAILED);
            resObj.setResMsg("endDate参数不能为空");
            LOG.error("getAgentDetailData, endDate参数不能为空");
            return resObj;
        }

        if(request.getParameter("aid")!=null){
            aid = request.getParameter("aid");
        }else{
            resObj.setResCode(ResponseObj.FAILED);
            resObj.setResMsg("aid参数不能为空");
            LOG.error("getAgentDetailData, aid参数不能为空");
            return resObj;
        }

        params.put("beginDate", beginDate);
        params.put("endDate", endDate);
        params.put("aid", aid);

        Map<String, Object> basicDataMap = apiService.getAgentDetailData(params);

        resObj.setResData(basicDataMap);

        return resObj;
    }

    @ResponseBody
    @RequestMapping(value = "/getAgentDataAnalysis", method=RequestMethod.POST)
    @ApiOperation(value="代理员数据分析接口", notes="代理员数据分析接口")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType="query",name="beginDate",dataType="String",required=true,value="格式:YYYY-MM-DD"),
            @ApiImplicitParam(paramType="query",name="endDate",dataType="String",required=true,value="格式:YYYY-MM-DD"),
    })
    @ApiResponses({
            @ApiResponse(code=400,message="测试"),
            @ApiResponse(code=404,message="测试")
    })
    public ResponseObj getAgentDataAnalysis(HttpServletRequest request, HttpServletResponse response) throws Exception {
        ResponseObj resObj = new ResponseObj();
        resObj.setResCode(ResponseObj.SUCCESS);
        String beginDate = null;
        String endDate = null;
        Map<String, Object> params = new HashMap<String, Object>();

        if(request.getParameter("beginDate")!=null){
            beginDate = request.getParameter("beginDate");
        }else{
            resObj.setResCode(ResponseObj.FAILED);
            resObj.setResMsg("beginDate参数不能为空");
            LOG.error("getAgentDataAnalysis, beginDate参数不能为空");
            return resObj;
        }

        if(request.getParameter("endDate")!=null){
            endDate = request.getParameter("endDate");
        }else{
            resObj.setResCode(ResponseObj.FAILED);
            resObj.setResMsg("endDate参数不能为空");
            LOG.error("getAgentDataAnalysis, endDate参数不能为空");
            return resObj;
        }

        params.put("beginDate", beginDate);
        params.put("endDate", endDate);

        Map<String, Object> basicDataMap = apiService.getAgentDataAnalysis(params);

        resObj.setResData(basicDataMap);

        return resObj;
    }

    @ResponseBody
    @RequestMapping(value = "/getPromotionData", method=RequestMethod.POST)
    @ApiOperation(value="推广数据接口", notes="推广数据接口")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType="query",name="beginDate",dataType="String",required=true,value="格式:YYYY-MM-DD"),
            @ApiImplicitParam(paramType="query",name="endDate",dataType="String",required=true,value="格式:YYYY-MM-DD"),
            @ApiImplicitParam(paramType="query",name="channelcd",dataType="String",required=true,value="格式:LW0022"),
            @ApiImplicitParam(paramType="query",name="aid",dataType="String",required=true,value="格式:8272156825333787265")
    })
    @ApiResponses({
            @ApiResponse(code=400,message="测试"),
            @ApiResponse(code=404,message="测试")
    })
    public ResponseObj getPromotionData(HttpServletRequest request, HttpServletResponse response) throws Exception {
        ResponseObj resObj = new ResponseObj();
        resObj.setResCode(ResponseObj.SUCCESS);
        String beginDate = null;
        String endDate = null;
        String channelcd = null;
        String aid = null;
        Map<String, Object> params = new HashMap<String, Object>();

        if(request.getParameter("beginDate")!=null){
            beginDate = request.getParameter("beginDate");
        }else{
            resObj.setResCode(ResponseObj.FAILED);
            resObj.setResMsg("beginDate参数不能为空");
            LOG.error("getPromotionData, beginDate参数不能为空");
            return resObj;
        }

        if(request.getParameter("endDate")!=null){
            endDate = request.getParameter("endDate");
        }else{
            resObj.setResCode(ResponseObj.FAILED);
            resObj.setResMsg("endDate参数不能为空");
            LOG.error("getPromotionData, endDate参数不能为空");
            return resObj;
        }

        if(request.getParameter("channelcd")!=null){
            channelcd = request.getParameter("channelcd");
        }else{
            resObj.setResCode(ResponseObj.FAILED);
            resObj.setResMsg("channelcd参数不能为空");
            LOG.error("getPromotionData, channelcd参数不能为空");
            return resObj;
        }

        if(request.getParameter("aid")!=null){
            aid = request.getParameter("aid");
        }else{
            resObj.setResCode(ResponseObj.FAILED);
            resObj.setResMsg("aid参数不能为空");
            LOG.error("getPromotionData, aid参数不能为空");
            return resObj;
        }

        params.put("beginDate", beginDate);
        params.put("endDate", endDate);
        params.put("channelcd", channelcd);
        params.put("aid", aid);

        LOG.info("获取推广数据, getPromotionData, params={}", params);
        Map<String, Object> basicDataMap = apiService.queryPromotionData(params);

        resObj.setResData(basicDataMap);

        return resObj;
    }

    @ResponseBody
    @RequestMapping(value = "/getPromotionAgentDataAnalysis", method=RequestMethod.POST)
    @ApiOperation(value="推广数据代理员数据分析接口", notes="推广数据代理员数据分析接口")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType="query",name="beginDate",dataType="String",required=false,value="格式:YYYY-MM-DD"),
            @ApiImplicitParam(paramType="query",name="endDate",dataType="String",required=false,value="格式:YYYY-MM-DD"),
            @ApiImplicitParam(paramType="query",name="channelcd",dataType="String",required=true,value="格式:LW0075")
    })
    @ApiResponses({
            @ApiResponse(code=400,message="测试"),
            @ApiResponse(code=404,message="测试")
    })
    public ResponseObj getPromotionAgentDataAnalysis(HttpServletRequest request, HttpServletResponse response) throws Exception {
        ResponseObj resObj = new ResponseObj();
        resObj.setResCode(ResponseObj.SUCCESS);
        String beginDate = null;
        String endDate = null;
        String channelcd = null;
        Map<String, Object> params = new HashMap<String, Object>();

        if(request.getParameter("beginDate")!=null){
            beginDate = request.getParameter("beginDate");
            params.put("beginDate", beginDate);
        }

        if(request.getParameter("endDate")!=null){
            endDate = request.getParameter("endDate");
            params.put("endDate", endDate);
        }

        if(request.getParameter("channelcd")!=null){
            channelcd = request.getParameter("channelcd");
        }else{
            resObj.setResCode(ResponseObj.FAILED);
            resObj.setResMsg("channelcd参数不能为空");
            LOG.error("getPromotionAgentDataAnalysis, channelcd参数不能为空");
            return resObj;
        }

        params.put("channelcd", channelcd);

        Map<String, Object> basicDataMap = apiService.getPromotionAgentDataAnalysis(params);

        resObj.setResData(basicDataMap);

        return resObj;
    }

    @ResponseBody
    @RequestMapping(value = "/getPromotionMemberData", method=RequestMethod.POST)
    @ApiOperation(value="推广数据组员数据接口", notes="推广数据组员数据接口")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType="query",name="beginDate",dataType="String",required=true,value="格式:YYYY-MM-DD"),
            @ApiImplicitParam(paramType="query",name="endDate",dataType="String",required=true,value="格式:YYYY-MM-DD"),
            @ApiImplicitParam(paramType="query",name="p_channelcd",dataType="String",required=false,value="格式:LW022"),
            @ApiImplicitParam(paramType="query",name="p_channelcds",dataType="String",required=false,value="格式:LW022,LW0075"),
    })
    @ApiResponses({
            @ApiResponse(code=400,message="测试"),
            @ApiResponse(code=404,message="测试")
    })
    public ResponseObj getPromotionMemberData(HttpServletRequest request, HttpServletResponse response) throws Exception {
        ResponseObj resObj = new ResponseObj();
        resObj.setResCode(ResponseObj.SUCCESS);
        String beginDate = null;
        String endDate = null;
        String p_channelcd = null;
        String p_channelcds = null;
        Map<String, Object> params = new HashMap<String, Object>();

        if(request.getParameter("beginDate")!=null){
            beginDate = request.getParameter("beginDate");
        }else{
            resObj.setResCode(ResponseObj.FAILED);
            resObj.setResMsg("beginDate参数不能为空");
            LOG.error("getPromotionMemberData, beginDate参数不能为空");
            return resObj;
        }

        if(request.getParameter("endDate")!=null){
            endDate = request.getParameter("endDate");
        }else{
            resObj.setResCode(ResponseObj.FAILED);
            resObj.setResMsg("endDate参数不能为空");
            LOG.error("getPromotionMemberData, endDate参数不能为空");
            return resObj;
        }
        //此处传的一定要是组长的p_channelcd
        if(request.getParameter("p_channelcd")!=null){
            p_channelcd = request.getParameter("p_channelcd");
            params.put("p_channelcd", p_channelcd);
        }
        //此处传的一定要是区域组编码的p_channelcds(LW0022,LW0075)
        if(request.getParameter("p_channelcds")!=null){
            p_channelcds = request.getParameter("p_channelcds");
            params.put("p_channelcds", p_channelcds);
        }

        params.put("beginDate", beginDate);
        params.put("endDate", endDate);
        LOG.info("getPromotionMemberData, 参数={}", params);

        Map<String, Object> basicDataMap = apiService.getPromotionMemberData(params);

        resObj.setResData(basicDataMap);

        return resObj;
    }

    @ResponseBody
    @RequestMapping(value = "/getAreaDataAnalysis", method=RequestMethod.POST)
    @ApiOperation(value="地区数据分析接口", notes="地区数据分析接口")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType="query",name="beginDate",dataType="String",required=true,value="格式:YYYY-MM-DD"),
            @ApiImplicitParam(paramType="query",name="endDate",dataType="String",required=true,value="格式:YYYY-MM-DD")
    })
    @ApiResponses({
            @ApiResponse(code=400,message="测试"),
            @ApiResponse(code=404,message="测试")
    })
    public ResponseObj getAreaDataAnalysis(HttpServletRequest request, HttpServletResponse response) throws Exception {
        ResponseObj resObj = new ResponseObj();
        resObj.setResCode(ResponseObj.SUCCESS);
        String beginDate = null;
        String endDate = null;
        Map<String, Object> params = new HashMap<String, Object>();

        if(request.getParameter("beginDate")!=null){
            beginDate = request.getParameter("beginDate");
        }else{
            resObj.setResCode(ResponseObj.FAILED);
            resObj.setResMsg("beginDate参数不能为空");
            LOG.error("getAreaDataAnalysis, beginDate参数不能为空");
            return resObj;
        }

        if(request.getParameter("endDate")!=null){
            endDate = request.getParameter("endDate");
        }else{
            resObj.setResCode(ResponseObj.FAILED);
            resObj.setResMsg("endDate参数不能为空");
            LOG.error("getAreaDataAnalysis, endDate参数不能为空");
            return resObj;
        }

        params.put("beginDate", beginDate);
        params.put("endDate", endDate);

        Map<String, Object> basicDataMap = apiService.getAreaDataAnalysis(params);

        resObj.setResData(basicDataMap);

        return resObj;
    }

    @ResponseBody
    @RequestMapping(value = "/getAgentAccountInfo", method=RequestMethod.POST)
    @ApiOperation(value="查询代理员上周二到当前时间的账户信息接口", notes="查询代理员上周二到当前时间的账户信息接口")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType="query",name="phone",dataType="String",required=true,value="格式:13480877165")
    })
    @ApiResponses({
            @ApiResponse(code=400,message="测试"),
            @ApiResponse(code=404,message="测试")
    })
    public ResponseObj getAgentAccountInfo(HttpServletRequest request, HttpServletResponse response) throws Exception {
        ResponseObj resObj = new ResponseObj();
        resObj.setResCode(ResponseObj.SUCCESS);
        String phone = null;
        Map<String, Object> params = new HashMap<String, Object>();

        if(request.getParameter("phone")!=null){
            phone = request.getParameter("phone");
        }else{
            resObj.setResCode(ResponseObj.FAILED);
            resObj.setResMsg("phone参数不能为空");
            LOG.error("getAgentAccountInfo, phone参数不能为空");
            return resObj;
        }

        params.put("phone", phone);

        Map<String, Object> basicDataMap = apiService.getAgentAccountInfo(params);

        resObj.setResData(basicDataMap);

        return resObj;
    }

    @ResponseBody
    @RequestMapping(value = "/getAgentAccountInfoTwo", method=RequestMethod.POST)
    @ApiOperation(value="查询代理员上周二到当前时间的账户信息接口", notes="查询代理员上周二到当前时间的账户信息接口")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType="query",name="phone",dataType="String",required=true,value="格式:13480877165,13480877165")
    })
    @ApiResponses({
            @ApiResponse(code=400,message="测试"),
            @ApiResponse(code=404,message="测试")
    })
    public ResponseObj getAgentAccountInfoTwo(HttpServletRequest request, HttpServletResponse response) throws Exception {
        ResponseObj resObj = new ResponseObj();
        resObj.setResCode(ResponseObj.SUCCESS);
        String phone = null;
        List<String> phoneList = new ArrayList<String>();
        Map<String, Object> params = new HashMap<String, Object>();

        if(request.getParameter("phone")!=null){
            phone = request.getParameter("phone");
            if(StringUtils.isBlank(phone)){
                resObj.setResCode(ResponseObj.FAILED);
                resObj.setResMsg("phone参数不能为空");
                LOG.error("getAgentAccountInfoTwo, phone参数不能为空");
                return resObj;
            }

            String[] tmpPhoneArr = StringUtils.splitByWholeSeparator(phone, ",");
            for(String tmpPhone : tmpPhoneArr){
                phoneList.add(tmpPhone);
            }
        }else{
            resObj.setResCode(ResponseObj.FAILED);
            resObj.setResMsg("phone参数不能为空");
            LOG.error("getAgentAccountInfoTwo, phone参数不能为空");
            return resObj;
        }

        params.put("phoneList", phoneList);

        List<Map<String, Object>> dataList = apiService.getAgentAccountInfoTwo(params);

        resObj.setResData(dataList);

        return resObj;
    }
    
    @ResponseBody
    @RequestMapping(value = "/getAccountReportCurrent", method=RequestMethod.POST)
    @ApiOperation(value="查询当期财务对账数据接口", notes="查询当期财务对账数据接口")
    @ApiImplicitParams({
    	@ApiImplicitParam(paramType="query",name="phone",dataType="String",required=false,value="格式:13480877165,13480877165"),
    	@ApiImplicitParam(paramType="query",name="aid",dataType="String",required=false,value="代理商ID"),
    	@ApiImplicitParam(paramType="query",name="startDate",dataType="String",required=false,value="格式:YYYY-MM-DD"),
    	@ApiImplicitParam(paramType="query",name="endDate",dataType="String",required=false,value="格式:YYYY-MM-DD"),
    	@ApiImplicitParam(paramType="query",name="start",dataType="String",required=false,value="开始记录数"),
    	@ApiImplicitParam(paramType="query",name="limit",dataType="String",required=false,value="查询条数")
    })
    public ResponseObj getAccountReportCurrent(HttpServletRequest request, HttpServletResponse response) throws Exception {
    	ResponseObj resObj = new ResponseObj();
    	resObj.setResCode(ResponseObj.SUCCESS);
    	
    	Map<String, Object> params = new HashMap<String, Object>();
    	
    	String phone = request.getParameter("phone");
    	String aid = request.getParameter("aid");
    	String start = request.getParameter("start");
    	String limit = request.getParameter("limit");
    	String startDate = request.getParameter("startDate");
    	String endDate = request.getParameter("endDate");
    	
    	int beginPage = 0;
    	int endPage = 20;
    	
    	if(StringUtils.isNotEmpty(start)){
			try {
				beginPage = Integer.parseInt(start);
			} catch (Exception e) {
				resObj.setResCode(ResponseObj.FAILED);
				resObj.setResMsg("开始记录数只能传数字");
				return resObj;
			}
		}
    	
    	if(StringUtils.isNotEmpty(limit)){
    		
    		try {
    			endPage = beginPage + Integer.parseInt(limit);
			} catch (Exception e) {
				resObj.setResCode(ResponseObj.FAILED);
				resObj.setResMsg("查询条数只能传数字");
				return resObj;
			}
    		
    	}
    	
    	if(StringUtils.isNotEmpty(startDate)){
    		try {
    			sdf.parse(startDate);
    		} catch (Exception e) {
    			resObj.setResCode(ResponseObj.FAILED);
    			resObj.setResMsg("开始时间格式错误");
    			return resObj;
    		}
    	}
    	
    	if(StringUtils.isNotEmpty(endDate)){
    		try {
    			sdf.parse(endDate);
    		} catch (Exception e) {
    			resObj.setResCode(ResponseObj.FAILED);
    			resObj.setResMsg("结束时间格式错误");
    			return resObj;
    		}
    	}
    	
    	params.put("phone", phone);
    	params.put("aid", aid);
    	params.put("beginPage", beginPage);
    	params.put("endPage", endPage);
    	params.put("startDate", startDate + " 00:00:00");
    	params.put("endDate", endDate + " 23:59:59");
    	
    	List<Map<String, Object>> dataList = apiService.queryAccountReportCurrentList(params);
    	
    	resObj.setResData(dataList);
    	
    	return resObj;
    }
    
    @ResponseBody
    @RequestMapping(value = "/getAccountReport", method=RequestMethod.POST)
    @ApiOperation(value="查询财务对账数据接口", notes="查询财务对账数据接口")
    @ApiImplicitParams({
    	@ApiImplicitParam(paramType="query",name="phone",dataType="String",required=false,value="格式:13480877165,13480877165"),
    	@ApiImplicitParam(paramType="query",name="aid",dataType="String",required=false,value="代理商ID"),
    	@ApiImplicitParam(paramType="query",name="startDate",dataType="String",required=false,value="格式:YYYY-MM-DD"),
    	@ApiImplicitParam(paramType="query",name="endDate",dataType="String",required=false,value="格式:YYYY-MM-DD"),
    	@ApiImplicitParam(paramType="query",name="start",dataType="String",required=false,value="开始记录数"),
    	@ApiImplicitParam(paramType="query",name="limit",dataType="String",required=false,value="查询条数")
    })
    public ResponseObj getAccountReport(HttpServletRequest request, HttpServletResponse response) throws Exception {
    	ResponseObj resObj = new ResponseObj();
    	resObj.setResCode(ResponseObj.SUCCESS);
    	
    	Map<String, Object> params = new HashMap<String, Object>();
    	
    	String phone = request.getParameter("phone");
    	String aid = request.getParameter("aid");
    	String start = request.getParameter("start");
    	String limit = request.getParameter("limit");
    	String startDate = request.getParameter("startDate");
    	String endDate = request.getParameter("endDate");
    	
    	int beginPage = 0;
    	int endPage = 20;
    	
    	if(StringUtils.isEmpty(aid) && StringUtils.isEmpty(phone)){
    		
    		resObj.setResCode(ResponseObj.FAILED);
			resObj.setResMsg("代理商id或手机号，必需填一个");
			return resObj;
    		
    	}
    	
    	if(StringUtils.isNotEmpty(startDate)){
    		try {
    			sdf.parse(startDate);
    		} catch (Exception e) {
    			resObj.setResCode(ResponseObj.FAILED);
    			resObj.setResMsg("开始时间格式错误");
    			return resObj;
    		}
    	}
    	
    	if(StringUtils.isNotEmpty(endDate)){
    		try {
    			sdf.parse(endDate);
    		} catch (Exception e) {
    			resObj.setResCode(ResponseObj.FAILED);
    			resObj.setResMsg("结束时间格式错误");
    			return resObj;
    		}
    	}
    	
    	if(StringUtils.isNotEmpty(start)){
    		try {
    			beginPage = Integer.parseInt(start);
    		} catch (Exception e) {
    			resObj.setResCode(ResponseObj.FAILED);
    			resObj.setResMsg("开始记录数只能传数字");
    			return resObj;
    		}
    	}
    	
    	if(StringUtils.isNotEmpty(limit)){
    		
    		try {
    			endPage = beginPage + Integer.parseInt(limit);
    		} catch (Exception e) {
    			resObj.setResCode(ResponseObj.FAILED);
    			resObj.setResMsg("查询条数只能传数字");
    			return resObj;
    		}
    		
    	}
    	
    	params.put("phone", phone);
    	params.put("aid", aid);
    	params.put("beginPage", beginPage);
    	params.put("endPage", endPage);
    	params.put("startDate", startDate);
    	params.put("endDate", endDate);
    	
    	List<Map<String, Object>> dataList = apiService.queryAccountReportList(params);
    	
    	resObj.setResData(dataList);
    	
    	return resObj;
    }
    
    @ResponseBody
    @RequestMapping(value = "/getAccountReportTotail", method=RequestMethod.POST)
    @ApiOperation(value="查询财务对账数据汇总接口", notes="查询财务对账数据汇总接口")
    @ApiImplicitParams({
    	@ApiImplicitParam(paramType="query",name="startDate",dataType="date",required=false,value="格式:YYYY-MM-DD"),
    	@ApiImplicitParam(paramType="query",name="endDate",dataType="date",required=false,value="格式:YYYY-MM-DD"),
    })
    public ResponseObj getAccountReportTotail(HttpServletRequest request, HttpServletResponse response) throws Exception {
    	ResponseObj resObj = new ResponseObj();
    	resObj.setResCode(ResponseObj.SUCCESS);
    	
    	Map<String, Object> params = new HashMap<String, Object>();
    	
    	String startDate = request.getParameter("startDate");
    	String endDate = request.getParameter("endDate");
    	
    	if(StringUtils.isNotEmpty(startDate)){
    		try {
    			sdf.parse(startDate);
    		} catch (Exception e) {
    			resObj.setResCode(ResponseObj.FAILED);
    			resObj.setResMsg("开始时间格式错误");
    			return resObj;
    		}
    	}
    	
    	if(StringUtils.isNotEmpty(endDate)){
    		try {
    			sdf.parse(endDate);
    		} catch (Exception e) {
    			resObj.setResCode(ResponseObj.FAILED);
    			resObj.setResMsg("结束时间格式错误");
    			return resObj;
    		}
    	}
    	
    	params.put("start_date", startDate + " 00:00:00");
    	params.put("end_date", endDate + " 23:59:59");
    	
    	Map<String, Object> dataList = apiService.queryAccountReportTotail(params);
    	
    	resObj.setResData(dataList);
    	
    	return resObj;
    }
    
    @ResponseBody
    @RequestMapping(value = "/queryLotteryRegisteredUsersCount", method=RequestMethod.POST)
    @ApiOperation(value="查询彩票注册用户数接口", notes="查询彩票注册用户数")
    @ApiImplicitParams({
    	@ApiImplicitParam(paramType="query",name="startDate",dataType="String",required=false,value="格式:YYYY-MM-DD"),
    	@ApiImplicitParam(paramType="query",name="endDate",dataType="String",required=false,value="格式:YYYY-MM-DD"),
    	@ApiImplicitParam(paramType="query",name="start",dataType="String",required=false,value="开始记录数"),
    	@ApiImplicitParam(paramType="query",name="limit",dataType="String",required=false,value="查询条数"),
    })
    public ResponseObj queryLotteryRegisteredUsersCount(HttpServletRequest request, HttpServletResponse response) throws Exception {
    	ResponseObj resObj = new ResponseObj();
    	resObj.setResCode(ResponseObj.SUCCESS);
    	
    	Map<String, Object> params = new HashMap<String, Object>();
    	
    	String startDate = request.getParameter("startDate");
    	String endDate = request.getParameter("endDate");
    	String start = request.getParameter("start");
    	String limit = request.getParameter("limit");
    	
    	int beginPage = 0;
    	int endPage = 20;
    	
    	if(StringUtils.isNotEmpty(startDate)){
    		try {
    			sdf.parse(startDate);
    		} catch (Exception e) {
    			resObj.setResCode(ResponseObj.FAILED);
    			resObj.setResMsg("开始时间格式错误");
    			return resObj;
    		}
    	}
    	
    	if(StringUtils.isNotEmpty(endDate)){
    		try {
    			sdf.parse(endDate);
    		} catch (Exception e) {
    			resObj.setResCode(ResponseObj.FAILED);
    			resObj.setResMsg("结束时间格式错误");
    			return resObj;
    		}
    	}
    	
    	if(StringUtils.isNotEmpty(start)){
    		try {
    			beginPage = Integer.parseInt(start);
    		} catch (Exception e) {
    			resObj.setResCode(ResponseObj.FAILED);
    			resObj.setResMsg("开始记录数只能传数字");
    			return resObj;
    		}
    	}
    	
    	if(StringUtils.isNotEmpty(limit)){
    		
    		try {
    			endPage = beginPage + Integer.parseInt(limit);
    		} catch (Exception e) {
    			resObj.setResCode(ResponseObj.FAILED);
    			resObj.setResMsg("查询条数只能传数字");
    			return resObj;
    		}
    		
    	}
    	
    	params.put("start_date", startDate + " 00:00:00");
    	params.put("end_date", endDate + " 23:59:59");
    	params.put("beginPage", beginPage);
    	params.put("endPage", endPage);
    	
    	List<Map<String, Object>> dataList = apiService.queryLotteryRegisteredUsersCount(params);
    	
    	resObj.setResData(dataList);
    	
    	return resObj;
    }
    
    @ResponseBody
    @RequestMapping(value = "/queryLotteryRegisteredUsers", method=RequestMethod.POST)
    @ApiOperation(value="查询彩票注册用户编码接口", notes="查询彩票注册用户编码")
    @ApiImplicitParams({
    	@ApiImplicitParam(paramType="query",name="phone",dataType="String",required=false,value="格式:13249818208"),
    	@ApiImplicitParam(paramType="query",name="channel_phone",dataType="String",required=false,value="格式:13249818208"),
    	@ApiImplicitParam(paramType="query",name="startDate",dataType="String",required=false,value="格式:YYYY-MM-DD"),
    	@ApiImplicitParam(paramType="query",name="endDate",dataType="String",required=false,value="格式:YYYY-MM-DD"),
    })
    public ResponseObj queryLotteryRegisteredUsers(HttpServletRequest request, HttpServletResponse response) throws Exception {
    	ResponseObj resObj = new ResponseObj();
    	resObj.setResCode(ResponseObj.SUCCESS);
    	
    	Map<String, Object> params = new HashMap<String, Object>();
    	
    	String phone = request.getParameter("phone");
    	String channel_phone = request.getParameter("channel_phone");
    	String startDate = request.getParameter("startDate");
    	String endDate = request.getParameter("endDate");
    	
    	if(StringUtils.isNotEmpty(startDate)){
    		try {
    			sdf.parse(startDate);
    		} catch (Exception e) {
    			resObj.setResCode(ResponseObj.FAILED);
    			resObj.setResMsg("开始时间格式错误");
    			return resObj;
    		}
    	}
    	
    	if(StringUtils.isNotEmpty(endDate)){
    		try {
    			sdf.parse(endDate);
    		} catch (Exception e) {
    			resObj.setResCode(ResponseObj.FAILED);
    			resObj.setResMsg("结束时间格式错误");
    			return resObj;
    		}
    	}
    	
    	params.put("phone", phone);
    	params.put("channel_phone", channel_phone);
    	params.put("start_date", startDate + " 00:00:00");
    	params.put("end_date", endDate + " 23:59:59");
    	
    	List<Map<String, Object>> dataList = apiService.queryLotteryRegisteredUsersList(params);
    	
    	resObj.setResData(dataList);
    	
    	return resObj;
    }
    
    @ResponseBody
    @RequestMapping(value = "/queryValidRegisteredUsersCount", method=RequestMethod.POST)
    @ApiOperation(value="查询有效注册用户数接口", notes="查询有效注册用户数")
    @ApiImplicitParams({
    	@ApiImplicitParam(paramType="query",name="startDate",dataType="String",required=false,value="格式:YYYY-MM-DD"),
    	@ApiImplicitParam(paramType="query",name="endDate",dataType="String",required=false,value="格式:YYYY-MM-DD"),
    	@ApiImplicitParam(paramType="query",name="start",dataType="String",required=false,value="开始记录数"),
    	@ApiImplicitParam(paramType="query",name="limit",dataType="String",required=false,value="查询条数"),
    })
    public ResponseObj queryValidRegisteredUsersCount(HttpServletRequest request, HttpServletResponse response) throws Exception {
    	ResponseObj resObj = new ResponseObj();
    	resObj.setResCode(ResponseObj.SUCCESS);
    	
    	Map<String, Object> params = new HashMap<String, Object>();
    	
    	String startDate = request.getParameter("startDate");
    	String endDate = request.getParameter("endDate");
    	String start = request.getParameter("start");
    	String limit = request.getParameter("limit");
    	
    	int beginPage = 0;
    	int endPage = 20;
    	
    	if(StringUtils.isNotEmpty(startDate)){
    		try {
    			sdf.parse(startDate);
    		} catch (Exception e) {
    			resObj.setResCode(ResponseObj.FAILED);
    			resObj.setResMsg("开始时间格式错误");
    			return resObj;
    		}
    	}
    	
    	if(StringUtils.isNotEmpty(endDate)){
    		try {
    			sdf.parse(endDate);
    		} catch (Exception e) {
    			resObj.setResCode(ResponseObj.FAILED);
    			resObj.setResMsg("结束时间格式错误");
    			return resObj;
    		}
    	}
    	
    	if(StringUtils.isNotEmpty(start)){
    		try {
    			beginPage = Integer.parseInt(start);
    		} catch (Exception e) {
    			resObj.setResCode(ResponseObj.FAILED);
    			resObj.setResMsg("开始记录数只能传数字");
    			return resObj;
    		}
    	}
    	
    	if(StringUtils.isNotEmpty(limit)){
    		
    		try {
    			endPage = beginPage + Integer.parseInt(limit);
    		} catch (Exception e) {
    			resObj.setResCode(ResponseObj.FAILED);
    			resObj.setResMsg("查询条数只能传数字");
    			return resObj;
    		}
    		
    	}
    	
    	params.put("start_date", startDate + " 00:00:00");
    	params.put("end_date", endDate + " 23:59:59");
    	params.put("beginPage", beginPage);
    	params.put("endPage", endPage);
    	
    	List<Map<String, Object>> dataList = apiService.queryValidRegisteredUsersCount(params);
    	
    	resObj.setResData(dataList);
    	
    	return resObj;
    }
    
    @ResponseBody
    @RequestMapping(value = "/queryValidRegisteredUsers", method=RequestMethod.POST)
    @ApiOperation(value="查询有效注册用户编码接口", notes="查询有效注册用户编码")
    @ApiImplicitParams({
    	@ApiImplicitParam(paramType="query",name="phone",dataType="String",required=false,value="格式:13249818208"),
    	@ApiImplicitParam(paramType="query",name="channel_phone",dataType="String",required=false,value="格式:13249818208"),
    	@ApiImplicitParam(paramType="query",name="startDate",dataType="String",required=false,value="格式:YYYY-MM-DD"),
    	@ApiImplicitParam(paramType="query",name="endDate",dataType="String",required=false,value="格式:YYYY-MM-DD"),
    })
    public ResponseObj queryValidRegisteredUsers(HttpServletRequest request, HttpServletResponse response) throws Exception {
    	ResponseObj resObj = new ResponseObj();
    	resObj.setResCode(ResponseObj.SUCCESS);
    	
    	Map<String, Object> params = new HashMap<String, Object>();
    	
    	String phone = request.getParameter("phone");
    	String channel_phone = request.getParameter("channel_phone");
    	String startDate = request.getParameter("startDate");
    	String endDate = request.getParameter("endDate");
    	
    	if(StringUtils.isNotEmpty(startDate)){
    		try {
    			sdf.parse(startDate);
    		} catch (Exception e) {
    			resObj.setResCode(ResponseObj.FAILED);
    			resObj.setResMsg("开始时间格式错误");
    			return resObj;
    		}
    	}
    	
    	if(StringUtils.isNotEmpty(endDate)){
    		try {
    			sdf.parse(endDate);
    		} catch (Exception e) {
    			resObj.setResCode(ResponseObj.FAILED);
    			resObj.setResMsg("结束时间格式错误");
    			return resObj;
    		}
    	}
    	
    	params.put("phone", phone);
    	params.put("channel_phone", channel_phone);
    	params.put("start_date", startDate + " 00:00:00");
    	params.put("end_date", endDate + " 23:59:59");
    	
    	List<Map<String, Object>> dataList = apiService.queryValidRegisteredUsers(params);
    	
    	resObj.setResData(dataList);
    	
    	return resObj;
    }

}
