package com.cornu.report.dao.mapper;

import java.util.Map;

public interface StatMapper {
	public void addBasicData(Map<String,Object> basicData);
	public void updateBasicData(Map<String,Object> basicData);
	
	public void addMixBasicData(Map<String,Object> basicData);
	public void updateMixBasicData(Map<String,Object> basicData);
	
	public void addDetailBasicData(Map<String,Object> basicData);
	public void updateDetailBasicData(Map<String,Object> basicData);
	
	public void updateHeadmanCommissionMoney(Map<String,Object> basicData);
	
	public void updateHeadmanCommissionMoneyByDate(Map<String,Object> basicData);
	
	public void saveAccountReport(Map<String,Object> basicData);
	public void updateAccountReport(Map<String,Object> basicData);
}
