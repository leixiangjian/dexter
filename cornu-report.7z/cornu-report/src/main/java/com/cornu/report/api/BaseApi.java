package com.cornu.report.api;

import java.text.SimpleDateFormat;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cornu.report.service.BasicDataService;
import com.cornu.report.service.PhoneBlackListServiceImpl;
import com.cornu.report.service.RefreshPromotersIncomeService;
import com.cornu.report.service.RefreshValidAgentService;

@RequestMapping("/stat")
public class BaseApi {
	@Autowired(required = true)
	@Qualifier(value = "basicDataService")
	BasicDataService basicDataService;

	@Autowired(required = true)
	@Qualifier(value = "refreshValidAgentService")
	RefreshValidAgentService refreshValidAgentService;

	@Autowired(required = true)
	@Qualifier(value = "refreshPromotersIncomeService")
	RefreshPromotersIncomeService refreshPromotersIncomeService;
	
	@Autowired(required = true)
	@Qualifier(value = "phoneBlackListService")
	PhoneBlackListServiceImpl phoneBlackListServiceImpl;

	static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
}
