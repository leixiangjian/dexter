package com.cornu.report.dao.bean;

public class ChannelEntity {
	private String channelcd;
	private String channelname;

	public String getChannelcd() {
		return channelcd;
	}

	public void setChannelcd(String channelcd) {
		this.channelcd = channelcd;
	}

	public String getChannelname() {
		return channelname;
	}

	public void setChannelname(String channelname) {
		this.channelname = channelname;
	}

}
