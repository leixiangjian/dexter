package com.cornu.report.service;

import com.alibaba.fastjson.JSONArray;
import com.cornu.report.dao.bean.AgentEntity;
import com.cornu.report.dao.bean.ChannelEntity;
import com.cornu.report.dao.bean.TransactionEntity;

import com.mongodb.WriteResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.springframework.data.mongodb.core.query.Criteria.where;

/**
 * Created by Dell on 2017/6/27.
 */
@Service("refreshValidAgentService")
public class RefreshValidAgentService {
    private static final Logger LOG = LoggerFactory.getLogger(RefreshValidAgentService.class);

    @Autowired
    MongoTemplate mongoTemplate;

    public void refreshValidAgent() throws Exception{
        //查询所有具备channelcd的代理员数据
        //循环代理员、根据代理员aid查询transaction（recharge=0）按时间升序计算是否是否注册人数大于等于5人，大于等于5人在标记isValid=1，validTime=第五个人的注册时间
        //所有渠道
        List<ChannelEntity> channelEntitys = mongoTemplate.findAll(ChannelEntity.class,
                "channel_info");
            for(ChannelEntity channelEntity : channelEntitys) {
            String channelCd = channelEntity.getChannelcd();

            Query query = new Query();
            query.addCriteria(where("channelcd").is(channelCd));

            List<AgentEntity> agentEntitys = mongoTemplate.find(query, AgentEntity.class, "agent");
            for (AgentEntity agentEntity : agentEntitys) {
                judgeAgentIsValid(agentEntity);
            }
        }
    }

    /**
     * 判断代理员是否为有效代理
     */
    public void judgeAgentIsValid(AgentEntity agentEntity) throws Exception{
        //查询应用所有的注册人数
        Query appRegQuery = new Query();
        appRegQuery.addCriteria(where("aid").is(agentEntity.getAid()));
        appRegQuery.addCriteria(where("recharge").is(0));
        appRegQuery.with(new Sort(new Sort.Order(Sort.Direction.ASC, "ctime")));
        List<TransactionEntity> appRegtransactionEntitys = mongoTemplate.find(appRegQuery, TransactionEntity.class, "transaction");
        Map<String, Object> newCpRegNum = new HashMap<String, Object>();
        for(TransactionEntity transactionEntity : appRegtransactionEntitys){
            String uid = transactionEntity.getUid();
            long regTime = transactionEntity.getOtime();
            newCpRegNum.put(uid, regTime);
            if(newCpRegNum != null && newCpRegNum.size() >= 5){
                Query query = new Query();
                query.addCriteria(new Criteria("aid").is(agentEntity.getAid()));
                Update update = new Update();
                update.set("isValid", "1");//isValid:0不是有效,1有效
                update.set("validTime", regTime);//validTime:时间long

                this.mongoTemplate.updateFirst(query, update, "agent");
                LOG.info("有效代理员为="+agentEntity.getAid());
                break;
            }
        }
    }

    /**
     * 刷新有效注册用户
     * @throws Exception
     */
    public void refreshValidRegUser() throws Exception{
        //查询所有具备channelcd的代理员数据
        //循环代理员、根据代理员aid查询transaction（recharge>0）按时间升序找到有效用户时间，刷下为有效用户
        //所有渠道
        List<ChannelEntity> channelEntitys = mongoTemplate.findAll(ChannelEntity.class,
                "channel_info");
            for(ChannelEntity channelEntity : channelEntitys) {
            String channelCd = channelEntity.getChannelcd();

            Query query = new Query();
            query.addCriteria(where("channelcd").is(channelCd));

            List<AgentEntity> agentEntitys = mongoTemplate.find(query, AgentEntity.class, "agent");
            for (AgentEntity agentEntity : agentEntitys) {
            	judgeUserIsValid(agentEntity);
            }
        }
    }
    
    /**
     * 判断是否为有效用户
     */
    public void judgeUserIsValid(AgentEntity agentEntity) throws Exception{
    	//查询应用所有的有效注册人数
    	Query appRegQuery = new Query();
    	appRegQuery.addCriteria(where("aid").is(agentEntity.getAid()));
    	appRegQuery.addCriteria(where("recharge").gt(0));
    	List<TransactionEntity> appRegtransactionEntitys = mongoTemplate.find(appRegQuery, TransactionEntity.class, "transaction");
    	if(null != appRegtransactionEntitys && appRegtransactionEntitys.size() > 0){
    		
    		Set<String> uids = new HashSet<String>();
    		for(TransactionEntity transactionEntity : appRegtransactionEntitys){
    			
    			uids.add(transactionEntity.getUid());
    			
    		}
    		
    		for (String uid : uids) {
				
    			Query timeQuery = new Query();
    			timeQuery.addCriteria(where("aid").is(agentEntity.getAid()));
                timeQuery.addCriteria(where("recharge").gt(0));
    			timeQuery.addCriteria(where("uid").is(uid));
    			timeQuery.with(new Sort(new Sort.Order(Sort.Direction.ASC, "ctime")));
    			List<TransactionEntity> timeRegtransactionEntitys = mongoTemplate.find(timeQuery, TransactionEntity.class, "transaction");
    			
    			long regTime = timeRegtransactionEntitys.get(0).getOtime();

                //查询这个aid、这个uid是否已经是有效注册用户，如果是则不需要再标记。
                Query queryValidReg = new Query();
                queryValidReg.addCriteria(new Criteria("aid").is(agentEntity.getAid()));
                queryValidReg.addCriteria(new Criteria("uid").is(timeRegtransactionEntitys.get(0).getUid()));
                queryValidReg.addCriteria(new Criteria("isValid").is("1"));
                queryValidReg.addCriteria(new Criteria("channelcd").is(agentEntity.getChannelcd()));
                List<TransactionEntity> validRegEntitys = mongoTemplate.find(queryValidReg, TransactionEntity.class, "transaction");
                if(validRegEntitys != null && validRegEntitys.size() > 0){
                    LOG.warn("刷新有效注册用户数据, 有效注册用户={}, 渠道={}, 代理员={}, 该购彩用户已经是有效注册用户,不需要再标记!",
                            uid, agentEntity.getChannelcd(), agentEntity.getAid());
                    continue;
                }

    			Query query = new Query();
    			query.addCriteria(new Criteria("aid").is(agentEntity.getAid()));
    			query.addCriteria(new Criteria("uid").is(timeRegtransactionEntitys.get(0).getUid()));
    			query.addCriteria(new Criteria("oid").is(timeRegtransactionEntitys.get(0).getUid()));
    			query.addCriteria(new Criteria("recharge").is(0));

    			Update update = new Update();
    			update.set("isValid", "1");//isValid:0不是有效,1有效
    			update.set("validTime", regTime);//validTime:时间long
    			update.set("channelcd", agentEntity.getChannelcd());	//渠道

                WriteResult writeResult = mongoTemplate.updateFirst(query, update, "transaction");
                if(writeResult != null && writeResult.getN() == 0){//表示没有彩票用户注册流水，则需要在该彩票用户第一次购彩的订单流水上进行标记。
                    LOG.error("刷新有效注册用户数据, 有效注册用户={}, 渠道={}, 代理员={}, transaction中不存在该彩票用户的注册流水",
                            uid, agentEntity.getChannelcd(), agentEntity.getAid());
                    Query queryAgain = new Query();
                    queryAgain.addCriteria(new Criteria("aid").is(agentEntity.getAid()));
                    queryAgain.addCriteria(new Criteria("uid").is(timeRegtransactionEntitys.get(0).getUid()));
                    queryAgain.addCriteria(new Criteria("oid").is(timeRegtransactionEntitys.get(0).getOid()));
                    queryAgain.addCriteria(where("recharge").gt(0));
                    Update updateAgain = new Update();
                    updateAgain.set("isValid", "1");//isValid:0不是有效,1有效
                    updateAgain.set("validTime", regTime);//validTime:时间long
                    updateAgain.set("channelcd", agentEntity.getChannelcd());	//渠道

                    WriteResult writeResultAgain = mongoTemplate.updateFirst(queryAgain, updateAgain, "transaction");
                    if(writeResultAgain != null && writeResultAgain.getN() == 0){
                        LOG.error("刷新有效注册用户数据, 有效注册用户={}, 渠道={}, 代理员={}, transaction中不存在该彩票用户的注册流水时, 标记第一次购彩流水未成功",
                                uid, agentEntity.getChannelcd(), agentEntity.getAid());
                    }else{
                        LOG.info("刷新有效注册用户数据成功, 有效注册用户={}, 渠道={}, 代理员={}, transaction中不存在该彩票用户的注册流水, 标记第一次购彩流水成功",
                                uid, agentEntity.getChannelcd(), agentEntity.getAid());
                    }
                }else{
                    LOG.info("刷新有效注册用户数据成功, 有效注册用户={}, 渠道={}, 代理员={}", uid, agentEntity.getChannelcd(), agentEntity.getAid());
                }
			}
    		
    	}
    }

    /**
     * 设置有效注册用户
     * @throws Exception
     */
    public void setValidRegUser() throws Exception{
        //查询所有具备channelcd的代理员数据
        //循环代理员、根据代理员aid查询transaction（recharge>0）按时间升序找到有效用户时间，刷下为有效用户
        //所有渠道
        List<ChannelEntity> channelEntitys = mongoTemplate.findAll(ChannelEntity.class,
                "channel_info");
        for(ChannelEntity channelEntity : channelEntitys) {
            String channelCd = channelEntity.getChannelcd();

            Query query = new Query();
            query.addCriteria(where("channelcd").is(channelCd));

            List<AgentEntity> agentEntitys = mongoTemplate.find(query, AgentEntity.class, "agent");
            for (AgentEntity agentEntity : agentEntitys) {
                judgeUserIsValidBySetValidRegUser(agentEntity);
            }
        }
    }

    /**
     * 设置有效注册用户判断是否为有效用户
     */
    public void judgeUserIsValidBySetValidRegUser(AgentEntity agentEntity) throws Exception{
        //查询 已标记用户集合
        Query validUserQuery = new Query();
        validUserQuery.addCriteria(where("aid").is(agentEntity.getAid()));
        validUserQuery.addCriteria(new Criteria("isValid").is("1"));
        List<TransactionEntity> validUserEntitys = mongoTemplate.find(validUserQuery, TransactionEntity.class, "transaction");
        Set<String> validUids = new HashSet<String>();
        if(null != validUserEntitys && validUserEntitys.size() > 0){

            for (TransactionEntity validUserEntity : validUserEntitys) {

                validUids.add(validUserEntity.getUid());

            }

        }

        /*LOG.warn("设置有效注册用户数据, 有效注册用户集合={}, 渠道={}, 代理员={}, 该批购彩用户已经是有效注册用户,不需要再标记!",
                JSONArray.toJSONString(validUids), agentEntity.getChannelcd(), agentEntity.getAid());*/

        //查询应用所有的有效注册人数
        Query appRegQuery = new Query();
        appRegQuery.addCriteria(where("aid").is(agentEntity.getAid()));
        appRegQuery.addCriteria(where("uid").nin(validUids));
        appRegQuery.addCriteria(where("recharge").gt(0));
        List<TransactionEntity> appRegtransactionEntitys = mongoTemplate.find(appRegQuery, TransactionEntity.class, "transaction");
        if(null != appRegtransactionEntitys && appRegtransactionEntitys.size() > 0){

            Set<String> uids = new HashSet<String>();
            for(TransactionEntity transactionEntity : appRegtransactionEntitys){

                uids.add(transactionEntity.getUid());

            }

            for (String uid : uids) {

                Query timeQuery = new Query();
                timeQuery.addCriteria(where("aid").is(agentEntity.getAid()));
                timeQuery.addCriteria(where("recharge").gt(0));
                timeQuery.addCriteria(where("uid").is(uid));
                timeQuery.with(new Sort(new Sort.Order(Sort.Direction.ASC, "ctime")));
                List<TransactionEntity> timeRegtransactionEntitys = mongoTemplate.find(timeQuery, TransactionEntity.class, "transaction");

                long regTime = timeRegtransactionEntitys.get(0).getOtime();

                //查询这个aid、这个uid是否已经是有效注册用户，如果是则不需要再标记。
                Query queryValidReg = new Query();
                queryValidReg.addCriteria(new Criteria("aid").is(agentEntity.getAid()));
                queryValidReg.addCriteria(new Criteria("uid").is(timeRegtransactionEntitys.get(0).getUid()));
                queryValidReg.addCriteria(new Criteria("isValid").is("1"));
                queryValidReg.addCriteria(new Criteria("channelcd").is(agentEntity.getChannelcd()));
                List<TransactionEntity> validRegEntitys = mongoTemplate.find(queryValidReg, TransactionEntity.class, "transaction");
                if(validRegEntitys != null && validRegEntitys.size() > 0){
                    LOG.warn("设置有效注册用户数据, 有效注册用户={}, 渠道={}, 代理员={}, 该购彩用户已经是有效注册用户,不需要再标记!",
                            uid, agentEntity.getChannelcd(), agentEntity.getAid());
                    continue;
                }

                Query query = new Query();
                query.addCriteria(new Criteria("aid").is(agentEntity.getAid()));
                query.addCriteria(new Criteria("uid").is(timeRegtransactionEntitys.get(0).getUid()));
                query.addCriteria(new Criteria("oid").is(timeRegtransactionEntitys.get(0).getUid()));
                query.addCriteria(new Criteria("recharge").is(0));

                Update update = new Update();
                update.set("isValid", "1");//isValid:0不是有效,1有效
                update.set("validTime", regTime);//validTime:时间long
                update.set("channelcd", agentEntity.getChannelcd());	//渠道

                WriteResult writeResult = mongoTemplate.updateFirst(query, update, "transaction");
                if(writeResult != null && writeResult.getN() == 0){//表示没有彩票用户注册流水，则需要在该彩票用户第一次购彩的订单流水上进行标记。
                    LOG.error("设置有效注册用户数据, 有效注册用户={}, 渠道={}, 代理员={}, transaction中不存在该彩票用户的注册流水",
                            uid, agentEntity.getChannelcd(), agentEntity.getAid());
                    Query queryAgain = new Query();
                    queryAgain.addCriteria(new Criteria("aid").is(agentEntity.getAid()));
                    queryAgain.addCriteria(new Criteria("uid").is(timeRegtransactionEntitys.get(0).getUid()));
                    queryAgain.addCriteria(new Criteria("oid").is(timeRegtransactionEntitys.get(0).getOid()));
                    queryAgain.addCriteria(where("recharge").gt(0));
                    Update updateAgain = new Update();
                    updateAgain.set("isValid", "1");//isValid:0不是有效,1有效
                    updateAgain.set("validTime", regTime);//validTime:时间long
                    updateAgain.set("channelcd", agentEntity.getChannelcd());	//渠道

                    WriteResult writeResultAgain = mongoTemplate.updateFirst(queryAgain, updateAgain, "transaction");
                    if(writeResultAgain != null && writeResultAgain.getN() == 0){
                        LOG.error("设置有效注册用户数据, 有效注册用户={}, 渠道={}, 代理员={}, transaction中不存在该彩票用户的注册流水时, 标记第一次购彩流水未成功",
                                uid, agentEntity.getChannelcd(), agentEntity.getAid());
                    }else{
                        LOG.info("设置有效注册用户数据成功, 有效注册用户={}, 渠道={}, 代理员={}, transaction中不存在该彩票用户的注册流水, 标记第一次购彩流水成功",
                                uid, agentEntity.getChannelcd(), agentEntity.getAid());
                    }
                }else{
                    LOG.info("设置有效注册用户数据成功, 有效注册用户={}, 渠道={}, 代理员={}", uid, agentEntity.getChannelcd(), agentEntity.getAid());
                }
            }

        }
    }

}
