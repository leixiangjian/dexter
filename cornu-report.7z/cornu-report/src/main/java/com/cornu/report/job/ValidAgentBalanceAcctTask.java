package com.cornu.report.job;

import com.cornu.report.service.BasicDataService;
import com.cornu.report.service.ValidAgentBalanceAcctService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;


/**
 * Created by Dell on 2017/7/10.
 * 有效代理费用结算JOB
 */
@Component("validAgentBalanceAcctTask")
public class ValidAgentBalanceAcctTask {
    private static final Logger LOG = LoggerFactory.getLogger(ValidAgentBalanceAcctTask.class);

    @Autowired(required = true)
    @Qualifier(value = "validAgentBalanceAcctService")
    ValidAgentBalanceAcctService validAgentBalanceAcctService;

    @Value("${validagent.balanceacct.enabled}")
    String enabled;

    public void validAgentBalanceAcct() {
        try {
            if(!Boolean.parseBoolean(enabled)){
                return;
            }

            validAgentBalanceAcctService.validAgentBalanceAcct();
            LOG.info("thread={}, 有效代理费用结算JOB, running......", Thread.currentThread().getId());
        } catch (Exception e) {
            LOG.error("thread={}, 有效代理费用结算JOB异常", Thread.currentThread().getId(), e);
        }
    }
}
