package com.cornu.report.api;

import com.cornu.report.response.ResponseObj;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by Dell on 2017/7/3.
 * 刷新渠道收益数据
 */
@Controller
@Api("刷新渠道收益数据")
public class RefreshPromotersIncome extends BaseApi{
    private static final Logger LOG = LoggerFactory.getLogger(RefreshPromotersIncome.class);

    /*@ResponseBody
    @RequestMapping(value = "/refreshPromotersIncome", method = RequestMethod.POST)
    @ApiOperation(value = "刷新渠道收益数据接口", notes = "刷新渠道收益数据接口")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "query", name = "bDate", dataType = "String", required = true, value = "开始日期，格式:YYYY-MM-DD"),
            @ApiImplicitParam(paramType = "query", name = "eDate", dataType = "String", required = true, value = "结束日期，格式:YYYY-MM-DD"),
            @ApiImplicitParam(paramType = "query", name = "channelcd", dataType = "String", required = false, value = "渠道编码，格式:LW0096,LW0022(所有渠道:ALL)")
    })
    public ResponseObj refreshPromotersIncome(HttpServletRequest request, HttpServletResponse response) {
        ResponseObj responseObj = new ResponseObj();
        responseObj.setResCode(ResponseObj.FAILED);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        try {
            Map<String, Object> params = new HashMap<String, Object>();

            String alanDate = sdf.format(new Date());
            Long today = Long.valueOf(alanDate);

            String bDate = request.getParameter("bDate");
            if(StringUtils.isBlank(bDate)){
                responseObj.setResCode(ResponseObj.FAILED);
                responseObj.setResMsg("bDate参数为空");
                return responseObj;
            }

            String eDate = request.getParameter("eDate");
            if(StringUtils.isBlank(eDate)){
                responseObj.setResCode(ResponseObj.FAILED);
                responseObj.setResMsg("eDate参数为空");
                return responseObj;
            }

            String channelcd = request.getParameter("channelcd");
            if(StringUtils.isNotBlank(channelcd)){
                String[] channelcds = StringUtils.splitByWholeSeparator(channelcd, ",");

                if(channelcds.length > 0){
                    params.put("channelcds", channelcds);
                }
            }

            long beginDate = Long.valueOf(bDate.replace("-", ""));
            long endDate = Long.valueOf(eDate.replace("-", ""));
            if(beginDate != 20170601){
                responseObj.setResCode(ResponseObj.FAILED);
                responseObj.setResMsg("bDate必须2017-06-01");
                return responseObj;
            }
            if(beginDate > endDate){
                responseObj.setResCode(ResponseObj.FAILED);
                responseObj.setResMsg("bDate不能大于endDate");
                return responseObj;
            }
            if(today - endDate != 1){
                String yesterday = String.valueOf(today -1);
                String year = yesterday.substring(0,4);
                String month = yesterday.substring(4,6);
                String day = yesterday.substring(6,8);
                String tmpDate = year+"-"+month+"-"+day;
                responseObj.setResCode(ResponseObj.FAILED);
                responseObj.setResMsg("eDate必须为"+tmpDate);
                return responseObj;
            }

            params.put("beginDate", bDate);
            params.put("endDate", eDate);
            params.put("bDateLong", beginDate);
            params.put("eDateLong", endDate);

            refreshPromotersIncomeService.refreshPromotersIncomeData(params);

        } catch (Exception e) {
            LOG.error("刷新渠道收益数据异常", e);
            responseObj.setResCode(ResponseObj.FAILED);
            responseObj.setResMsg("刷新渠道收益数据失败, 出现异常:"+e.getMessage());
            return responseObj;
        }

        responseObj.setResCode(ResponseObj.SUCCESS);
        responseObj.setResMsg("刷新渠道收益数据成功");
        return responseObj;
    }*/

}
