package com.cornu.report.response;

import java.io.Serializable;

public class ResponseObj implements Serializable {
	private static final long serialVersionUID = 6982188055111979852L;

	public static final String SUCCESS = "1000";
	public static final String FAILED = "-1";

	String resMsg;
	String resCode;
	Object resData;

	public String getResMsg() {
		return resMsg;
	}

	public void setResMsg(String resMsg) {
		this.resMsg = resMsg;
	}

	public String getResCode() {
		return resCode;
	}

	public void setResCode(String resCode) {
		this.resCode = resCode;
	}

	public Object getResData() {
		return resData;
	}

	public void setResData(Object resData) {
		this.resData = resData;
	}

	@Override
	public String toString() {
		return "ResponseObj{" + "resMsg='" + resMsg + '\'' + ", resCode='" + resCode + '\'' + ", resData=" + resData
				+ '}';
	}
}
