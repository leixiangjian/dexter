package com.cornu.report.api;

import java.text.ParseException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cornu.report.response.ResponseObj;
import com.cornu.report.service.MigrateDataService;
import com.cornu.report.utils.CommonUtil;
import com.cornu.report.utils.DateUtil;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * 刷数据
 * 
 * @author lenovo01
 *
 */
@Controller
@Api("刷新统计基本数据")
public class RefreshBasicData extends BaseApi{
	private static final Logger LOG = LoggerFactory.getLogger(RefreshBasicData.class);
	
	/*@Autowired(required = true)
	@Qualifier(value = "migrateDataService")
	MigrateDataService migrateDataService;*/
	
	@ResponseBody
	@RequestMapping(value = "/refreshBasic", method = RequestMethod.POST)
	@ApiOperation(value = "刷新统计基本数据接口", notes = "刷新统计基本数据")
	@ApiImplicitParams({
			@ApiImplicitParam(paramType = "query", name = "bDate", dataType = "String", required = true, value = "开始日期，格式:YYYY-MM-DD"), 
			@ApiImplicitParam(paramType = "query", name = "eDate", dataType = "String", required = true, value = "结束日期，格式:YYYY-MM-DD")})
	public ResponseObj refreshBasic(HttpServletRequest request, HttpServletResponse response) {
		ResponseObj responseObj = new ResponseObj();
		String bDate = request.getParameter("bDate");
		if(StringUtils.isBlank(bDate)){
			responseObj.setResCode(ResponseObj.FAILED);
			responseObj.setResMsg("bDate参数为空");
			return responseObj;
		}else{
			try{
			  sdf.parse(bDate);
			}catch(ParseException e){
				responseObj.setResCode(ResponseObj.FAILED);
				responseObj.setResMsg("bDate参数格式不正确");
				return responseObj;
			}
			
		}
		String eDate = request.getParameter("eDate");
		if(StringUtils.isBlank(eDate)){
			responseObj.setResCode(ResponseObj.FAILED);
			responseObj.setResMsg("eDate参数为空");
			return responseObj;
		}else{
			try{
			  sdf.parse(eDate);
			}catch(ParseException e){
				responseObj.setResCode(ResponseObj.FAILED);
				responseObj.setResMsg("eDate参数格式不正确");
				return responseObj;
			}
		}
		
		//解析日期
		int days = DateUtil.daysBetween(bDate,eDate);
		
		for(int i=0;i<=days;i++){
			Date afterDay = DateUtil.getSpecifiedDayAfter(bDate,i);
			try {
				basicDataService.statBasicData(afterDay);
			} catch (Exception e) {
				LOG.error("刷新统计基本数据异常",e);
				responseObj.setResCode(ResponseObj.FAILED);
				responseObj.setResMsg("刷新统计基本数据失败,出现异常:"+e.getMessage());
				return responseObj;
			}
		}
		
		responseObj.setResCode(ResponseObj.SUCCESS);
		responseObj.setResMsg("刷新统计基本数据成功");
		return responseObj;
	}
	
	@ResponseBody
	@RequestMapping(value = "/refreshMixBasic", method = RequestMethod.POST)
	@ApiOperation(value = "刷新混合统计基本数据接口", notes = "刷新混合统计基本数据")
	@ApiImplicitParams({
			@ApiImplicitParam(paramType = "query", name = "bDate", dataType = "String", required = true, value = "开始日期，格式:YYYY-MM-DD"), 
			@ApiImplicitParam(paramType = "query", name = "eDate", dataType = "String", required = true, value = "结束日期，格式:YYYY-MM-DD")})
	public ResponseObj refreshMixBasic(HttpServletRequest request, HttpServletResponse response) {
		ResponseObj responseObj = new ResponseObj();
		String bDate = request.getParameter("bDate");
		if(StringUtils.isBlank(bDate)){
			responseObj.setResCode(ResponseObj.FAILED);
			responseObj.setResMsg("bDate参数为空");
			return responseObj;
		}else{
			try{
			  sdf.parse(bDate);
			}catch(ParseException e){
				responseObj.setResCode(ResponseObj.FAILED);
				responseObj.setResMsg("bDate参数格式不正确");
				return responseObj;
			}
			
		}
		String eDate = request.getParameter("eDate");
		if(StringUtils.isBlank(eDate)){
			responseObj.setResCode(ResponseObj.FAILED);
			responseObj.setResMsg("eDate参数为空");
			return responseObj;
		}else{
			try{
			  sdf.parse(eDate);
			}catch(ParseException e){
				responseObj.setResCode(ResponseObj.FAILED);
				responseObj.setResMsg("eDate参数格式不正确");
				return responseObj;
			}
		}
		
		//解析日期
		int days = DateUtil.daysBetween(bDate,eDate);
		
		for(int i=0;i<=days;i++){
			Date afterDay = DateUtil.getSpecifiedDayAfter(bDate,i);
			try {
				basicDataService.statMixBasic(afterDay);
			} catch (Exception e) {
				LOG.error("刷新混合统计基本数据异常",e);
				responseObj.setResCode(ResponseObj.FAILED);
				responseObj.setResMsg("刷新混合统计基本数据失败,出现异常:"+e.getMessage());
				return responseObj;
			}
		}
		
		responseObj.setResCode(ResponseObj.SUCCESS);
		responseObj.setResMsg("刷新混合统计基本数据成功");
		return responseObj;
	}
	
	@ResponseBody
	@RequestMapping(value = "/refresh9999Basic", method = RequestMethod.POST)
	@ApiOperation(value = "刷新自然代理统计基本数据接口", notes = "刷新自然代理统计基本数据")
	@ApiImplicitParams({
			@ApiImplicitParam(paramType = "query", name = "bDate", dataType = "String", required = true, value = "开始日期，格式:YYYY-MM-DD"), 
			@ApiImplicitParam(paramType = "query", name = "eDate", dataType = "String", required = true, value = "结束日期，格式:YYYY-MM-DD")})
	public ResponseObj refresh9999Basic(HttpServletRequest request, HttpServletResponse response) {
		ResponseObj responseObj = new ResponseObj();
		String bDate = request.getParameter("bDate");
		if(StringUtils.isBlank(bDate)){
			responseObj.setResCode(ResponseObj.FAILED);
			responseObj.setResMsg("bDate参数为空");
			return responseObj;
		}else{
			try{
			  sdf.parse(bDate);
			}catch(ParseException e){
				responseObj.setResCode(ResponseObj.FAILED);
				responseObj.setResMsg("bDate参数格式不正确");
				return responseObj;
			}
			
		}
		String eDate = request.getParameter("eDate");
		if(StringUtils.isBlank(eDate)){
			responseObj.setResCode(ResponseObj.FAILED);
			responseObj.setResMsg("eDate参数为空");
			return responseObj;
		}else{
			try{
			  sdf.parse(eDate);
			}catch(ParseException e){
				responseObj.setResCode(ResponseObj.FAILED);
				responseObj.setResMsg("eDate参数格式不正确");
				return responseObj;
			}
		}
		
		//解析日期
		int days = DateUtil.daysBetween(bDate,eDate);
		
		for(int i=0;i<=days;i++){
			Date afterDay = DateUtil.getSpecifiedDayAfter(bDate,i);
			try {
				basicDataService.stat9999Basic(afterDay);
			} catch (Exception e) {
				LOG.error("刷新自然代理统计基本数据异常",e);
				responseObj.setResCode(ResponseObj.FAILED);
				responseObj.setResMsg("刷新自然代理统计基本数据失败,出现异常:"+e.getMessage());
				return responseObj;
			}
		}
		
		responseObj.setResCode(ResponseObj.SUCCESS);
		responseObj.setResMsg("刷新自然代理统计基本数据成功");
		return responseObj;
	}
	
	@ResponseBody
	@RequestMapping(value = "/refreshDetailBasic", method = RequestMethod.POST)
	@ApiOperation(value = "刷新详细统计基本数据接口", notes = "刷新详细统计基本数据")
	@ApiImplicitParams({
			@ApiImplicitParam(paramType = "query", name = "bDate", dataType = "String", required = true, value = "开始日期，格式:YYYY-MM-DD"), 
			@ApiImplicitParam(paramType = "query", name = "eDate", dataType = "String", required = true, value = "结束日期，格式:YYYY-MM-DD")})
	public ResponseObj refreshDetailBasic(HttpServletRequest request, HttpServletResponse response) {
		ResponseObj responseObj = new ResponseObj();
		String bDate = request.getParameter("bDate");
		if(StringUtils.isBlank(bDate)){
			responseObj.setResCode(ResponseObj.FAILED);
			responseObj.setResMsg("bDate参数为空");
			return responseObj;
		}else{
			try{
			  sdf.parse(bDate);
			}catch(ParseException e){
				responseObj.setResCode(ResponseObj.FAILED);
				responseObj.setResMsg("bDate参数格式不正确");
				return responseObj;
			}
			
		}
		String eDate = request.getParameter("eDate");
		if(StringUtils.isBlank(eDate)){
			responseObj.setResCode(ResponseObj.FAILED);
			responseObj.setResMsg("eDate参数为空");
			return responseObj;
		}else{
			try{
			  sdf.parse(eDate);
			}catch(ParseException e){
				responseObj.setResCode(ResponseObj.FAILED);
				responseObj.setResMsg("eDate参数格式不正确");
				return responseObj;
			}
		}
		
		//解析日期
		int days = DateUtil.daysBetween(bDate,eDate);
		
		for(int i=0;i<=days;i++){
			Date afterDay = DateUtil.getSpecifiedDayAfter(bDate,i);
			try {
				basicDataService.statDetailBasic(afterDay);
			} catch (Exception e) {
				LOG.error("刷新详细统计基本数据异常",e);
				responseObj.setResCode(ResponseObj.FAILED);
				responseObj.setResMsg("刷新详细统计基本数据失败,出现异常:"+e.getMessage());
				return responseObj;
			}
		}
		
		responseObj.setResCode(ResponseObj.SUCCESS);
		responseObj.setResMsg("刷新详细统计基本数据成功");
		return responseObj;
	}
	
	
	@ResponseBody
	@RequestMapping(value = "/queryCodeByPhone", method = RequestMethod.POST)
	@ApiOperation(value = "根据手机号，查询最新验证码接口", notes = "根据手机号，查询最新验证码")
	@ApiImplicitParams({
		@ApiImplicitParam(paramType = "query", name = "phone", dataType = "String", required = true, value = "手机号")
	})
	public ResponseObj queryCodeByPhone(HttpServletRequest request, HttpServletResponse response) {
		ResponseObj responseObj = new ResponseObj();
		String phone = request.getParameter("phone");
		if(StringUtils.isBlank(phone)){
			responseObj.setResCode(ResponseObj.FAILED);
			responseObj.setResMsg("手机号参数为空");
			return responseObj;
		}else if(!CommonUtil.validPhone(phone)){
			responseObj.setResCode(ResponseObj.FAILED);
			responseObj.setResMsg("手机号参数格式不正确");
			return responseObj;
		}
		
		try {
			String smsCode = basicDataService.queryCodeByPhone(phone);
			responseObj.setResData(smsCode);
		} catch (Exception e) {
			LOG.error("根据手机号，查询最新验证码异常",e);
			responseObj.setResCode(ResponseObj.FAILED);
			responseObj.setResMsg("根据手机号，查询最新验证码失败,出现异常:"+e.getMessage());
			return responseObj;
		}
		
		responseObj.setResCode(ResponseObj.SUCCESS);
		responseObj.setResMsg("根据手机号，查询最新验证码成功");
		return responseObj;
	}
	
	@ResponseBody
	@RequestMapping(value = "/refreshAccountReportBasic", method = RequestMethod.POST)
	@ApiOperation(value = "刷新聚宝盆财务对账数据接口", notes = "刷新聚宝盆财务对账数据")
	@ApiImplicitParams({
			@ApiImplicitParam(paramType = "query", name = "startDate", dataType = "String", required = true, value = "开始日期，格式:YYYY-MM-DD"), 
			@ApiImplicitParam(paramType = "query", name = "endDate", dataType = "String", required = true, value = "结束日期，格式:YYYY-MM-DD")})
	public ResponseObj refreshAccountReportBasic(HttpServletRequest request, HttpServletResponse response) {
		ResponseObj responseObj = new ResponseObj();
		
		String startDate = request.getParameter("startDate");
		if(StringUtils.isBlank(startDate)){
			responseObj.setResCode(ResponseObj.FAILED);
			responseObj.setResMsg("startDate参数为空");
			return responseObj;
		}else{
			try{
			  sdf.parse(startDate);
			}catch(ParseException e){
				responseObj.setResCode(ResponseObj.FAILED);
				responseObj.setResMsg("startDate参数格式不正确");
				return responseObj;
			}
			
		}
		
		String endDate = request.getParameter("endDate");
		if(StringUtils.isBlank(endDate)){
			responseObj.setResCode(ResponseObj.FAILED);
			responseObj.setResMsg("endDate参数为空");
			return responseObj;
		}else{
			try{
			  sdf.parse(endDate);
			}catch(ParseException e){
				responseObj.setResCode(ResponseObj.FAILED);
				responseObj.setResMsg("endDate参数格式不正确");
				return responseObj;
			}
		}
		
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("startDate", startDate + " 00:00:00");
		paramMap.put("endDate", endDate + " 23:59:59");
		try {
			basicDataService.statAccountReportBasic(paramMap);
		} catch (Exception e) {
			LOG.error("刷新财务对账数据异常",e);
			responseObj.setResCode(ResponseObj.FAILED);
			responseObj.setResMsg("刷新财务对账数据数据失败,出现异常:"+e.getMessage());
			return responseObj;
		}
		
		responseObj.setResCode(ResponseObj.SUCCESS);
		responseObj.setResMsg("刷新财务对账数据成功");
		return responseObj;
	}
	
	/*@ResponseBody
	@RequestMapping(value = "/refresAccountReportCurrentBasic", method = RequestMethod.POST)
	@ApiOperation(value = "刷新聚宝盆财务对账当期数据接口", notes = "刷新聚宝盆财务对账当期数据")
	public ResponseObj refresAccountReportCurrentBasic(HttpServletRequest request, HttpServletResponse response) {
		ResponseObj responseObj = new ResponseObj();
		
		try {
			migrateDataService.migrateAccountReport();
		} catch (Exception e) {
			e.printStackTrace();
			responseObj.setResCode(ResponseObj.FAILED);
		}
		
		responseObj.setResCode(ResponseObj.SUCCESS);
		responseObj.setResMsg("刷新财务对账数据成功");
		return responseObj;
	}*/
	
}
