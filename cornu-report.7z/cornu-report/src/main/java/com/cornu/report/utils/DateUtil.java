package com.cornu.report.utils;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.springframework.security.authentication.encoding.MessageDigestPasswordEncoder;

public class DateUtil {

	public static final long ONE_SECOND = 1000;
	public static final long T05_SECOND = ONE_SECOND * 5;
	public static final long T10_SECOND = ONE_SECOND * 10;
	public static final long T15_SECOND = ONE_SECOND * 15;
	public static final long T20_SECOND = ONE_SECOND * 20;
	public static final long T25_SECOND = ONE_SECOND * 25;
	public static final long T30_SECOND = ONE_SECOND * 30;
	public static final long T35_SECOND = ONE_SECOND * 35;
	public static final long T40_SECOND = ONE_SECOND * 40;
	public static final long T45_SECOND = ONE_SECOND * 45;
	public static final long T50_SECOND = ONE_SECOND * 50;
	public static final long T55_SECOND = ONE_SECOND * 55;

	public static final long ONE_MINUTE = ONE_SECOND * 60;
	public static final long ONE_HOUR = ONE_MINUTE * 60;

	public static final long T12_HOUR = ONE_HOUR * 12;

	public static final long ONE_DAY = ONE_HOUR * 24;

	// 日期格式
	public static final String DATE_FORMAT_STANDARD = "yyyy-MM-dd HH:mm:ss";

	public static final int ONE_DataCycle = 7; // 一个数据周期(单位 天 Date)

	// 获取当前时间
	public static java.util.Date now() {
		return new java.util.Date();
	}

	public static String nowFormat() {
		return new SimpleDateFormat(DATE_FORMAT_STANDARD).format(now());
	}

	public static String format(java.util.Date d) {
		return new SimpleDateFormat(DATE_FORMAT_STANDARD).format(d);
	}

	public static String nowFormat(String fm) {
		return new SimpleDateFormat(fm).format(now());
	}

	public static String Format(java.util.Date d, String fm) {
		return new SimpleDateFormat(fm).format(d);
	}

	public static Timestamp parseTimestamp(String s) {
		java.util.Date d;
		try {
			d = new SimpleDateFormat(DATE_FORMAT_STANDARD).parse(s);
			return new Timestamp(d.getTime());
		} catch (ParseException e) {
			e.printStackTrace();
			return null;
		}
	}

	public static long convertDate(java.util.Date d, String fmt) {
		return Long.parseLong(new SimpleDateFormat(fmt).format(d));
	}

	// 获得当前时间的小时数 0-23小时制
	public static int GetNowHour() {
		return Integer.parseInt(new SimpleDateFormat("HH").format(now()));
	}

	// 获得当前时间的分钟数 0-59
	public static int GetNowMinute() {
		return Integer.parseInt(new SimpleDateFormat("mm").format(now()));
	}

	// 获得当前时间的分钟数 0-59
	public static int GetNowSeconds() {
		return Integer.parseInt(new SimpleDateFormat("ss").format(now()));
	}

	/**
	 * 计算两天之间的天数
	 * 
	 * @param startStr
	 * @param endStr
	 * @return
	 */
	public static int daysBetween(String startStr, String endStr) {
		int daysBetween = 0;
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

			Date date1 = sdf.parse(startStr);
			Calendar startDate = Calendar.getInstance();
			startDate.setTime(date1);

			Date date2 = sdf.parse(endStr);
			Calendar endDate = Calendar.getInstance();
			endDate.setTime(date2);

			Calendar date = (Calendar) startDate.clone();

			while (date.before(endDate)) {
				date.add(Calendar.DAY_OF_MONTH, 1);
				daysBetween++;
			}

		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return daysBetween;
	}

	/**
	 * 获得指定日期的后一天
	 * 
	 * @param specifiedDay
	 * @return
	 */
	public static Date getSpecifiedDayAfter(String specifiedDay,int dayNum) {
		Calendar c = Calendar.getInstance();
		Date date = null;
		try {
			date = new SimpleDateFormat("yy-MM-dd").parse(specifiedDay);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		c.setTime(date);
		int day = c.get(Calendar.DATE);
		c.set(Calendar.DATE, day + dayNum);

		return c.getTime();
	}

	/**
	 * 获取当前年月2017-06
	 * @return
     */
	public static String getCurrentMonth(){
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM");
		Calendar c = Calendar.getInstance();

		c.setTime(new Date());
		Date d = c.getTime();
		String day = format.format(d);
		return day;
	}

	/**
	 * 获取上个月年月2017-05
	 * @return
     */
	public static String getLastMonth(){
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM");
		Calendar c = Calendar.getInstance();

		c.setTime(new Date());
		c.add(Calendar.MONTH, -1);
		Date m = c.getTime();
		String mon = format.format(m);
		return mon;
	}
	
	/**
	 * 获取周二日期
	 * 
	 * @param date	设置的时间
	 * @param num	加N天
	 * @return
	 */
	public static Date getTuesday(Date date, int num){
		
		Calendar c = Calendar.getInstance();
		c.setFirstDayOfWeek(Calendar.MONDAY);
		c.setTime(date);
		c.add(Calendar.DATE, 0);	
		c.set(Calendar.DAY_OF_WEEK, Calendar.TUESDAY); //获取周二的日期
		
		return c.getTime();
	}
	
}
