package com.cornu.report.dao.bean;

public class AgentEntity {
	private String aid;
	private String passwd;
	private String phone;
	private String acode;
	private String from;
	private String tincome;
	private String ttake;
	private String ticount;
	private String tocount;
	private String level;
	private String status;
	private String ip;
	private long ctime;
	private long mtime;
	private String bankname;
	private String cardno;
	private String username;
	private String channelcd;
	private String isValid;
	private long validTime;
	private String roletype;
	private String p_channelcd;//组长编码
	private String channel_total_income;
	private String channel_income_count;
	private String headman_total_income;
	private String headman_income_count;
	private String validagent_total_income;
	private String validagent_income_count;
	private String validreguser_total_income;
	private String validreguser_income_count;
	private String last_withdraw_balance;
	private long last_withdraw_time;
	private String branchbankname;
	
	private String tincome_new;
	private String channel_total_income_new;
	private String headman_total_income_new;
	private String ttake_new;
	

	public String getIsValid() {
		return isValid;
	}

	public void setIsValid(String isValid) {
		this.isValid = isValid;
	}

	public long getValidTime() {
		return validTime;
	}

	public void setValidTime(long validTime) {
		this.validTime = validTime;
	}

	public String getBankname() {
		return bankname;
	}

	public void setBankname(String bankname) {
		this.bankname = bankname;
	}

	public String getCardno() {
		return cardno;
	}

	public void setCardno(String cardno) {
		this.cardno = cardno;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getFrom() {
		return from;
	}

	public void setFrom(String from) {
		this.from = from;
	}

	public String getTincome() {
		return tincome;
	}

	public void setTincome(String tincome) {
		this.tincome = tincome;
	}

	public String getTtake() {
		return ttake;
	}

	public void setTtake(String ttake) {
		this.ttake = ttake;
	}

	public String getTicount() {
		return ticount;
	}

	public void setTicount(String ticount) {
		this.ticount = ticount;
	}

	public String getTocount() {
		return tocount;
	}

	public void setTocount(String tocount) {
		this.tocount = tocount;
	}

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public long getCtime() {
		return ctime;
	}

	public void setCtime(long ctime) {
		this.ctime = ctime;
	}

	public long getMtime() {
		return mtime;
	}

	public void setMtime(long mtime) {
		this.mtime = mtime;
	}

	public String getChannelcd() {
		return channelcd;
	}

	public void setChannelcd(String channelcd) {
		this.channelcd = channelcd;
	}

	public String getPasswd() {
		return passwd;
	}

	public void setPasswd(String passwd) {
		this.passwd = passwd;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getAcode() {
		return acode;
	}

	public void setAcode(String acode) {
		this.acode = acode;
	}

	public String getAid() {
		return aid;
	}

	public void setAid(String aid) {
		this.aid = aid;
	}

	public String getRoletype() {
		return roletype;
	}

	public void setRoletype(String roletype) {
		this.roletype = roletype;
	}

	public String getP_channelcd() {
		return p_channelcd;
	}

	public void setP_channelcd(String p_channelcd) {
		this.p_channelcd = p_channelcd;
	}

	public String getChannel_income_count() {
		return channel_income_count;
	}

	public void setChannel_income_count(String channel_income_count) {
		this.channel_income_count = channel_income_count;
	}

	public String getChannel_total_income() {
		return channel_total_income;
	}

	public void setChannel_total_income(String channel_total_income) {
		this.channel_total_income = channel_total_income;
	}

	public String getHeadman_income_count() {
		return headman_income_count;
	}

	public void setHeadman_income_count(String headman_income_count) {
		this.headman_income_count = headman_income_count;
	}

	public String getHeadman_total_income() {
		return headman_total_income;
	}

	public void setHeadman_total_income(String headman_total_income) {
		this.headman_total_income = headman_total_income;
	}

	public String getValidagent_income_count() {
		return validagent_income_count;
	}

	public void setValidagent_income_count(String validagent_income_count) {
		this.validagent_income_count = validagent_income_count;
	}

	public String getValidagent_total_income() {
		return validagent_total_income;
	}

	public void setValidagent_total_income(String validagent_total_income) {
		this.validagent_total_income = validagent_total_income;
	}

	public String getLast_withdraw_balance() {
		return last_withdraw_balance;
	}

	public void setLast_withdraw_balance(String last_withdraw_balance) {
		this.last_withdraw_balance = last_withdraw_balance;
	}

	public long getLast_withdraw_time() {
		return last_withdraw_time;
	}

	public void setLast_withdraw_time(long last_withdraw_time) {
		this.last_withdraw_time = last_withdraw_time;
	}

	public String getValidreguser_income_count() {
		return validreguser_income_count;
	}

	public void setValidreguser_income_count(String validreguser_income_count) {
		this.validreguser_income_count = validreguser_income_count;
	}

	public String getValidreguser_total_income() {
		return validreguser_total_income;
	}

	public void setValidreguser_total_income(String validreguser_total_income) {
		this.validreguser_total_income = validreguser_total_income;
	}

	public String getBranchbankname() {
		return branchbankname;
	}

	public void setBranchbankname(String branchbankname) {
		this.branchbankname = branchbankname;
	}

	public String getTincome_new() {
		return tincome_new;
	}

	public void setTincome_new(String tincome_new) {
		this.tincome_new = tincome_new;
	}

	public String getChannel_total_income_new() {
		return channel_total_income_new;
	}

	public void setChannel_total_income_new(String channel_total_income_new) {
		this.channel_total_income_new = channel_total_income_new;
	}

	public String getHeadman_total_income_new() {
		return headman_total_income_new;
	}

	public void setHeadman_total_income_new(String headman_total_income_new) {
		this.headman_total_income_new = headman_total_income_new;
	}

	public String getTtake_new() {
		return ttake_new;
	}

	public void setTtake_new(String ttake_new) {
		this.ttake_new = ttake_new;
	}
}
