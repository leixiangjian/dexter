package com.cornu.report.service;

import com.cornu.report.dao.bean.AgentEntity;
import com.cornu.report.dao.bean.ChannelEntity;
import com.cornu.report.dao.bean.TransactionEntity;
import com.cornu.report.dao.mapper.CommonMapper;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.*;

import static org.springframework.data.mongodb.core.query.Criteria.where;

/**
 * Created by Dell on 2017/7/10.
 */
@Service("validAgentBalanceAcctService")
public class ValidAgentBalanceAcctService {

    private static final Logger LOG = LoggerFactory.getLogger(ValidAgentBalanceAcctService.class);

    //有效代理奖励金额(暂定为1000分一个)
    private static final long VALIDAGENT_AWARD_MONEY = Long.parseLong(System.getProperty("validagent.award.money", "1000"));

    //有效注册用户奖励金额(暂定为100分一个)
    private static final long VALIDREGUSER_AWARD_MONEY = Long.parseLong(System.getProperty("validreguser.award.money", "100"));

    //新账户字段
    private static final long CORNU_NEWACCOUNT_TIME = 1501516800000l;

    //需要过滤的刷子推广渠道
    private static Set<String> filterChannelcd = new HashSet<String>();

    static{
        filterChannelcd.add("LW0398");//LW0398  刘烁  18357374919
        filterChannelcd.add("LW0382");//LW0382  张俊辉  15958359459
        filterChannelcd.add("LW0433");//LW0433  巩宇翔  13067919128
        filterChannelcd.add("LW0421");//LW0421  熊青  18627823056
        filterChannelcd.add("LW0517");//LW0517  汤达  18557511955
    }

    @Autowired
    MongoTemplate mongoTemplate;

    @Autowired(required = true)
    @Qualifier(value = "commonMapper")
    CommonMapper commonMapper;

    /**
     * 1.查询所有渠道channelcd
     * 2.循环所有渠道，根据channelcd查询到该channelcd的推广员信息，然后查询所有具备channelcd的代理员数据。
     * 3.循环代理员数据、根据代理员aid查询transaction（recharge=0）按时间升序计算是否是否注册人数大于等于5人，大于等于5人则为有效代理。
     * 4.入库数据到T_VALIDAGENT_BALANCEACCT表和mongodb的validagent_balanceacct表。
     * 5.如果入库成功则给该channelcd的推广员账户入账有效代理奖励金额及增加validagent_total_income和validagent_income_count否则跳过本次循环。
     * @throws Exception
     */
    public void validAgentBalanceAcct() throws Exception{
        //所有渠道
        List<ChannelEntity> channelEntitys = mongoTemplate.findAll(ChannelEntity.class,
                "channel_info");
        for(ChannelEntity channelEntity : channelEntitys) {
            String channelCd = channelEntity.getChannelcd();

            Query query = new Query();
            query.addCriteria(where("channelcd").is(channelCd));

            List<AgentEntity> agentEntitys = mongoTemplate.find(query, AgentEntity.class, "agent");
            for (AgentEntity agentEntity : agentEntitys) {
                balanceAcctAwardMoeny(agentEntity);
            }
        }
    }

    /**
     * 结算有效代理奖励金额
     */
    public void balanceAcctAwardMoeny(AgentEntity agentEntity) throws Exception{
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        //查询应用所有的注册人数
        Query appRegQuery = new Query();
        appRegQuery.addCriteria(where("aid").is(agentEntity.getAid()));
        appRegQuery.addCriteria(where("recharge").is(0));
        appRegQuery.with(new Sort(new Sort.Order(Sort.Direction.ASC, "ctime")));
        List<TransactionEntity> appRegtransactionEntitys = mongoTemplate.find(appRegQuery, TransactionEntity.class, "transaction");
        int newCpRegNum = 0;
        for(TransactionEntity transactionEntity : appRegtransactionEntitys){
            String uid = transactionEntity.getUid();
            long regTime = transactionEntity.getOtime();
            newCpRegNum++;
            if(newCpRegNum == 5){

                String channelcd = agentEntity.getChannelcd();
                List<String> roletypeList = new ArrayList<String>();
                roletypeList.add("2");//组长
                roletypeList.add("3");//组员
                Map<String, Object> params = new HashMap<String, Object>();
                params.put("channelcd", channelcd);
                params.put("roletypes", roletypeList);
                AgentEntity channelMemberAgentInfo = queryAgentInfo(params);
                if(channelMemberAgentInfo == null){
                    LOG.error("有效代理费用结算, queryAgentInfo, 代理不存在, params={}", params);
                    break;
                }

                //入库数据到T_VALIDAGENT_BALANCEACCT表和mongodb的validagent_balanceacct表。（有效代理在一个CHANNELCD只会有一个）
                Map<String, Object> insertParams = new HashMap<String, Object>();
                insertParams.put("VB_AID", agentEntity.getAid());//有效代理AID
                insertParams.put("VB_CHANNELCD", channelcd);//有效代理所属推广渠道（如LW0022）
                insertParams.put("VB_CHANNEL_MEMBER_AID", channelMemberAgentInfo.getAid());
                insertParams.put("VB_VALIDTIME", regTime);
                insertParams.put("VB_AWARDMONEY", VALIDAGENT_AWARD_MONEY);//金额单位：分
                insertParams.put("VB_APPID", transactionEntity.getAppid());//应用ID
                insertParams.put("VB_PHONE", agentEntity.getPhone());//有效代理的手机号码
                insertParams.put("VB_CHANNEL_MEMBER_PHONE", channelMemberAgentInfo.getPhone());//推广渠道组员的代理的手机号码

                try{
                    LOG.info("有效代理费用结算, addValidagentBalanceacct, 参数={}", insertParams);
                    commonMapper.addValidagentBalanceacct(insertParams);
                }catch(DuplicateKeyException e){
                    //LOG.warn("有效代理费用结算, addValidagentBalanceacct记录已存在, insertParams={}", insertParams);
                    break;
                }

                Date currentDate = new Date();
                Map<String, Object> mongoInsertParams = new HashMap<String, Object>();
                mongoInsertParams.put("aid", agentEntity.getAid());
                mongoInsertParams.put("channelcd", channelcd);
                mongoInsertParams.put("channel_member_aid", channelMemberAgentInfo.getAid());
                mongoInsertParams.put("validtime", regTime);
                mongoInsertParams.put("awardmoney", VALIDAGENT_AWARD_MONEY);//金额单位：分
                mongoInsertParams.put("appid", transactionEntity.getAppid());
                mongoInsertParams.put("phone", agentEntity.getPhone());
                mongoInsertParams.put("channel_member_phone", channelMemberAgentInfo.getPhone());
                mongoInsertParams.put("crt_time", currentDate.getTime() / 1000);
                mongoInsertParams.put("crt_time_str", sdf.format(currentDate));
                mongoInsertParams.put("mod_time", currentDate.getTime() / 1000);
                mongoInsertParams.put("mod_time_str", sdf.format(currentDate));
                try{
                    LOG.info("有效代理费用结算, addValidagentBalanceacct mongodb, 参数={}", mongoInsertParams);
                    mongoTemplate.insert(mongoInsertParams, "validagent_balanceacct");
                }catch (DuplicateKeyException e){
                    LOG.error("有效代理费用结算, addValidagentBalanceacct mongodb 记录已存在, mongoInsertParams={}", mongoInsertParams, e);
                    break;
                }

                //5.如果入库成功则给该channelcd的推广员账户入账有效代理奖励金额及增加validagent_total_income和validagent_income_count否则跳过本次循环。
                Query query = new Query();
                query.addCriteria(new Criteria("aid").is(channelMemberAgentInfo.getAid()));
                Update update = new Update();
                update.inc("validagent_total_income", VALIDAGENT_AWARD_MONEY);//金额单位：分
                update.inc("validagent_income_count", 1);
                
                //2017-08-01 00:00:00之后的收入记录到tincome_new中和ttake_new中
                if(new Date().getTime() > CORNU_NEWACCOUNT_TIME){
                    update.inc("tincome_new", VALIDAGENT_AWARD_MONEY);//金额单位：分
                }else{
                    update.inc("tincome", VALIDAGENT_AWARD_MONEY);//金额单位：分
                }

                this.mongoTemplate.updateFirst(query, update, "agent");
                LOG.info("有效代理费用结算, 给channelcd推广员代理账户入账成功, 参数={}", mongoInsertParams);

                break;
            }
        }
    }

    /**
     * 查询代理信息
     * @param params
     * @return
     */
    private AgentEntity queryAgentInfo(Map<String, Object> params){
        List<String> roletypes = (List<String>)params.get("roletypes");
        Query agentQuery = new Query();
        if(params.containsKey("channelcd")){
            String channelcd = (String)params.get("channelcd");
            if(StringUtils.isNotBlank(channelcd)){
                agentQuery.addCriteria(Criteria.where("channelcd").is(channelcd));
            }
        }
        if(params.containsKey("roletypes")){
            if(roletypes.size() > 0){
                agentQuery.addCriteria(Criteria.where("roletype").in(roletypes));
            }
        }
        if(params.containsKey("aid")){
            String aid = (String)params.get("aid");
            if(StringUtils.isNotBlank(aid)){
                agentQuery.addCriteria(Criteria.where("aid").is(aid));
            }
        }
        AgentEntity agentEntity = mongoTemplate.findOne(agentQuery, AgentEntity.class, "agent");
        if(agentEntity == null){
            return null;
        }

        return agentEntity;
    }

    /**
     * 1.查询所有渠道channelcd
     * 2.循环所有渠道，根据channelcd和isValid=1查询transaction表中的有效注册用户。
     * 3.入库数据到T_VALIDREGUSER_BALANCEACCT表和mongodb的validreguser_balanceacct表。
     * 4.如果入库成功则给该channelcd的推广员账户入账有效注册用户奖励金额及增加validreguser_total_income和validreguser_income_count否则跳过本次循环。
     * @throws Exception
     */
    public void validRegUserBalanceAcct() throws Exception{
        //所有渠道
        List<ChannelEntity> channelEntitys = mongoTemplate.findAll(ChannelEntity.class,
                "channel_info");
        for(ChannelEntity channelEntity : channelEntitys) {
            String channelCd = channelEntity.getChannelcd();
            /*if(filterChannelcd.contains(channelCd)){
                LOG.warn("有效注册用户费用结算JOB, 扫描到刷子推广渠道, 不进行结算, 刷子推广渠道集合={}, 扫描到的刷子渠道={}",
                        filterChannelcd, channelCd);
                continue;
            }*/
            Query query = new Query();
            query.addCriteria(where("channelcd").is(channelCd));
            query.addCriteria(where("isValid").is("1"));

            List<TransactionEntity> transactionEntitys = mongoTemplate.find(query, TransactionEntity.class, "transaction");
            for (TransactionEntity transactionEntity : transactionEntitys) {
                balanceAcctValidRegUserAwardMoeny(transactionEntity);
            }
        }
    }

    /**
     * 结算有效注册用户奖励金额
     */
    public void balanceAcctValidRegUserAwardMoeny(TransactionEntity transactionEntity) throws Exception{
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        String aid = transactionEntity.getAid();
        String channelcd = transactionEntity.getChannelcd();
        String uid = transactionEntity.getUid();
        long validTime = transactionEntity.getValidTime();

        /**
         * 查询推广渠道组员信息
         */
        List<String> roletypeList = new ArrayList<String>();
        roletypeList.add("2");//组长
        roletypeList.add("3");//组员
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("channelcd", channelcd);
        params.put("roletypes", roletypeList);
        AgentEntity channelMemberAgentInfo = queryAgentInfo(params);
        if(channelMemberAgentInfo == null){
            LOG.error("有效注册用户费用结算, queryAgentInfo, 推广渠道组员代理信息不存在, params={}", params);
            return;
        }

        String aidPhone = null;
        Map<String, Object> aidParams = new HashMap<String, Object>();
        aidParams.put("aid", aid);
        AgentEntity agentInfoByAid = queryAgentInfo(aidParams);
        if(agentInfoByAid != null){
            aidPhone = agentInfoByAid.getPhone();
        }

        //入库数据到T_VALIDREGUSER_BALANCEACCT表和mongodb的validreguser_balanceacct表。（有效注册用户一个代理下只会有一个）
        Map<String, Object> insertParams = new HashMap<String, Object>();
        insertParams.put("VB_AID", aid);//代理AID
        insertParams.put("VB_USERCD", uid);//彩票注册用户
        insertParams.put("VB_CHANNEL_MEMBER_AID", channelMemberAgentInfo.getAid());
        insertParams.put("VB_CHANNELCD", channelcd);//代理所属推广渠道（如LW0022）
        insertParams.put("VB_VALIDTIME", validTime);//成为有效注册用户时的时间戳（秒）
        insertParams.put("VB_AWARDMONEY", VALIDREGUSER_AWARD_MONEY);//有效注册用户奖励金额，单位：分（这里的奖励金额是奖给推广渠道组员的代理AID）
        insertParams.put("VB_APPID", transactionEntity.getAppid());//应用ID
        insertParams.put("VB_PHONE", aidPhone);//代理的手机号码
        insertParams.put("VB_CHANNEL_MEMBER_PHONE", channelMemberAgentInfo.getPhone());//推广渠道组员的代理的手机号码

        try{
            LOG.info("有效注册用户费用结算, addValidreguserBalanceacct, 参数={}", insertParams);
            commonMapper.addValidreguserBalanceacct(insertParams);
        }catch(DuplicateKeyException e){
            //LOG.warn("有效注册用户费用结算, addValidreguserBalanceacct记录已存在, insertParams={}", insertParams);
            return;
        }

        Date currentDate = new Date();
        Map<String, Object> mongoInsertParams = new HashMap<String, Object>();
        mongoInsertParams.put("aid", aid);
        mongoInsertParams.put("usercd", uid);
        mongoInsertParams.put("channelcd", channelcd);
        mongoInsertParams.put("channel_member_aid", channelMemberAgentInfo.getAid());
        mongoInsertParams.put("validtime", validTime);
        mongoInsertParams.put("awardmoney", VALIDREGUSER_AWARD_MONEY);//金额单位：分
        mongoInsertParams.put("appid", transactionEntity.getAppid());
        mongoInsertParams.put("phone", aidPhone);
        mongoInsertParams.put("channel_member_phone", channelMemberAgentInfo.getPhone());
        mongoInsertParams.put("crt_time", currentDate.getTime() / 1000);
        mongoInsertParams.put("crt_time_str", sdf.format(currentDate));
        mongoInsertParams.put("mod_time", currentDate.getTime() / 1000);
        mongoInsertParams.put("mod_time_str", sdf.format(currentDate));
        try{
            LOG.info("有效注册用户费用结算, addValidreguserBalanceacct mongodb, 参数={}", mongoInsertParams);
            mongoTemplate.insert(mongoInsertParams, "validreguser_balanceacct");
        }catch (DuplicateKeyException e){
            LOG.error("有效注册用户费用结算, addValidreguserBalanceacct mongodb 记录已存在, mongoInsertParams={}", mongoInsertParams, e);
            return;
        }

        //如果入库成功则给该channelcd的推广员账户入账有效注册用户奖励金额及增加validreguser_total_income和validreguser_income_count否则返回
        Query query = new Query();
        query.addCriteria(new Criteria("aid").is(channelMemberAgentInfo.getAid()));
        Update update = new Update();
        update.inc("validreguser_total_income", VALIDREGUSER_AWARD_MONEY);//金额单位：分
        update.inc("validreguser_income_count", 1);

        //2017-08-01 00:00:00之后的收入记录到tincome_new中和ttake_new中
        if(new Date().getTime() > CORNU_NEWACCOUNT_TIME){
            update.inc("tincome_new", VALIDREGUSER_AWARD_MONEY);//金额单位：分
        }else{
            update.inc("tincome", VALIDREGUSER_AWARD_MONEY);//金额单位：分
        }

        mongoTemplate.updateFirst(query, update, "agent");
        LOG.info("有效注册用户费用结算, 给channelcd推广员代理账户入账成功, 参数={}", mongoInsertParams);

    }


}
