package com.cornu.report.api;

import com.cornu.report.response.ResponseObj;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by Dell on 2017/6/27.
 */
@Controller
@Api("刷新有效代理员数据")
public class RefreshValidAgentData extends BaseApi{
    private static final Logger LOG = LoggerFactory.getLogger(RefreshValidAgentData.class);

    @ResponseBody
    @RequestMapping(value = "/refreshValidAgent", method = RequestMethod.POST)
    @ApiOperation(value = "刷新有效代理数据接口", notes = "刷新有效代理数据接口")
    public ResponseObj refreshValidAgent(HttpServletRequest request, HttpServletResponse response) {
        ResponseObj responseObj = new ResponseObj();

        try {
            refreshValidAgentService.refreshValidAgent();
        } catch (Exception e) {
            LOG.error("刷新有效代理数据异常", e);
            responseObj.setResCode(ResponseObj.FAILED);
            responseObj.setResMsg("刷新有效代理数据失败, 出现异常:"+e.getMessage());
            return responseObj;
        }

        responseObj.setResCode(ResponseObj.SUCCESS);
        responseObj.setResMsg("刷新有效代理数据成功");
        return responseObj;
    }
    
    @ResponseBody
    @RequestMapping(value = "/refreshValidRegUser", method = RequestMethod.POST)
    @ApiOperation(value = "刷新有效注册用户数接口", notes = "刷新有效注册用户数接口")
    public ResponseObj refreshValidRegUser(HttpServletRequest request, HttpServletResponse response) {
    	ResponseObj responseObj = new ResponseObj();
    	
    	try {
    		refreshValidAgentService.refreshValidRegUser();
    	} catch (Exception e) {
    		LOG.error("刷新有效注册用户数据异常", e);
    		responseObj.setResCode(ResponseObj.FAILED);
    		responseObj.setResMsg("刷新有效注册用户数据失败, 出现异常:"+e.getMessage());
    		return responseObj;
    	}
    	
    	responseObj.setResCode(ResponseObj.SUCCESS);
    	responseObj.setResMsg("刷新有效注册用户数据成功");
    	return responseObj;
    }

}
