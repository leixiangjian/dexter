package com.cornu.report.dao.bean;

public class AppEntity {
	private String did;
	private String appid;
	private String appname;
	private String desc;
	private int level;
	private long apptime;
	private String size;
	private String language;
	private String system;
	private String dlink;
	private String version;
	private String applogo;
	private long rate;
	private long ftrade;
	private long proportion;
	private double status;
	private String ip;
	private long ctime;
	private long mtime;
	private double rltimeret;
	private int pic_type;
	private long t_total_income;
	private long t_agent_income;
	private long t_cornu_income;
	private long t_cornu_recieve;
	private long ticount;
	private long trcount;
	private String spread;
	private String backgroud;

	public long getT_total_income() {
		return t_total_income;
	}

	public void setT_total_income(long t_total_income) {
		this.t_total_income = t_total_income;
	}

	public long getT_agent_income() {
		return t_agent_income;
	}

	public void setT_agent_income(long t_agent_income) {
		this.t_agent_income = t_agent_income;
	}

	public long getT_cornu_income() {
		return t_cornu_income;
	}

	public void setT_cornu_income(long t_cornu_income) {
		this.t_cornu_income = t_cornu_income;
	}

	public long getT_cornu_recieve() {
		return t_cornu_recieve;
	}

	public void setT_cornu_recieve(long t_cornu_recieve) {
		this.t_cornu_recieve = t_cornu_recieve;
	}

	public int getPic_type() {
		return pic_type;
	}

	public void setPic_type(int pic_type) {
		this.pic_type = pic_type;
	}

	public long getTicount() {
		return ticount;
	}

	public void setTicount(long ticount) {
		this.ticount = ticount;
	}

	public long getTrcount() {
		return trcount;
	}

	public void setTrcount(long trcount) {
		this.trcount = trcount;
	}

	public String getSpread() {
		return spread;
	}

	public void setSpread(String spread) {
		this.spread = spread;
	}

	public String getBackgroud() {
		return backgroud;
	}

	public void setBackgroud(String backgroud) {
		this.backgroud = backgroud;
	}

	public String getDid() {
		return did;
	}

	public void setDid(String did) {
		this.did = did;
	}

	public String getAppid() {
		return appid;
	}

	public void setAppid(String appid) {
		this.appid = appid;
	}

	public String getAppname() {
		return appname;
	}

	public void setAppname(String appname) {
		this.appname = appname;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}

	public long getApptime() {
		return apptime;
	}

	public void setApptime(long apptime) {
		this.apptime = apptime;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public String getSystem() {
		return system;
	}

	public void setSystem(String system) {
		this.system = system;
	}

	public String getDlink() {
		return dlink;
	}

	public void setDlink(String dlink) {
		this.dlink = dlink;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getApplogo() {
		return applogo;
	}

	public void setApplogo(String applogo) {
		this.applogo = applogo;
	}

	public long getRate() {
		return rate;
	}

	public void setRate(long rate) {
		this.rate = rate;
	}

	public long getFtrade() {
		return ftrade;
	}

	public void setFtrade(long ftrade) {
		this.ftrade = ftrade;
	}

	public long getProportion() {
		return proportion;
	}

	public void setProportion(long proportion) {
		this.proportion = proportion;
	}

	public double getStatus() {
		return status;
	}

	public void setStatus(double status) {
		this.status = status;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public long getCtime() {
		return ctime;
	}

	public void setCtime(long ctime) {
		this.ctime = ctime;
	}

	public long getMtime() {
		return mtime;
	}

	public void setMtime(long mtime) {
		this.mtime = mtime;
	}

	public double getRltimeret() {
		return rltimeret;
	}

	public void setRltimeret(double rltimeret) {
		this.rltimeret = rltimeret;
	}

}
