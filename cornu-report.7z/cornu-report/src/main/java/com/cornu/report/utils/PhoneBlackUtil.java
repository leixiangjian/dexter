
package com.cornu.report.utils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSONObject;

/**
 * //TODO
 *
 * @author zhouxw
 * @version nyservice 下午5:25:47
 * @since 1.0
 **/
public class PhoneBlackUtil {

    private static final Logger LOG = LoggerFactory.getLogger(PhoneBlackUtil.class.getName());

    /*private static String appkey = "ukBQysqqfh";
    private static String secertkey = "tnliBCmusiyFimShkYzi";
    private static String baseUrl = "https://api.secboot.com/phone/black/query";
    private static String level = "0,1,2";*/
    private static String appkey = "kEKv2JyBUA";
    private static String secertkey = "MOdugzL09BOa0m0juHVL";
    private static String baseUrl = "https://api.secboot.com/phone/black/query";
    private static String level = "0,1,2";
    
    static String prefix="手机号黑名单检查";

    public static boolean validPhone(String phone) {
        if (StringUtils.isBlank(phone)) {
            return false;
        }

        return validPhone(phone, appkey, secertkey, baseUrl, level, new HashMap<String, String>());
    }

    /**
     * 大陆手机号码11位数，匹配格式：前三位固定格式+后8位任意数
     * 此方法中前三位格式有：
     * 13+任意数
     * 15+除4的任意数
     * 18+除1和4的任意数
     * 17+除9的任意数
     * 147
     */
    public static boolean phone(String str) throws PatternSyntaxException {
        String regExp = "^((13[0-9])|(15[^4])|(18[0,2,3,5-9])|(17[0-8])|(147))\\d{8}$";
        Pattern p = Pattern.compile(regExp);
        Matcher m = p.matcher(str);
        return m.matches();
    }

    public static boolean validPhone(String phone, String key, String secrt, String baseUrl1, String level, Map<String, String> returnData) {
        if (!phone(phone)) {
            return false;
        }
        try {
            long time = System.currentTimeMillis();
            StringBuffer sb = new StringBuffer();
//            sb.append("countrycode=countrycode");
            sb.append("&appkey=" + key);
            sb.append("&phone=" + phone);
            sb.append("&t=" + time);
            String sign = MD5.sign(sb.toString() + secrt, "", "utf-8");
            sb.append("&sign=" + sign);
            String url = baseUrl1 + "?" + sb;
       /*     Map<String, String> postData = new HashMap<>();
            postData.put("appkey", key);
            postData.put("phone", phone);
            postData.put("t", time + "");
            postData.put("sign", sign);*/
            JSONObject jsonObject = null;//  openUrlWithJSONObject(baseUrl , postData) ;
            jsonObject = UrlUtil.openWithJSONObject(url, "utf-8");
            Boolean success = jsonObject.getBoolean("success");
            String retMsg = jsonObject.getString("retMsg");
            JSONObject data = jsonObject.getJSONObject("data");
            LOG.info(prefix + ",验证的手机号是：{}, 短信黑名单返回数据:{}", phone , jsonObject);
            if (success != null && success) {
                if (data == null) {
                    LOG.info(prefix + ",验证手机黑名单：phone{},手机号正常", phone);
                } else {
                    returnData.put("grade", data.getString("level"));
                    returnData.put("source", data.getString("source"));
                    returnData.put("phone", phone);
                    return level.contains(data.getString("level"));
                }
            } else {


                LOG.info(prefix + ",验证手机黑名单：phone{},错误信息:{}", phone, jsonObject.toJSONString());
            }


        } catch (Exception e) {

            LOG.info(e + "");
        }


        return false;
    }

/*

    public static JSONObject openUrlWithJSONObject(String url, Map<String, String> data) {
        HttpRequest request = new HttpRequest(HttpResultType.STRING);
        request.setUrl(url);
        Set<String> keys = data.keySet();
        NameValuePair[] parameters = new NameValuePair[keys.size()];
        int i = 0;
        for (String key : keys) {
            parameters[i] = new BasicNameValuePair(key, data.get(key));
            i++;
        }
        request.setParameters(parameters);
        try {

        HttpClientImpl httpClient=    new HttpClientImpl();
            HttpResponse response = httpClient.httpPost(request, true);
            if (null == response) {
                LOG.info("response为null=====");
                return null;
            }
            String res = response.getStringResult();
            LOG.info("getAccessToken：调用获HttpClientImpl取的AccessToken为：{}", res);
            return JSONObject.parseObject(res);
        } catch (Exception e) {

            LOG.info("出错了{}",e);
        }
        return null;
    }
*/

    public static void main(String[] args) {


        String p = "13249818208";
//        String p = "13538178747";
        System.out.println(validPhone(p));
        
    }


}


class UrlUtil {


    static Logger logger = LoggerFactory.getLogger(UrlUtil.class);


    /**
     * 发起一个http请求
     *
     * @param urlParm 请求url
     * @param conding 编码格式
     * @return 返回JSONObject 格式数据
     */
    public static JSONObject openWithJSONObject(String urlParm, String conding) {
        try {
            return JSONObject.parseObject(openWithString(urlParm, conding));
        } catch (Exception e) {
            logger.error(e.toString());
        }

        return null;

    }


    /**
     * 发起一个http请求
     *
     * @param urlParm 请求url
     * @param conding 编码格式
     * @return 返回 字符串 格式数据
     */
    public static String openWithString(String urlParm, String conding) {
        try {

            conding = StringUtils.isBlank(conding) ? "utf-8" : conding;
            URLConnection conn = getURLConnection(urlParm);
            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), conding));
            String line = null;
            StringBuffer result = new StringBuffer();
            while ((line = reader.readLine()) != null) {
                result.append(line);
            }
            reader.close();


            return result.toString();
        } catch (IOException e) {
            logger.error(e.toString());
        }

        return null;

    }

    /**
     * 发起一个http请求
     *
     * @param urlParm 请求url
     * @param conding 编码格式
     * @param data
     * @return 返回 字符串 格式数据
     */
    public static String openWithString(String urlParm, String conding, byte[] data) {
        try {

            conding = StringUtils.isBlank(conding) ? "utf-8" : conding;
            URLConnection conn = getURLConnection(urlParm);
            conn.setDoOutput(true);
            conn.getOutputStream().write(data);
            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), conding));
            String line = null;
            StringBuffer result = new StringBuffer();
            while ((line = reader.readLine()) != null) {
                result.append(line);
            }
            reader.close();


            return result.toString();
        } catch (IOException e) {
            logger.error(e.toString());
        }

        return null;

    }

    public static List<String> openWithList(String urlParm, String conding) {
        try {

            conding = StringUtils.isBlank(conding) ? "utf-8" : conding;
            URLConnection conn = getURLConnection(urlParm);

            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), conding));
            String line = null;
            List<String> list = new ArrayList<String>();
            while ((line = reader.readLine()) != null) {
                list.add(line);
            }
            reader.close();


            return list;
        } catch (IOException e) {
            logger.error(e.toString());
        }

        return new ArrayList<String>();

    }


    /**
     * 获取 URLConnection
     *
     * @param urlParm
     * @return 返回URLConnection
     */
    public static URLConnection getURLConnection(String urlParm) {
        try {
            URL url = new URL(urlParm);
            URLConnection conn = url.openConnection();
            return conn;
        } catch (IOException e) {
            logger.error(e.toString());
        }
        return null;

    }


    /**
     * post 请求 参数xml格式
     *
     * @param urlStr  请求url
     * @param xmlInfo 请求xml格式的参数
     * @return 返回xml格式数据
     */
    public static String openXMLWithString(String urlStr, String xmlInfo) {
        try {
            URL url = new URL(urlStr);
            URLConnection con = url.openConnection();
            con.setDoOutput(true);
//            con.setRequestProperty("Pragma:", "no-cache");
            con.setRequestProperty("Cache-Control", "no-cache");
            con.setRequestProperty("Content-Type", "text/xml");
            // 发送POST请求必须设置如下两行
            con.setDoOutput(true);
            con.setDoInput(true);
//            con.setRequestProperty("Charset", "UTF-8");
            OutputStreamWriter out = new OutputStreamWriter(con
                    .getOutputStream(), "utf-8");
            out.write(xmlInfo);
//            out.w
            out.flush();
            out.close();
            BufferedReader br = new BufferedReader(new InputStreamReader(con
                    .getInputStream(), "utf-8"));
            String line = "";
            StringBuilder stringBuilder = new StringBuilder();
            while ((line = br.readLine()) != null) {
                stringBuilder.append(line);
            }
            br.close();

//            logger.info(stringBuilder + "");
            return stringBuilder.toString();
        } catch (MalformedURLException e) {
            logger.error(e + "");
        } catch (IOException e) {
            logger.error(e + "");
        }
        return null;
    }


}