package com.cornu.report.job;

import com.cornu.report.service.RefreshValidAgentService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * @author 作者：yca
 * @date 2017年7月12日上午11:28:25
 */
@Component("setValidReguserTask")
public class SetValidReguserTask {
	
	private static final Logger LOG = LoggerFactory.getLogger(SetValidReguserTask.class);
	
	@Autowired(required = true)
	@Qualifier(value = "refreshValidAgentService")
	RefreshValidAgentService refreshValidAgentService;
	
	@Value("${set.validreguser.enabled}")
	String enabled;
	
	public void setValidReguserTask() {
		try {
			if(!Boolean.parseBoolean(enabled)){
				return;
			}

			refreshValidAgentService.setValidRegUser();
			LOG.info("thread:{},设置有效注册用户JOB, running......", Thread.currentThread().getId());
		} catch (Exception e) {
			LOG.error("thread:{},设置有效注册用户JOB异常", Thread.currentThread().getId(), e);
		}
	}

}
