package com.cornu.report.dao.bean;

/**
 * Created by Dell on 2017/7/3.
 */
public class ChannelIncomeEntity {

    private String aid;
    private String appid;
    private String did;
    private String uid;
    private String uname;
    private String oid;
    private long otime;
    private String ip;
    private long recharge;
    private String retrade;
    private String status;
    private long ctime;
    private long mtime;
    private long day_for_agent;
    private String channelcd;
    private double channel_income;

    public double getDay_for_agent() {
        return day_for_agent;
    }

    public void setDay_for_agent(long day_for_agent) {
        this.day_for_agent = day_for_agent;
    }

    public String getAid() {
        return aid;
    }

    public void setAid(String aid) {
        this.aid = aid;
    }

    public String getAppid() {
        return appid;
    }

    public void setAppid(String appid) {
        this.appid = appid;
    }

    public String getDid() {
        return did;
    }

    public void setDid(String did) {
        this.did = did;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getUname() {
        return uname;
    }

    public void setUname(String uname) {
        this.uname = uname;
    }

    public String getOid() {
        return oid;
    }

    public void setOid(String oid) {
        this.oid = oid;
    }

    public long getOtime() {
        return otime;
    }

    public void setOtime(long otime) {
        this.otime = otime;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public long getRecharge() {
        return recharge;
    }

    public void setRecharge(long recharge) {
        this.recharge = recharge;
    }

    public String getRetrade() {
        return retrade;
    }

    public void setRetrade(String retrade) {
        this.retrade = retrade;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public long getCtime() {
        return ctime;
    }

    public void setCtime(long ctime) {
        this.ctime = ctime;
    }

    public long getMtime() {
        return mtime;
    }

    public void setMtime(long mtime) {
        this.mtime = mtime;
    }

    public double getChannel_income() {
        return channel_income;
    }

    public void setChannel_income(double channel_income) {
        this.channel_income = channel_income;
    }

    public String getChannelcd() {
        return channelcd;
    }

    public void setChannelcd(String channelcd) {
        this.channelcd = channelcd;
    }
}
