package com.cornu.report.dao.mapper;

import io.swagger.models.auth.In;

import java.util.List;
import java.util.Map;

/**
 * Created by Dell on 2017/6/14.
 */
public interface ApiMapper {
    public List<Map<String, Object>> queryBasicDataForCaipiao(Map<String, Object> params);
    public List<Map<String, Object>> queryBasicDataForAgent(Map<String, Object> params);
    public List<Map<String, Object>> queryAgentDetailData(Map<String, Object> params);
    public List<Map<String, Object>> queryAgentDataAnalysis(Map<String, Object> params);
    public Integer queryValidAgentNum(Map<String, Object> params);
    public List<Map<String, Object>> queryValidAgentNumList(Map<String, Object> params);
    public List<Map<String, Object>> queryBuyLotteryDataList(Map<String, Object> params);
    public List<Map<String, Object>> queryAllChannelcdDataList(Map<String, Object> params);
    public Long queryBuycpmoney(Map<String, Object> params);

    public List<Map<String, Object>> queryChannelIncomeList(Map<String, Object> params);

    public void addRefreshPromotersIncome(Map<String, Object> params);

    public List<Map<String, Object>> queryAreaList();

    public List<Map<String, Object>> queryValidagentBalanceacctList(Map<String, Object> params);
    public List<Map<String, Object>> queryValidreguserBalanceacctList(Map<String, Object> params);

    public Integer queryBuyLotteryUserTotal(Map<String, Object> params);
    
    public List<Map<String, Object>> queryAccountReportList(Map<String, Object> params);
    public List<Map<String, Object>> queryAccountReportByPageList(Map<String, Object> params);
    
    public List<Map<String, Object>> queryAccountReportCurrentList(Map<String, Object> params);
    public List<Map<String, Object>> queryAccountReportCurrentByPageList(Map<String, Object> params);
    
    public Map<String, Object> queryAccountReportTotail(Map<String, Object> params);
    
    public List<Map<String, Object>> queryLotteryRegisteredUsersCount(Map<String, Object> params);
    public List<Map<String, Object>> queryLotteryRegisteredUsersList(Map<String, Object> params);
    
    public List<Map<String, Object>> queryValidRegisteredUsersCount(Map<String, Object> params);
    public List<Map<String, Object>> queryValidRegisteredUsers(Map<String, Object> params);
}
