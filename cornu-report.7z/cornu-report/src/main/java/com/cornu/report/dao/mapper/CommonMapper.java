package com.cornu.report.dao.mapper;

import java.util.Map;

/**
 * Created by Dell on 2017/7/10.
 */
public interface CommonMapper {
    public void addValidagentBalanceacct(Map<String,Object> map);
    public void addValidreguserBalanceacct(Map<String,Object> map);

}
