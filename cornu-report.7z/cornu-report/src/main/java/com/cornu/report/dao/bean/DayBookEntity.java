package com.cornu.report.dao.bean;

public class DayBookEntity {
	private String aid;
	private String appid;
	private String day;
	private long day_recharge_money;
	private long day_rebate_money;
	private long day_for_self;
	private long day_for_agent;
	private long day_total_count;
	private long ctime;
	private long mtime;

	public String getAid() {
		return aid;
	}

	public void setAid(String aid) {
		this.aid = aid;
	}

	public String getAppid() {
		return appid;
	}

	public void setAppid(String appid) {
		this.appid = appid;
	}

	public String getDay() {
		return day;
	}

	public void setDay(String day) {
		this.day = day;
	}

	public long getDay_recharge_money() {
		return day_recharge_money;
	}

	public void setDay_recharge_money(long day_recharge_money) {
		this.day_recharge_money = day_recharge_money;
	}

	public long getDay_rebate_money() {
		return day_rebate_money;
	}

	public void setDay_rebate_money(long day_rebate_money) {
		this.day_rebate_money = day_rebate_money;
	}

	public long getDay_for_self() {
		return day_for_self;
	}

	public void setDay_for_self(long day_for_self) {
		this.day_for_self = day_for_self;
	}

	public long getDay_for_agent() {
		return day_for_agent;
	}

	public void setDay_for_agent(long day_for_agent) {
		this.day_for_agent = day_for_agent;
	}

	public long getDay_total_count() {
		return day_total_count;
	}

	public void setDay_total_count(long day_total_count) {
		this.day_total_count = day_total_count;
	}

	public long getCtime() {
		return ctime;
	}

	public void setCtime(long ctime) {
		this.ctime = ctime;
	}

	public long getMtime() {
		return mtime;
	}

	public void setMtime(long mtime) {
		this.mtime = mtime;
	}

}
