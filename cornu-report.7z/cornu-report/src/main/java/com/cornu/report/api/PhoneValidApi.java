package com.cornu.report.api;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cornu.report.response.ResponseObj;
import com.cornu.report.utils.CommonUtil;

/**
 * @author 作者：yca
 * @date 2017年7月18日下午4:22:55
 */

@Controller
@Api("手机号验证")
public class PhoneValidApi extends BaseApi {
	
	private static final Logger LOG = LoggerFactory.getLogger(PhoneValidApi.class);
	
	@ResponseBody
    @RequestMapping(value = "/phoneValidApi", method = RequestMethod.POST)
    @ApiOperation(value = "查询手机号是否黑名单接口", notes = "查询手机号是否黑名单")
	@ApiImplicitParams({
		@ApiImplicitParam(paramType = "query", name = "phone", dataType = "String", required = true, value = "手机号")
	})
    public ResponseObj phoneValid(HttpServletRequest request, HttpServletResponse response) {
		
		ResponseObj responseObj = new ResponseObj();

        try {
        	
        	String phone = request.getParameter("phone");
        	
        	if(StringUtils.isBlank(phone)){
    			responseObj.setResCode(ResponseObj.FAILED);
    			responseObj.setResMsg("手机号参数为空");
    			return responseObj;
    		}else if(!CommonUtil.validPhone(phone)){
    			responseObj.setResCode(ResponseObj.FAILED);
    			responseObj.setResMsg("手机号参数格式不正确");
    			return responseObj;
    		}
        	
        	boolean falg = phoneBlackListServiceImpl.validPhone(phone);
        	
        	if(falg){
        		
        		responseObj.setResData(0);
        		responseObj.setResMsg("属于黑名单手机号");
        		
        	}else {
				
        		responseObj.setResData(1);
        		responseObj.setResMsg("属于正常手机号");
        		
			}
        	
        } catch (Exception e) {
            LOG.error("查询手机号是否黑名单异常", e);
            responseObj.setResCode(ResponseObj.FAILED);
            responseObj.setResMsg("查询手机号是否黑名单失败, 出现异常:"+e.getMessage());
            return responseObj;
        }

        responseObj.setResCode(ResponseObj.SUCCESS);
        return responseObj;
		
	}

}
