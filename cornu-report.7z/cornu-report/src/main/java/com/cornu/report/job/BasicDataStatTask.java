package com.cornu.report.job;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.cornu.report.service.BasicDataService;

/**
 * 基础数据统计
 * 
 * @author lenovo01
 *
 */
@Component("basicDataStatTask")
public class BasicDataStatTask {
	private static final Logger LOG = LoggerFactory.getLogger(BasicDataStatTask.class);

	@Autowired(required = true)
	@Qualifier(value = "basicDataService")
	BasicDataService basicDataService;
	
	@Value("${job.enabled}")
	String enabled;
	
	public void statBasic() {
		try {
			if(!Boolean.parseBoolean(enabled)){
				return;
			}

			Date curDate = new Date();
			basicDataService.statBasicData(curDate);
			LOG.info("thread:{},基础数据统计......", Thread.currentThread().getId());
		} catch (Exception e) {
			LOG.error("thread:{},基础数据统计异常", Thread.currentThread().getId(), e);
		}
	}

	public void statMixBasic() {
		try {
			if(!Boolean.parseBoolean(enabled)){
				return;
			}

			Date curDate = new Date();
			basicDataService.statMixBasic(curDate);
			LOG.info("thread:{},混合基础数据统计......", Thread.currentThread().getId());
		} catch (Exception e) {
			LOG.error("thread:{},混合基础数据统计异常", Thread.currentThread().getId(), e);
		}
	}

	public void stat9999Basic() {
		try {
			if(!Boolean.parseBoolean(enabled)){
				return;
			}

			Date curDate = new Date();
			basicDataService.stat9999Basic(curDate);
			LOG.info("thread:{},自然代理基础数据统计......", Thread.currentThread().getId());
		} catch (Exception e) {
			LOG.error("thread:{},自然代理基础数据统计异常", Thread.currentThread().getId(), e);
		}
	}

	public void statDetailBasic() {
		try {
			if(!Boolean.parseBoolean(enabled)){
				return;
			}

			Date curDate = new Date();
			basicDataService.statDetailBasic(curDate);
			LOG.info("thread:{},代理人详细基础数据统计......", Thread.currentThread().getId());
		} catch (Exception e) {
			LOG.error("thread:{},代理人详细基础数据统计异常", Thread.currentThread().getId(), e);
		}
	}
	
}
