package com.cornu.report.job;

import com.cornu.report.service.ValidAgentBalanceAcctService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * Created by Dell on 2017/7/11.
 */
@Component("validRegUserBalanceAcctTask")
public class ValidRegUserBalanceAcctTask {
    private static final Logger LOG = LoggerFactory.getLogger(ValidRegUserBalanceAcctTask.class);

    @Autowired(required = true)
    @Qualifier(value = "validAgentBalanceAcctService")
    ValidAgentBalanceAcctService validAgentBalanceAcctService;

    @Value("${validreguser.balanceacct.enabled}")
    String enabled;

    public void validRegUserBalanceAcct() {
        try {
            if(!Boolean.parseBoolean(enabled)){
                return;
            }

            validAgentBalanceAcctService.validRegUserBalanceAcct();
            LOG.info("thread={}, 有效注册用户费用结算JOB, running......", Thread.currentThread().getId());
        } catch (Exception e) {
            LOG.error("thread={}, 有效注册用户费用结算JOB异常", Thread.currentThread().getId(), e);
        }
    }

}
