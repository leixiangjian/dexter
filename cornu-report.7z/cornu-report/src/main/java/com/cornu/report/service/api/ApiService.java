package com.cornu.report.service.api;

import com.alibaba.fastjson.JSONObject;
import com.cornu.report.dao.bean.AgentEntity;
import com.cornu.report.dao.bean.ChannelEntity;
import com.cornu.report.dao.bean.TransactionEntity;
import com.cornu.report.dao.bean.ValidagentBalanceacctEntity;
import com.cornu.report.dao.mapper.ApiMapper;
import com.cornu.report.service.BasicDataService;
import com.cornu.report.utils.DateUtil;
import com.mongodb.DBObject;

import io.swagger.models.auth.In;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationOperation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by Dell on 2017/6/14.
 */
@Service("apiService")
public class ApiService {
    private static final Logger LOG = LoggerFactory.getLogger(ApiService.class);

    @Autowired
    MongoTemplate mongoTemplate;

    @Autowired(required = true)
    @Qualifier(value = "apiMapper")
    ApiMapper apiMapper;

    //推广员提供比例，默认千分之二
    private static final double COMMISSION_VALUE = Double.parseDouble(System.getProperty("promoters.commission.value", "0.002"));

    //组长提供比例，默认千分之一
    private static final double HEADMAN_COMMISSION_VALUE = Double.parseDouble(System.getProperty("headman.commission.value", "0.001"));

    //单个有效代理奖励金额(1000分一个)
    private static final int VALIDAGENT_AWARDMONEY = Integer.parseInt(System.getProperty("validagent.awardmoney", "1000"));

    //单个有效注册用户奖励金额(100分一个)
    private static final int VALIDREGUSER_AWARDMONEY = Integer.parseInt(System.getProperty("validreguser.awardmoney", "100"));

    /**
     * 查询基础数据
     * @param params
     * @return
     * @throws Exception
     */
    public Map<String, Object> queryBasicData(Map<String, Object> params) throws Exception{
        Map<String, Object> resultMap = new HashMap<String, Object>();
        List<Map<String, Object>> basicDataForCaipiao = apiMapper.queryBasicDataForCaipiao(params);
        //汇总
        long B_NEWCPBUYNUM_TOTAL = 0l;//新注册且购彩人数
        long B_BUYCPUSERNUM_TOTAL = 0l;//购彩人数
        long B_NEWCPBUYMONEY_TOTAL = 0l;//新注册且购彩金额
        long B_BUYCPMONEY_TOTAL = 0l;//购彩金额
        long B_NEWCPNUM_TOTAL = 0l;//新注册彩票人数
        long M_ANEWREGNUM_TOTAL = 0l;//新注册代理人数
        for(Map<String, Object> tmpData : basicDataForCaipiao){
            Map<String, Object> agentParams =  new HashMap<String, Object>();
            agentParams.put("channelcds", params.get("channelcds"));
            agentParams.put("beginDate", tmpData.get("B_DATE"));
            agentParams.put("endDate", tmpData.get("B_DATE"));
            List<Map<String, Object>> basicDataForAgent = apiMapper.queryBasicDataForAgent(agentParams);
            if(basicDataForAgent != null && basicDataForAgent.size() > 0){
                if(basicDataForAgent.get(0) != null){
                    tmpData.put("M_ANEWREGNUM", basicDataForAgent.get(0).get("M_ANEWREGNUM"));
                }else{
                    tmpData.put("M_ANEWREGNUM", 0);
                }
            }else{
                tmpData.put("M_ANEWREGNUM", 0);
            }

            B_NEWCPBUYNUM_TOTAL = B_NEWCPBUYNUM_TOTAL+Long.valueOf(tmpData.get("B_NEWCPBUYNUM").toString());
            B_BUYCPUSERNUM_TOTAL = B_BUYCPUSERNUM_TOTAL+Long.valueOf(tmpData.get("B_BUYCPUSERNUM").toString());
            B_NEWCPBUYMONEY_TOTAL = B_NEWCPBUYMONEY_TOTAL+Long.valueOf(tmpData.get("B_NEWCPBUYMONEY").toString());
            B_BUYCPMONEY_TOTAL = B_BUYCPMONEY_TOTAL+Long.valueOf(tmpData.get("B_BUYCPMONEY").toString());
            B_NEWCPNUM_TOTAL = B_NEWCPNUM_TOTAL+Long.valueOf(tmpData.get("B_NEWCPNUM").toString());
            M_ANEWREGNUM_TOTAL = M_ANEWREGNUM_TOTAL+Long.valueOf(tmpData.get("M_ANEWREGNUM").toString());

        }

        Map<String, Object> totalMap = new HashMap<String, Object>();
        totalMap.put("B_NEWCPBUYNUM_TOTAL", B_NEWCPBUYNUM_TOTAL);
        totalMap.put("B_BUYCPUSERNUM_TOTAL", B_BUYCPUSERNUM_TOTAL);
        totalMap.put("B_NEWCPBUYMONEY_TOTAL", B_NEWCPBUYMONEY_TOTAL);
        totalMap.put("B_BUYCPMONEY_TOTAL", B_BUYCPMONEY_TOTAL);
        totalMap.put("B_NEWCPNUM_TOTAL", B_NEWCPNUM_TOTAL);
        totalMap.put("M_ANEWREGNUM_TOTAL", M_ANEWREGNUM_TOTAL);
        resultMap.put("detail_total", totalMap);

        resultMap.put("detail_list", basicDataForCaipiao);

        return resultMap;
    }

    /**
     * 代理员详细数据
     * @param params
     * @return
     * @throws Exception
     */
    public Map<String, Object> getAgentDetailData(Map<String, Object> params) throws Exception{
        Map<String, Object> resultMap = new HashMap<String, Object>();
        List<Map<String, Object>> agentDetailData = apiMapper.queryAgentDetailData(params);
        //汇总
        long D_NEWCPBUYNUM_TOTAL = 0l;//新注册且购彩人数
        long D_BUYCPUSERNUM_TOTAL = 0l;//购彩人数
        long D_NEWCPBUYMONEY_TOTAL = 0l;//新注册且购彩金额
        long D_BUYCPMONEY_TOTAL = 0l;//购彩金额
        long D_NEWCPNUM_TOTAL = 0l;//新注册彩票人数
        long D_BUYREBATEMONEY_TOTAL = 0l;//提成金额
        for(Map<String, Object> tmpData : agentDetailData){
            D_NEWCPBUYNUM_TOTAL = D_NEWCPBUYNUM_TOTAL+Long.valueOf(tmpData.get("D_NEWCPBUYNUM").toString());
            D_BUYCPUSERNUM_TOTAL = D_BUYCPUSERNUM_TOTAL+Long.valueOf(tmpData.get("D_BUYCPUSERNUM").toString());
            D_NEWCPBUYMONEY_TOTAL = D_NEWCPBUYMONEY_TOTAL+Long.valueOf(tmpData.get("D_NEWCPBUYMONEY").toString());
            D_BUYCPMONEY_TOTAL = D_BUYCPMONEY_TOTAL+Long.valueOf(tmpData.get("D_BUYCPMONEY").toString());
            D_NEWCPNUM_TOTAL = D_NEWCPNUM_TOTAL+Long.valueOf(tmpData.get("D_NEWCPNUM").toString());
            D_BUYREBATEMONEY_TOTAL = D_BUYREBATEMONEY_TOTAL+Long.valueOf(tmpData.get("D_BUYREBATEMONEY").toString());
        }

        Map<String, Object> totalMap = new HashMap<String, Object>();
        totalMap.put("D_NEWCPBUYNUM_TOTAL", D_NEWCPBUYNUM_TOTAL);
        totalMap.put("D_BUYCPUSERNUM_TOTAL", D_BUYCPUSERNUM_TOTAL);
        totalMap.put("D_NEWCPBUYMONEY_TOTAL", D_NEWCPBUYMONEY_TOTAL);
        totalMap.put("D_BUYCPMONEY_TOTAL", D_BUYCPMONEY_TOTAL);
        totalMap.put("D_NEWCPNUM_TOTAL", D_NEWCPNUM_TOTAL);
        totalMap.put("D_BUYREBATEMONEY_TOTAL", D_BUYREBATEMONEY_TOTAL);
        resultMap.put("detail_total", totalMap);

        resultMap.put("detail_list", agentDetailData);

        return resultMap;
    }

    /**
     * 代理员数据分析
     * @param params
     * @return
     * @throws Exception
     */
    public Map<String, Object> getAgentDataAnalysis(Map<String, Object> params) throws Exception{
        Map<String, Object> resultMap = new HashMap<String, Object>();

        //查询所有代理人
        Map<String, String> agentInfo = new HashMap<String, String>();
        List<AgentEntity> agentEntitys = mongoTemplate.findAll( AgentEntity.class, "agent");
        for(AgentEntity agentEntity:agentEntitys) {
            String aid = agentEntity.getAid();
            String phone = agentEntity.getPhone();
            agentInfo.put(aid, phone);
        }

        int activeAgentTotal = 0;//活跃代理人数
        int inactiveAgentTotal = 0;//不活跃代理人数
        int newRegisterTotal=0;//新注册人数
        int buyLotteryUserTotal=0;//购彩用户
        //D_AID,D_NEWCPNUM,D_BUYCPUSERNUM
        List<Map<String, Object>> agentDataAnalysis = apiMapper.queryAgentDataAnalysis(params);
        for(Map<String, Object> tmpData : agentDataAnalysis){
            //活跃代理人数
            if(tmpData.get("D_NEWCPNUM") != null
                    && Integer.parseInt(tmpData.get("D_NEWCPNUM").toString()) > 0){
                activeAgentTotal++;
                //新注册人数
                newRegisterTotal = newRegisterTotal+Integer.parseInt(tmpData.get("D_NEWCPNUM").toString());
            }
            //购彩用户
            if(tmpData.get("D_NEWCPBUYNUM") != null
                    && Integer.parseInt(tmpData.get("D_NEWCPBUYNUM").toString()) > 0){
                buyLotteryUserTotal = buyLotteryUserTotal+Integer.parseInt(tmpData.get("D_NEWCPBUYNUM").toString());
            }

            if(StringUtils.isNotBlank(agentInfo.get(tmpData.get("D_AID").toString()))){
                tmpData.put("phone", (String)agentInfo.get(tmpData.get("D_AID").toString()));
            }else{
                tmpData.put("phone", tmpData.get("D_AID").toString());
            }

            //累计用户（占比）
            double proportion = (Double.parseDouble(tmpData.get("D_NEWCPNUM").toString()) / Double.parseDouble(String.valueOf(agentInfo.size())) ) * 100;
            BigDecimal tmpProportion = new BigDecimal((proportion)).setScale(0, BigDecimal.ROUND_HALF_UP);
            String userProportion = tmpProportion.intValue() + "%";
            tmpData.put("registerusers", tmpData.get("D_NEWCPNUM"));
            tmpData.put("buylotteryusers", tmpData.get("D_NEWCPBUYNUM"));
            tmpData.put("userProportion", userProportion);
        }

        inactiveAgentTotal = agentInfo.size() - activeAgentTotal;
        Map<String, Integer> total = new HashMap<String, Integer>();
        total.put("activeAgentTotal", activeAgentTotal);
        total.put("buyLotteryUserTotal", buyLotteryUserTotal);
        total.put("inactiveAgentTotal", inactiveAgentTotal);
        total.put("newRegisterTotal", newRegisterTotal);

        resultMap.put("list", agentDataAnalysis);
        resultMap.put("total", total);

        return resultMap;
    }

    /**
     * 查询推广数据
     * @param params
     * @return
     * @throws Exception
     */
    public Map<String, Object> queryPromotionData(Map<String, Object> params) throws Exception{
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        //Date date = sdf.parse("2017-06-30 00:00:00");
        Map<String, Object> resultMap = new HashMap<String, Object>();
        Double channelIncomeRebate = COMMISSION_VALUE;//组员收入
        Double headmanIncomeRebate = HEADMAN_COMMISSION_VALUE;//组长收入
        Long myEarningsTotal = 0l;
        Long myHeanmanEarningsTotal = 0l;
        Long myAgentIncomeTotal = 0l;
        List<Map<String, Object>> basicDataForCaipiao = apiMapper.queryBasicDataForCaipiao(params);
        for(Map<String, Object> tmpData : basicDataForCaipiao){
            Map<String, Object> agentParams =  new HashMap<String, Object>();
            agentParams.put("channelcd", params.get("channelcd"));
            agentParams.put("beginDate", tmpData.get("B_DATE"));
            agentParams.put("endDate", tmpData.get("B_DATE"));
            List<Map<String, Object>> basicDataForAgent = apiMapper.queryBasicDataForAgent(agentParams);
            if(basicDataForAgent != null && basicDataForAgent.size() > 0){
                if(basicDataForAgent.get(0) != null){
                    Integer m_validagentnum = 0;
                    Integer m_validregnum = 0;
                    Integer myValidAgentEarnings = 0;
                    Integer myValidReguserEarnings = 0;
                    if(basicDataForAgent.get(0).get("M_VALIDAGENTNUM") != null){
                        m_validagentnum = Integer.parseInt(basicDataForAgent.get(0).get("M_VALIDAGENTNUM").toString());
                        myValidAgentEarnings = m_validagentnum * VALIDAGENT_AWARDMONEY;
                    }
                    if(basicDataForAgent.get(0).get("M_VALIDREGNUM") != null){
                        m_validregnum = Integer.parseInt(basicDataForAgent.get(0).get("M_VALIDREGNUM").toString());
                        myValidReguserEarnings = m_validregnum * VALIDREGUSER_AWARDMONEY;
                    }
                    tmpData.put("M_ANEWREGNUM", basicDataForAgent.get(0).get("M_ANEWREGNUM"));
                    tmpData.put("M_VALIDAGENTNUM", m_validagentnum);//有效代理人数
                    tmpData.put("M_VALIDREGNUM", m_validregnum);//有效注册用户数
                    tmpData.put("myValidAgentEarnings", myValidAgentEarnings);//有效代理收益
                    tmpData.put("myValidReguserEarnings", myValidReguserEarnings);//有效注册收益
                }else{
                    tmpData.put("M_ANEWREGNUM", 0);
                    tmpData.put("M_VALIDAGENTNUM", 0);//有效代理人数
                    tmpData.put("M_VALIDREGNUM", 0);//有效注册用户数
                    tmpData.put("myValidAgentEarnings", 0);//有效代理收益
                    tmpData.put("myValidReguserEarnings", 0);//有效注册收益
                }
            }else{
                tmpData.put("M_ANEWREGNUM", 0);
                tmpData.put("M_VALIDAGENTNUM", 0);//有效代理人数
                tmpData.put("M_VALIDREGNUM", 0);//有效注册用户数
                tmpData.put("myValidAgentEarnings", 0);//有效代理收益
                tmpData.put("myValidReguserEarnings", 0);//有效注册收益
            }

            //组员收益=购彩金额 * 0.002
            Double myEarnings = 0d;
            //组长收益=购彩金额 * 0.001
            Double myHeanmanEarnings = 0d;
            //购彩金额
            Date day = sdf.parse(tmpData.get("B_DATE").toString());
            if(tmpData.get("B_BUYCPMONEY") != null){
                //金额单位：分
                long buycpmoney = (long)Double.parseDouble(tmpData.get("B_BUYCPMONEY").toString());
                myEarnings = buycpmoney * channelIncomeRebate;
                myHeanmanEarnings = buycpmoney * headmanIncomeRebate;
            }
            tmpData.put("myEarnings", (long)Double.parseDouble(myEarnings.toString()));
            tmpData.put("myHeanmanEarnings", (long)Double.parseDouble(myHeanmanEarnings.toString()));

            //查询aid的代理收益
            Long myAgentIncome = 0l;
            Map<String, Object> agentIncomeParams = new HashMap<String, Object>();
            agentIncomeParams.put("beginDate", tmpData.get("B_DATE"));
            agentIncomeParams.put("endDate", tmpData.get("B_DATE"));
            agentIncomeParams.put("aid", (String)params.get("aid"));
            List<Map<String, Object>> agentIncomeList = apiMapper.queryAgentDetailData(agentIncomeParams);
            if(agentIncomeList != null && agentIncomeList.size() > 0){
                if(agentIncomeList.get(0) != null){
                    myAgentIncome = Long.parseLong(agentIncomeList.get(0).get("D_BUYREBATEMONEY").toString());
                }
            }
            tmpData.put("myAgentIncome", myAgentIncome);

            myEarningsTotal = myEarningsTotal + (long)Double.parseDouble(myEarnings.toString());
            myHeanmanEarningsTotal = myHeanmanEarningsTotal + (long)Double.parseDouble(myHeanmanEarnings.toString());
            myAgentIncomeTotal = myAgentIncomeTotal + myAgentIncome;
        }

        //获取上个月有效代理人数
        /*Integer lastMonthValidAgentNum = 0;
        String lastMonth = DateUtil.getLastMonth();
        Map<String, Object> lastParams = new HashMap<String, Object>();
        lastParams.put("month", lastMonth+"%");//2017-06%
        lastParams.put("channelcd", params.get("channelcd"));
        Integer lastMonthValidAgentNumList = apiMapper.queryValidAgentNum(lastParams);

        if(lastMonthValidAgentNumList != null){
            lastMonthValidAgentNum = lastMonthValidAgentNumList;
        }
        Map<String, Object> lastMonthMap = new HashMap<String, Object>();
        lastMonthMap.put("lastMonth", lastMonth.substring(lastMonth.length() -1) + "月");
        lastMonthMap.put("lastMonthValidAgentNum", lastMonthValidAgentNum);
        lastMonthMap.put("currentAwardLevel", getLevelMoney(lastMonthValidAgentNum));
        lastMonthMap.put("awardTotalMoney", getLevelMoney(lastMonthValidAgentNum) * lastMonthValidAgentNum);*/

        //获取当月有效代理人数
        /*Integer currentMonthValidAgentNum = 0;
        String currentMonth = DateUtil.getCurrentMonth();
        Map<String, Object> currentParams = new HashMap<String, Object>();
        currentParams.put("month", currentMonth+"%");//2017-06%
        currentParams.put("channelcd", params.get("channelcd"));
        Integer currentMonthValidAgentNumList = apiMapper.queryValidAgentNum(currentParams);

        if(currentMonthValidAgentNumList != null){
            currentMonthValidAgentNum = currentMonthValidAgentNumList;
        }

        //计算当月的我的组员收益
        Double currentMonthMyEarnings = 0d;
        //计算当月的我的组长收益
        Double currentMonthMyHeanmanEarnings = 0d;
        Map<String, Object> queryBuycpmoneyParams = new HashMap<String, Object>();
        queryBuycpmoneyParams.put("month", currentMonth+"%");//2017-06%
        queryBuycpmoneyParams.put("channelcd", params.get("channelcd"));
        Long currentMonthBuycpmoney = apiMapper.queryBuycpmoney(queryBuycpmoneyParams);
        if(currentMonthBuycpmoney != null){
            currentMonthMyEarnings = currentMonthBuycpmoney * channelIncomeRebate;
            currentMonthMyHeanmanEarnings = currentMonthBuycpmoney * headmanIncomeRebate;
        }*/
        //查询aid是否为组长，如果是组长myEarnings=currentMonthMyEarnings+currentMonthMyHeanmanEarnings;
        /*Query parentChannelQuery = new Query();
        parentChannelQuery.addCriteria(Criteria.where("aid").is((String)params.get("aid")));
        parentChannelQuery.addCriteria(Criteria.where("p_channelcd").is((String)params.get("channelcd")));
        parentChannelQuery.addCriteria(Criteria.where("channelcd").is((String)params.get("channelcd")));
        parentChannelQuery.addCriteria(Criteria.where("roletype").is("2"));
        AgentEntity parentAgentEntity = mongoTemplate.findOne(parentChannelQuery,AgentEntity.class, "agent");
        LOG.info("queryPromotionData, 参数={}, currentMonthMyEarnings={}, currentMonthMyHeanmanEarnings={}, myEarningsTotal={}, myHeanmanEarningsTotal={}, myAgentIncomeTotal={}",
                params, currentMonthMyEarnings, currentMonthMyHeanmanEarnings,
                myEarningsTotal, myHeanmanEarningsTotal, myAgentIncomeTotal);
        if(parentAgentEntity != null){
            //说明是组长
            currentMonthMyEarnings = currentMonthMyEarnings+currentMonthMyHeanmanEarnings;
            LOG.info("queryPromotionData, 参数={}, 当前代理是组长, currentMonthMyEarnings+currentMonthMyHeanmanEarnings={}, currentMonthMyHeanmanEarnings={}",
                    params, currentMonthMyEarnings, currentMonthMyHeanmanEarnings);
        }

        Map<String, Object> currentMonthMap = new HashMap<String, Object>();
        currentMonthMap.put("currentMonth", currentMonth.substring(currentMonth.length() -1) + "月");
        currentMonthMap.put("currentMonthValidAgentNum", currentMonthValidAgentNum);
        currentMonthMap.put("currentAwardLevel", getLevelMoney(currentMonthValidAgentNum));
        currentMonthMap.put("awardTotalMoney", getLevelMoney(currentMonthValidAgentNum) * currentMonthValidAgentNum);
        currentMonthMap.put("myEarnings", (long)Double.parseDouble(currentMonthMyEarnings.toString()));*/

        /*resultMap.put("lastmonth_data", lastMonthMap);
        resultMap.put("currentmonth_data", currentMonthMap);*/
        resultMap.put("detail_list", basicDataForCaipiao);

        return resultMap;
    }

    /**
     * 根据有效代理人数获取各级别金额
     * @param validAgentNum
     * @return
     */
    private Integer getLevelMoney( Integer validAgentNum){
        Integer money = 10;
        /*if(validAgentNum < 10 ){
            money = 0;
        }else if(validAgentNum >=10 && validAgentNum <=49){
            money = 2;
        }else if(validAgentNum >=50 && validAgentNum <=99){
            money = 4;
        }else if(validAgentNum >=100 && validAgentNum <=199){
            money = 10;
        }else if(validAgentNum >=200 && validAgentNum <=499){
            money = 15;
        }else if(validAgentNum >=500){
            money = 20;
        }*/
        /*if(validAgentNum > 0){
            money  = validAgentNum * VALIDAGENT_AWARDMONEY;
        }*/

        return money;
    }

    /**
     * 推广数据代理员数据分析
     * @param params
     * @return
     * @throws Exception
     */
    public Map<String, Object> getPromotionAgentDataAnalysis(Map<String, Object> params) throws Exception{
        Map<String, Object> resultMap = new HashMap<String, Object>();

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        
        Long timeStart = null;
        Long timeEnd = null;
        		
        String beginDate = String.valueOf(params.get("beginDate"));
        String endDate = String.valueOf(params.get("endDate"));

        if(StringUtils.isNotBlank(beginDate) && !"null".equals(beginDate)){
        	
        	timeStart = sdf.parse(String.format("%s 00:00:00", beginDate)).getTime();
        	
        }
        
        if(StringUtils.isNotBlank(endDate) && !"null".equals(endDate)){
        	
        	timeEnd = sdf.parse(String.format("%s 23:59:59", endDate)).getTime();
        	
        }


        /*Long allCaipiaoRegNum = 0l;
        //查询所有代理邀请的彩票注册人数
        Query appRegQuery = new Query();
        appRegQuery.addCriteria(Criteria.where("recharge").is(0));
        *//*List<TransactionEntity> appRegtransactionEntitys = mongoTemplate.find(appRegQuery, TransactionEntity.class, "transaction");
        if(appRegtransactionEntitys != null && appRegtransactionEntitys.size() > 0){
            allCaipiaoRegNum = appRegtransactionEntitys.size();
        }*//*
        Long allCaipiaoRegCount = mongoTemplate.count(appRegQuery, TransactionEntity.class, "transaction");
        if(allCaipiaoRegCount != null && allCaipiaoRegCount > 0){
            allCaipiaoRegNum = allCaipiaoRegCount;
        }*/

        //查询channelcd下所有代理人
        Map<String, String> agentInfo = new HashMap<String, String>();
        String channelcd = (String)params.get("channelcd");
        Query queryAgentByChannelcd = new Query();
        queryAgentByChannelcd.addCriteria(Criteria.where("channelcd").is(channelcd));

        List<String> aids = new ArrayList<String>();
        List<AgentEntity> agentEntitys = mongoTemplate.find(queryAgentByChannelcd, AgentEntity.class, "agent");
        for(AgentEntity agentEntity:agentEntitys) {
            String aid = agentEntity.getAid();
            String phone = agentEntity.getPhone();
            agentInfo.put(aid, phone);
            aids.add(aid);
        }
        if(agentEntitys == null || agentEntitys.size() ==0){
            resultMap.put("list", new ArrayList<Map<String, Object>>());
            resultMap.put("total", "");
            return resultMap;
        }

        int agentTotal = 0;//channelcd下的代理总数
        int newRegisterTotal=0;//新增彩票注册人数
        int buyLotteryUserTotal=0;//购彩用户数
        long buyLotteryMoneyTotal=0;//购彩金额

        //有效代理人数
        Integer validAgentNum =0;
        //有效代理人收益
        Integer validAgentEarnings = 0;
        //有效注册用户数
        Integer validReguserNum = 0;
        //有效注册用户收益
        Integer validReguserEarnings = 0;

        if(aids != null && aids.size() > 0){
            params.put("aids", aids);
            agentTotal = aids.size();
        }

        //D_AID,D_NEWCPNUM,D_BUYCPUSERNUM,D_BUYCPMONEY
        List<Map<String, Object>> agentDataAnalysis = apiMapper.queryAgentDataAnalysis(params);
        for(Map<String, Object> tmpData : agentDataAnalysis){
            tmpData.put("phone", tmpData.get("D_AID").toString());
            tmpData.put("registerusers", 0);//新增注册用户
            tmpData.put("buylotteryusers", 0);//购彩用户
            tmpData.put("buylotterymoney", 0);//购彩金额
            tmpData.put("userProportion", "0%");//累计用户占比(去除)
            tmpData.put("validreguser", 0);//有效注册用户数
            tmpData.put("validreguserEarnings", 0);//有效注册收益
            tmpData.put("validagentEarnings", 0);//有效代理收益
            tmpData.put("channelMemberEarnings", 0);//组员推广收益

            //代理手机号码
            if(StringUtils.isNotBlank(agentInfo.get(tmpData.get("D_AID").toString()))){
                String tmpPhone = (String)agentInfo.get(tmpData.get("D_AID").toString());
                //tmpPhone = tmpPhone.substring(0, 3) + "****" + tmpPhone.substring(7);
                tmpData.put("phone", tmpPhone);
            }
            //新增彩票注册人数
            if(tmpData.get("D_NEWCPNUM") != null
                    && Integer.parseInt(tmpData.get("D_NEWCPNUM").toString()) > 0){
                tmpData.put("registerusers", tmpData.get("D_NEWCPNUM"));//新增注册用户
                newRegisterTotal = newRegisterTotal+Integer.parseInt(tmpData.get("D_NEWCPNUM").toString());
            }
            //购彩用户数
            /*if(tmpData.get("D_BUYCPUSERNUM") != null
                    && Integer.parseInt(tmpData.get("D_BUYCPUSERNUM").toString()) > 0){
                tmpData.put("buylotteryusers", tmpData.get("D_BUYCPUSERNUM"));//购彩用户
                buyLotteryUserTotal = buyLotteryUserTotal+Integer.parseInt(tmpData.get("D_BUYCPUSERNUM").toString());
            }*/

            Map<String, Object> buyLotteryUserParams = new HashMap<String, Object>();
            buyLotteryUserParams.put("aid", tmpData.get("D_AID").toString());
            
            if(StringUtils.isNotBlank(beginDate) && !"null".equals(beginDate)){
            	
            	buyLotteryUserParams.put("beginDate", beginDate + " 00:00:00");
            	
            }
            
            if(StringUtils.isNotBlank(endDate) && !"null".equals(endDate)){
            	
            	buyLotteryUserParams.put("endDate", endDate + " 23:59:59");
            	
            }
            
            Integer buyLotteryUserCount = apiMapper.queryBuyLotteryUserTotal(buyLotteryUserParams);
            if(buyLotteryUserCount != null && buyLotteryUserCount > 0){
                tmpData.put("buylotteryusers", buyLotteryUserCount);//购彩用户
                buyLotteryUserTotal = buyLotteryUserTotal+buyLotteryUserCount;
            }

            //购彩金额和组员推广收益
            if(tmpData.get("D_BUYCPMONEY") != null
                    && Integer.parseInt(tmpData.get("D_BUYCPMONEY").toString()) > 0){
                tmpData.put("buylotterymoney", tmpData.get("D_BUYCPMONEY"));//购彩金额
                tmpData.put("channelMemberEarnings", Integer.parseInt(tmpData.get("D_BUYCPMONEY").toString()) * COMMISSION_VALUE);//组员推广收益
                buyLotteryMoneyTotal = buyLotteryMoneyTotal + Long.parseLong(tmpData.get("D_BUYCPMONEY").toString());
            }

            //有效代理收益
            Map<String, Object> validAgentParams = new HashMap<String, Object>();
            validAgentParams.put("VB_AID", tmpData.get("D_AID").toString());
            if(timeStart != null){
            	
            	validAgentParams.put("timeStart", timeStart/1000);
            	
            }
            if(timeEnd != null){
            	
            	validAgentParams.put("timeEnd", timeEnd/1000);
            	
            }
            List<Map<String, Object>> validagentList = apiMapper.queryValidagentBalanceacctList(validAgentParams);
            if(validagentList !=null && validagentList.size() >0){
                tmpData.put("validagentEarnings", validagentList.get(0).get("VB_AWARDMONEY"));//有效代理收益
                validAgentNum = validAgentNum + validagentList.size();
                validAgentEarnings = validAgentEarnings + Integer.parseInt(validagentList.get(0).get("VB_AWARDMONEY").toString());
            }

            //有效注册用户数和有效注册收益
            Map<String, Object> validReguserParams = new HashMap<String, Object>();
            validReguserParams.put("VB_AID", tmpData.get("D_AID").toString());
            if(timeStart != null){
            	
            	validReguserParams.put("timeStart", timeStart/1000);
            	
            }
            if(timeEnd != null){
            	
            	validReguserParams.put("timeEnd", timeEnd/1000);
            	
            }
            List<Map<String, Object>> validReguserList = apiMapper.queryValidreguserBalanceacctList(validReguserParams);
            if(validReguserList != null && validReguserList.size() > 0){
                tmpData.put("validreguser", validReguserList.size());
                tmpData.put("validreguserEarnings", validReguserList.size() * VALIDREGUSER_AWARDMONEY);
                validReguserNum = validReguserNum + validReguserList.size();
                validReguserEarnings = validReguserEarnings + (validReguserList.size() * VALIDREGUSER_AWARDMONEY);
            }

            /*Long caipiaoRegNumByAid = 0l;
            //累计用户（占比）
            double proportion = 0d;
            if(allCaipiaoRegNum > 0){
                //查询aid邀请的彩票注册人数
                //查询所有代理邀请的彩票注册人数
                Query caipiaoRegByAidQuery = new Query();
                caipiaoRegByAidQuery.addCriteria(Criteria.where("aid").is(tmpData.get("D_AID").toString()));
                caipiaoRegByAidQuery.addCriteria(Criteria.where("recharge").is(0));
                Long caipiaoRegByAidCount = mongoTemplate.count(caipiaoRegByAidQuery, TransactionEntity.class, "transaction");
                if(caipiaoRegByAidCount != null && caipiaoRegByAidCount > 0){
                    caipiaoRegNumByAid = caipiaoRegByAidCount;
                }

                proportion =  Double.parseDouble(caipiaoRegNumByAid.toString())/Double.parseDouble(allCaipiaoRegNum.toString()) * 100;
            }
            BigDecimal tmpProportion = new BigDecimal((proportion)).setScale(0, BigDecimal.ROUND_HALF_UP);
            String userProportion = String.format("%s%s%s%s%s", caipiaoRegNumByAid, "(", tmpProportion.intValue(),"%", ")");
            tmpData.put("registerusers", tmpData.get("D_NEWCPNUM"));//新增注册用户
            tmpData.put("buylotteryusers", tmpData.get("D_BUYCPUSERNUM"));//购彩用户
            tmpData.put("userProportion", "0%");//累计用户占比(去除)*/
        }

        /*//有效代理人数
        Integer validAgentNum =0;
        //有效代理人收益
        Integer validAgentEarnings = 0;
        //有效注册用户数
        Integer validReguserNum = 0;
        //有效注册用户收益
        Integer validReguserEarnings = 0;
        List<Map<String, Object>> validDataList = apiMapper.queryValidAgentNumList(params);
        if(validDataList != null && validDataList.size() > 0){
            if(validDataList.get(0) != null){
                validAgentNum = Integer.parseInt(validDataList.get(0).get("M_VALIDAGENTNUM").toString());
                validAgentEarnings = validAgentNum * VALIDAGENT_AWARDMONEY;
                validReguserNum = Integer.parseInt(validDataList.get(0).get("M_VALIDREGNUM").toString());
                validReguserEarnings = validReguserNum * VALIDREGUSER_AWARDMONEY;
            }
        }*/

        Map<String, Object> total = new HashMap<String, Object>();
        total.put("validAgentNum", validAgentNum);//有效代理人数
        total.put("validAgentEarnings", validAgentEarnings);//有效代理人收益
        total.put("validReguserNum", validReguserNum);//有效注册用户数
        total.put("validReguserEarnings", validReguserEarnings);//有效注册用户收益
        total.put("agentTotal", agentTotal);//代理总数
        total.put("buyLotteryUserTotal", buyLotteryUserTotal);//购彩用户数总数
        total.put("newRegisterTotal", newRegisterTotal);//新增彩票注册人数总数
        total.put("buyLotteryMoneyTotal", buyLotteryMoneyTotal);//购彩金额总数
        total.put("channelMemberEarnings", buyLotteryMoneyTotal * COMMISSION_VALUE);//组员推广收益

        resultMap.put("list", agentDataAnalysis);
        resultMap.put("total", total);

        return resultMap;
    }

    /**
     * 推广数据组员数据
     * @param params
     * @return
     * @throws Exception
     */
    public Map<String, Object> getPromotionMemberData(Map<String, Object> params) throws Exception{
        long starttime = System.currentTimeMillis();

        Map<String, Object> resultMap = new HashMap<String, Object>();
        List<String> channelcdList  = new ArrayList<String>();
        Map<String, String> channelcdAndNameDict = new HashMap<String, String>();
        //获取所有渠道
        List<ChannelEntity> channelEntitys = mongoTemplate.findAll(ChannelEntity.class,
                "channel_info");
        for(ChannelEntity channelEntity : channelEntitys) {
            String channelCd = channelEntity.getChannelcd();
            String channelName = channelEntity.getChannelname();
            channelcdAndNameDict.put(channelCd, channelName);
        }

        if(params.containsKey("p_channelcd")){//此处一定是组长的p_channelcd
            //根据组长的p_channelcd查询组员的channelcd
            String p_channelcd = (String)params.get("p_channelcd");
            Query queryAgentByChannelcd = new Query();
            queryAgentByChannelcd.addCriteria(Criteria.where("p_channelcd").is(p_channelcd));

            List<AgentEntity> agentEntitys = mongoTemplate.find(queryAgentByChannelcd, AgentEntity.class, "agent");
            for(AgentEntity agentEntity:agentEntitys) {
                String channelcd = agentEntity.getChannelcd();
                if(StringUtils.isNotBlank(channelcd)){
                    channelcdList.add(channelcd);
                }
            }
            LOG.info("getPromotionMemberData 根据p_channelcd={}, 查询组员的channelcd, 查询结果={}",
                    p_channelcd, channelcdList);
            //如果没有组员数据就返回空
            if(channelcdList == null || channelcdList.size() == 0){
                /*resultMap.put("lastmonth_data", null);
                resultMap.put("currentmonth_data", null);*/
                resultMap.put("detail_list", null);
                return resultMap;
            }
        }else if(params.containsKey("p_channelcds")){//此处一定是区域组编码（LW0022,LW0075）
            String p_channelcds = (String)params.get("p_channelcds");
            String[] pChannelcdArr = p_channelcds.split(",");
            List<String> pChannelcds = new ArrayList<String>();
            for(String channelcd : pChannelcdArr){
                pChannelcds.add(channelcd);
            }

            Query queryAgentByChannelcd = new Query();
            queryAgentByChannelcd.addCriteria(Criteria.where("p_channelcd").in(pChannelcds));

            List<AgentEntity> agentEntitys = mongoTemplate.find(queryAgentByChannelcd, AgentEntity.class, "agent");
            for(AgentEntity agentEntity:agentEntitys) {
                String channelcd = agentEntity.getChannelcd();
                if(StringUtils.isNotBlank(channelcd)){
                    channelcdList.add(channelcd);
                }
            }
            LOG.info("getPromotionMemberData 根据p_channelcds={}, 查询组员的channelcd, 查询结果={}",
                    p_channelcds, channelcdList);
            //如果没有组员数据就返回空
            if(channelcdList == null || channelcdList.size() == 0){
                /*resultMap.put("lastmonth_data", null);
                resultMap.put("currentmonth_data", null);*/
                resultMap.put("detail_list", null);
                return resultMap;
            }
        }else{
            //所有渠道
            for(ChannelEntity channelEntity : channelEntitys) {
                String channelCd = channelEntity.getChannelcd();
                channelcdList.add(channelCd);
            }
        }

        //获取上个月有效代理总数、注册代理总数、购彩用户总数
        /*Integer lastMonthValidAgentTotal = 0;//有效代理总数
        Integer lastMonthRegAgentTotal = 0;//注册代理总数
        Integer lastMonthBuyLotteryUserTotal = 0;//购彩用户总数
        String lastMonth = DateUtil.getLastMonth();*/
        /*Map<String, Object> lastParams = new HashMap<String, Object>();
        lastParams.put("month", lastMonth+"%");//2017-06%
        lastParams.put("channelcds", channelcdList);
        List<Map<String, Object>> lastMonthValidAgentNumList = apiMapper.queryValidAgentNumList(lastParams);
        if(lastMonthValidAgentNumList != null && lastMonthValidAgentNumList.size() > 0){
            if(lastMonthValidAgentNumList.get(0) != null){
                lastMonthValidAgentTotal = Integer.valueOf(lastMonthValidAgentNumList.get(0).get("M_VALIDAGENTNUM").toString());
                lastMonthRegAgentTotal = Integer.valueOf(lastMonthValidAgentNumList.get(0).get("M_ANEWREGNUM").toString());
            }
        }

        //查询购彩用户数据
        List<Map<String, Object>> lastMonthBuyLotteryDataList = apiMapper.queryBuyLotteryDataList(lastParams);
        if(lastMonthBuyLotteryDataList!=null && lastMonthBuyLotteryDataList.size() > 0){
            if(lastMonthBuyLotteryDataList.get(0) != null){
                lastMonthBuyLotteryUserTotal = Integer.valueOf(lastMonthBuyLotteryDataList.get(0).get("BUYCPUSERNUM").toString());
            }
        }*/

        /*Map<String, Object> lastMonthMap = new HashMap<String, Object>();
        lastMonthMap.put("lastMonth", lastMonth.substring(lastMonth.length() -1) + "月");
        lastMonthMap.put("lastMonthValidAgentTotal", lastMonthValidAgentTotal);
        lastMonthMap.put("lastMonthRegAgentTotal", lastMonthRegAgentTotal);
        lastMonthMap.put("lastMonthBuyLotteryUserTotal", lastMonthBuyLotteryUserTotal);*/

        //获取当月有效代理总数、注册代理总数、购彩用户总数
        /*Integer currentMonthValidAgentTotal = 0;//有效代理总数
        Integer currentMonthRegAgentTotal = 0;//注册代理总数
        Integer currentMonthBuyLotteryUserTotal = 0;//购彩用户总数
        String currentMonth = DateUtil.getCurrentMonth();*/
       /* Map<String, Object> currentParams = new HashMap<String, Object>();
        currentParams.put("month", currentMonth+"%");//2017-06%
        currentParams.put("channelcds", channelcdList);
        List<Map<String, Object>> currentMonthValidAgentNumList = apiMapper.queryValidAgentNumList(currentParams);
        if(currentMonthValidAgentNumList != null && currentMonthValidAgentNumList.size() > 0){
            if(currentMonthValidAgentNumList.get(0) != null){
                currentMonthValidAgentTotal = Integer.valueOf(currentMonthValidAgentNumList.get(0).get("M_VALIDAGENTNUM").toString());
                currentMonthRegAgentTotal = Integer.valueOf(currentMonthValidAgentNumList.get(0).get("M_ANEWREGNUM").toString());
            }
        }

        //查询购彩用户数据
        List<Map<String, Object>> currentMonthbuyLotteryDataList = apiMapper.queryBuyLotteryDataList(currentParams);
        if(currentMonthbuyLotteryDataList!=null && currentMonthbuyLotteryDataList.size() > 0){
            if(currentMonthbuyLotteryDataList.get(0) != null){
                currentMonthBuyLotteryUserTotal = Integer.valueOf(currentMonthbuyLotteryDataList.get(0).get("BUYCPUSERNUM").toString());
            }
        }*/

        /*Map<String, Object> currentMonthMap = new HashMap<String, Object>();
        currentMonthMap.put("currentMonth", currentMonth.substring(currentMonth.length() -1) + "月");
        currentMonthMap.put("currentMonthValidAgentTotal", currentMonthValidAgentTotal);
        currentMonthMap.put("currentMonthRegAgentTotal", currentMonthRegAgentTotal);
        currentMonthMap.put("currentMonthBuyLotteryUserTotal", currentMonthBuyLotteryUserTotal);*/

        //所有组员数据
        params.put("channelcds", channelcdList);
        List<Map<String, Object>> allChannelcdDataList = apiMapper.queryAllChannelcdDataList(params);
        /*//有效代理人总数
        Integer validAgentTotal = 0;
        Integer tmpValidAgentTotal= apiMapper.queryValidAgentNum(params);
        if(tmpValidAgentTotal != null){
            validAgentTotal = tmpValidAgentTotal;
        }*/
        for(Map<String, Object> map : allChannelcdDataList){
            map.put("M_CHANNEL_NAME", channelcdAndNameDict.get(map.get("M_CHANNEL_CD") == null ? "0":map.get("M_CHANNEL_CD").toString()));
            //有效代理占比
            /*String M_VALIDAGENTNUM = "0";
            if(map.get("M_VALIDAGENTNUM") != null && !"null".equals(map.get("M_VALIDAGENTNUM"))){
                M_VALIDAGENTNUM = map.get("M_VALIDAGENTNUM").toString();
            }*/
            /*double proportion = 0d;
            if(validAgentTotal > 0){
                proportion = (Double.parseDouble(M_VALIDAGENTNUM) / Double.parseDouble(String.valueOf(validAgentTotal)) ) * 100;
            }

            BigDecimal tmpProportion = new BigDecimal((proportion)).setScale(0, BigDecimal.ROUND_HALF_UP);
            String userProportion = tmpProportion.intValue() + "%";
            map.put("VALIDAGENT_PROPORTION", userProportion);*/

            //获取当前奖励级别
            /*Integer tmpCurrentMonthValidAgentNum = 0;
            String tmpCurrentMonth = DateUtil.getCurrentMonth();
            Map<String, Object> tmpCurrentParams = new HashMap<String, Object>();
            tmpCurrentParams.put("month", tmpCurrentMonth+"%");//2017-06%
            tmpCurrentParams.put("channelcd", map.get("M_CHANNEL_CD").toString());
            Integer tmpCurrentMonthValidAgentNumList = apiMapper.queryValidAgentNum(tmpCurrentParams);

            if(tmpCurrentMonthValidAgentNumList != null){
                tmpCurrentMonthValidAgentNum = tmpCurrentMonthValidAgentNumList;
            }

            map.put("CURRENT_AWARDLEVEL", getLevelMoney(tmpCurrentMonthValidAgentNum));*/

            Integer buycpusernum =0;//购彩人数
            Long buycpmoney =0l;//购彩金额
            //查询购彩用户数据
            Map<String, Object> buyLotteryParams = new HashMap<String, Object>();
            buyLotteryParams.put("channelcd", map.get("M_CHANNEL_CD").toString());
            buyLotteryParams.put("beginDate", (String)params.get("beginDate"));
            buyLotteryParams.put("endDate", (String)params.get("endDate"));
            List<Map<String, Object>> buyLotteryDataList = apiMapper.queryBuyLotteryDataList(buyLotteryParams);
            if(buyLotteryDataList!=null && buyLotteryDataList.size() > 0){
                if(buyLotteryDataList.get(0) != null){
                    Map<String, Object> tmpMap = buyLotteryDataList.get(0);
                    if(tmpMap != null && tmpMap.size() > 0){
                        if(tmpMap.get("BUYCPUSERNUM") != null){
                            //buycpusernum = Long.valueOf(tmpMap.get("BUYCPUSERNUM").toString());
                        }
                        if(tmpMap.get("BUYCPMONEY") != null){
                            buycpmoney = Long.valueOf(tmpMap.get("BUYCPMONEY").toString());
                        }
                    }
                }
            }

            //查询购彩用户去重总数
            Map<String, Object> tmpParams = new HashMap<String, Object>();
            tmpParams.put("channelcd", map.get("M_CHANNEL_CD").toString());
            tmpParams.put("beginDate", (String)params.get("beginDate") + " 00:00:00");
            tmpParams.put("endDate", (String)params.get("endDate") + " 23:59:59");

            Integer tmpBuycpuserTotal = apiMapper.queryBuyLotteryUserTotal(tmpParams);
            if(tmpBuycpuserTotal !=null && tmpBuycpuserTotal > 0){
                buycpusernum = tmpBuycpuserTotal;
            }

            map.put("BUYCPUSERNUM", buycpusernum);
            map.put("BUYCPMONEY", buycpmoney);
            map.put("HEADMANINCOMEMONEY", buycpmoney * HEADMAN_COMMISSION_VALUE);
        }

        /*resultMap.put("lastmonth_data", lastMonthMap);
        resultMap.put("currentmonth_data", currentMonthMap);*/
        resultMap.put("detail_list", allChannelcdDataList);

        long endtime = System.currentTimeMillis();

        LOG.info("查询组员推广数据, getPromotionMemberData, 参数={}, 耗时={}秒", params, ((endtime-starttime)/1000));
        return resultMap;
    }

    /**
     * 地区数据分析
     * @param params
     * @return
     * @throws Exception
     */
    public Map<String, Object> getAreaDataAnalysis(Map<String, Object> params) throws Exception{
        Map<String, Object> resultMap = new HashMap<String, Object>();
        //查询地区数据
        List<Map<String, Object>> areaList = apiMapper.queryAreaList();
        if(areaList == null || areaList.size() ==0 ){
            resultMap.put("detail_list", null);
            return resultMap;
        }

        List<Map<String, Object>> areaDataAnalysisList = new ArrayList<Map<String, Object>>();
        Map<String, Object> areaDataAnalysisMap = null;
        for(Map<String, Object> map : areaList){
            LOG.info("getAreaDataAnalysis, areaDataAnalysisList.map={}", map);
            areaDataAnalysisMap = new HashMap<String, Object>();
            if(map.get("CA_AREA_NAME") == null || map.get("CA_AREA_CHANNELS") == null){
                continue;
            }
            String areaName = (String)map.get("CA_AREA_NAME");//区域名称
            String areaCode = (String)map.get("CA_AREA_CODE");//区域编码
            String areaChannels = (String)map.get("CA_AREA_CHANNELS");
            List<String> pChannelcds = new ArrayList<String>();
            String[] areaChannelcds = areaChannels.split(",");//区域组编码（LW0103,LW0025）
            for(String s : areaChannelcds){
                pChannelcds.add(s);
            }
            Query channelQuery = new Query();
            channelQuery.addCriteria(Criteria.where("p_channelcd").in(pChannelcds));
            channelQuery.addCriteria(Criteria.where("roletype").in("2", "3"));
            List<AgentEntity> agentEntitys = mongoTemplate.find(channelQuery, AgentEntity.class, "agent");
            if(agentEntitys == null && agentEntitys.size() == 0){
                LOG.info("getAreaDataAnalysis, agentEntitys is null ");
                continue;
            }
            List<String> channelcds = new ArrayList<String>();
            for(AgentEntity agentEntity : agentEntitys){
                channelcds.add(agentEntity.getChannelcd());
            }
            LOG.info("getAreaDataAnalysis, find channelcd by pChannelcds, channelcds={}", channelcds);

            //获取有效代理数、注册代理数
            Integer validAgentTotal = 0;//有效代理数
            Integer regAgentTotal = 0;//注册代理数
            Map<String, Object> agentParams = new HashMap<String, Object>();
            agentParams.put("beginDate", params.get("beginDate"));
            agentParams.put("endDate", params.get("endDate"));
            agentParams.put("channelcds", channelcds);
            List<Map<String, Object>> agentDataList = apiMapper.queryValidAgentNumList(agentParams);
            if(agentDataList != null && agentDataList.size() > 0){
                if(agentDataList.get(0) != null){
                    validAgentTotal = Integer.valueOf(agentDataList.get(0).get("M_VALIDAGENTNUM").toString());
                    regAgentTotal = Integer.valueOf(agentDataList.get(0).get("M_ANEWREGNUM").toString());
                }
            }
            areaDataAnalysisMap.put("AREA_NAME", areaName);
            areaDataAnalysisMap.put("AREA_CODE", areaCode);
            areaDataAnalysisMap.put("AREA_CHANNELS", areaChannels);
            areaDataAnalysisMap.put("VALIDAGENTNUM", validAgentTotal);
            areaDataAnalysisMap.put("ANEWREGNUM", regAgentTotal);

            //获取彩票注册用户数、购彩用户数、销量
            Long newCpNumTotal = 0l;//彩票注册用户数
            Long buyCpMoneyTotal = 0l;//销量
            List<Map<String, Object>> caipiaoDataList = apiMapper.queryBuyLotteryDataList(agentParams);
            if(caipiaoDataList != null && caipiaoDataList.size() > 0){
                if(caipiaoDataList != null){
                    newCpNumTotal = Long.valueOf(caipiaoDataList.get(0).get("NEWCPNUM").toString());
                    //buyCpUserNumTotal = Long.valueOf(caipiaoDataList.get(0).get("BUYCPUSERNUM").toString());
                    buyCpMoneyTotal = Long.valueOf(caipiaoDataList.get(0).get("BUYCPMONEY").toString());
                }
            }

            Integer buyCpUserNumTotal = 0;//购彩用户数
            Map<String, Object> buyCpUserParams = new HashMap<String, Object>();
            buyCpUserParams.put("channelcds", channelcds);
            buyCpUserParams.put("beginDate", (String)params.get("beginDate") + " 00:00:00");
            buyCpUserParams.put("endDate", (String)params.get("endDate") + " 23:59:59");

            if(channelcds.size() > 0){
                Integer tmpBuycpuserTotal = apiMapper.queryBuyLotteryUserTotal(buyCpUserParams);
                if(tmpBuycpuserTotal != null && tmpBuycpuserTotal > 0){
                    buyCpUserNumTotal = tmpBuycpuserTotal;
                }
            }

            areaDataAnalysisMap.put("NEWCPNUM", newCpNumTotal);
            areaDataAnalysisMap.put("BUYCPUSERNUM", buyCpUserNumTotal);
            areaDataAnalysisMap.put("BUYCPMONEY", buyCpMoneyTotal);

            areaDataAnalysisList.add(areaDataAnalysisMap);
        }
        resultMap.put("detail_list", areaDataAnalysisList);

        return resultMap;
    }

    /**
     * 查询代理员上周二到当前时间的账户信息接口
     * @param params
     * @return
     * @throws Exception
     */
    public Map<String, Object> getAgentAccountInfo(Map<String, Object> params) throws Exception {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Map<String, Object> resultMap = new HashMap<String, Object>();
        String phone = (String)params.get("phone");
        double agentIncomeTotal = 0;//代理收益
        double channelIncomeTotal = 0;//组员收益
        double headmanIncomeTotal = 0;//组长收益
        long validAgentIncomeTotal = 0;//有效代理收益
        long validReguserIncomeTotal = 0;//有效注册用户收益

        Query agentQuery = new Query();
        agentQuery.addCriteria(Criteria.where("phone").is(phone));
        AgentEntity agentEntity = mongoTemplate.findOne(agentQuery, AgentEntity.class, "agent");
        if(agentEntity == null){
            resultMap.put("agentIncomeTotal", (long)agentIncomeTotal);
            resultMap.put("incomeTotal", (long)(channelIncomeTotal+headmanIncomeTotal));
            resultMap.put("memberIncomeTotal", (long)channelIncomeTotal);
            resultMap.put("headmanIncomeTotal", (long)headmanIncomeTotal);
            resultMap.put("validAgentIncomeTotal", validAgentIncomeTotal);
            resultMap.put("validReguserIncomeTotal", validReguserIncomeTotal);

            return resultMap;
        }
        String aid = agentEntity.getAid();
        LOG.info("getAgentAccountInfo, 参数={}, aid={}", params, aid);

        Map<String, Object> dateMap = getLastTuesdayToThisMondayDateStr();
        if(dateMap == null && dateMap.size() == 0){
            resultMap.put("agentIncomeTotal", (long)agentIncomeTotal);
            resultMap.put("incomeTotal", (long)(channelIncomeTotal+headmanIncomeTotal));
            resultMap.put("memberIncomeTotal", (long)channelIncomeTotal);
            resultMap.put("headmanIncomeTotal", (long)headmanIncomeTotal);
            resultMap.put("validAgentIncomeTotal", validAgentIncomeTotal);
            resultMap.put("validReguserIncomeTotal", validReguserIncomeTotal);
            return resultMap;
        }

        long timeStart = sdf.parse((String)dateMap.get("beginDate")).getTime();
        long timeEnd = sdf.parse((String)dateMap.get("endDate")).getTime();

        //获取这个时间段内的代理收益
        /*Query agentIncomeQuery = new Query();
        agentIncomeQuery.addCriteria(Criteria.where("aid").is(aid));
        agentIncomeQuery.addCriteria(Criteria.where("recharge").gt(0));
        agentIncomeQuery.addCriteria(Criteria.where("ctime").gte(timeStart / 1000).lte(timeEnd / 1000));
        List<TransactionEntity> agentIncomeTransactionEntitys = mongoTemplate.find(agentIncomeQuery, TransactionEntity.class,"transaction");
        for(TransactionEntity agentIncomeTransactionEntity :agentIncomeTransactionEntitys){
            double buyCpMoney = agentIncomeTransactionEntity.getDay_for_agent();
            agentIncomeTotal = agentIncomeTotal+buyCpMoney;
        }*/

        AggregationOperation agentIncomeMatch = Aggregation.match(Criteria.where("aid").is(aid).and("recharge").gt(0).and("ctime").gte(timeStart / 1000).lte(timeEnd / 1000));
        AggregationOperation agentIncomeGroup = Aggregation.group("null").sum("day_for_agent").as("rebateMoney");
        Aggregation agentIncomeAggregation = Aggregation.newAggregation(agentIncomeMatch,agentIncomeGroup);
        AggregationResults<DBObject> agentIncomeResults = mongoTemplate.aggregate(agentIncomeAggregation, "transaction", DBObject.class);
        List<DBObject> agentIncomeFieldList = agentIncomeResults.getMappedResults();
        if(agentIncomeFieldList != null && !agentIncomeFieldList.isEmpty()) {
            if(agentIncomeFieldList.size()==1){
                DBObject db = agentIncomeFieldList.get(0);
                agentIncomeTotal = Double.parseDouble(db.get("rebateMoney").toString());
            }
        }

        //获取这个时间段内的组员收益
        String roletype = agentEntity.getRoletype();
        if(StringUtils.isNotBlank(roletype) && ( "2".equals(roletype) || "3".equals(roletype) ) ){
            //获取这个时间段内的组员收益
            /*Query channelIncomeQuery = new Query();
            channelIncomeQuery.addCriteria(Criteria.where("channelcd").is(agentEntity.getChannelcd()));
            channelIncomeQuery.addCriteria(Criteria.where("recharge").gt(0));
            channelIncomeQuery.addCriteria(Criteria.where("ctime").gte(timeStart / 1000).lte(timeEnd / 1000));
            List<TransactionEntity> channelIncomeTransactionEntitys = mongoTemplate.find(channelIncomeQuery, TransactionEntity.class,"channel_income");
            for(TransactionEntity channelIncomeTransactionEntity :channelIncomeTransactionEntitys){
                double buyCpMoney = channelIncomeTransactionEntity.getChannel_income();
                channelIncomeTotal = channelIncomeTotal+buyCpMoney;
            }*/
            AggregationOperation channelIncomeMatch = Aggregation.match(Criteria.where("channelcd").is(agentEntity.getChannelcd()).and("recharge").gt(0).and("ctime").gte(timeStart / 1000).lte(timeEnd / 1000));
            AggregationOperation channelIncomeGroup = Aggregation.group("null").sum("channel_income").as("rebateMoney");
            Aggregation channelIncomeAggregation = Aggregation.newAggregation(channelIncomeMatch,channelIncomeGroup);
            AggregationResults<DBObject> channelIncomeResults = mongoTemplate.aggregate(channelIncomeAggregation, "channel_income", DBObject.class);
            List<DBObject> channelIncomeFieldList = channelIncomeResults.getMappedResults();
            if(channelIncomeFieldList != null && !channelIncomeFieldList.isEmpty()) {
                if(channelIncomeFieldList.size()==1){
                    DBObject db = channelIncomeFieldList.get(0);
                    channelIncomeTotal = Double.parseDouble(db.get("rebateMoney").toString());
                }
            }

            //获取这个时间段内的组长收益
            if("2".equals(roletype)){
                /*Query headmanIncomeQuery = new Query();
                headmanIncomeQuery.addCriteria(Criteria.where("headman_aid").is(aid));
                headmanIncomeQuery.addCriteria(Criteria.where("recharge").gt(0));
                headmanIncomeQuery.addCriteria(Criteria.where("ctime").gte(timeStart / 1000).lte(timeEnd / 1000));
                List<TransactionEntity> headmanIncomeTransactionEntitys = mongoTemplate.find(headmanIncomeQuery, TransactionEntity.class,"headman_income");
                for(TransactionEntity headmanIncomeTransactionEntity :headmanIncomeTransactionEntitys){
                    double buyCpMoney = headmanIncomeTransactionEntity.getHeadman_income();
                    headmanIncomeTotal = headmanIncomeTotal+buyCpMoney;
                }*/

                AggregationOperation headmanIncomeMatch = Aggregation.match(Criteria.where("headman_aid").is(aid).and("recharge").gt(0).and("ctime").gte(timeStart / 1000).lte(timeEnd / 1000));
                AggregationOperation headmanIncomeGroup = Aggregation.group("null").sum("headman_income").as("rebateMoney");
                Aggregation headmanIncomeAggregation = Aggregation.newAggregation(headmanIncomeMatch,headmanIncomeGroup);
                AggregationResults<DBObject> headmanIncomeResults = mongoTemplate.aggregate(headmanIncomeAggregation, "headman_income", DBObject.class);
                List<DBObject> headmanIncomeFieldList = headmanIncomeResults.getMappedResults();
                if(headmanIncomeFieldList != null && !headmanIncomeFieldList.isEmpty()) {
                    if(headmanIncomeFieldList.size()==1){
                        DBObject db = headmanIncomeFieldList.get(0);
                        headmanIncomeTotal = Double.parseDouble(db.get("rebateMoney").toString());
                    }
                }
            }
        }

        //获取这个时间段内的有效代理收益
        if(StringUtils.isNotBlank(roletype) && ( "2".equals(roletype) || "3".equals(roletype) ) ){
            //获取这个时间段内的有效代理收益
            /*Query validagentIncomeQuery = new Query();
            validagentIncomeQuery.addCriteria(Criteria.where("channel_member_aid").is(aid));
            validagentIncomeQuery.addCriteria(Criteria.where("crt_time").gte(timeStart / 1000).lte(timeEnd / 1000));
            List<ValidagentBalanceacctEntity> validagentBalanceacctEntitys = mongoTemplate.find(validagentIncomeQuery, ValidagentBalanceacctEntity.class,"validagent_balanceacct");
            for(ValidagentBalanceacctEntity validagentBalanceacctEntity : validagentBalanceacctEntitys){
                long awardmoney = validagentBalanceacctEntity.getAwardmoney();
                validAgentIncomeTotal = validAgentIncomeTotal + awardmoney;
            }*/

            AggregationOperation validagentIncomeMatch = Aggregation.match(Criteria.where("channel_member_aid").is(aid).and("crt_time").gte(timeStart / 1000).lte(timeEnd / 1000));
            AggregationOperation validagentIncomeGroup = Aggregation.group("null").sum("awardmoney").as("rebateMoney");
            Aggregation validagentIncomeAggregation = Aggregation.newAggregation(validagentIncomeMatch,validagentIncomeGroup);
            AggregationResults<DBObject> validagentIncomeResults = mongoTemplate.aggregate(validagentIncomeAggregation, "validagent_balanceacct", DBObject.class);
            List<DBObject> validagentIncomeFieldList = validagentIncomeResults.getMappedResults();
            if(validagentIncomeFieldList != null && !validagentIncomeFieldList.isEmpty()) {
                if(validagentIncomeFieldList.size()==1){
                    DBObject db = validagentIncomeFieldList.get(0);
                    validAgentIncomeTotal = Long.parseLong(db.get("rebateMoney").toString());
                }
            }
        }

        //获取这个时间段内的有效注册用户收益
        if(StringUtils.isNotBlank(roletype) && ( "2".equals(roletype) || "3".equals(roletype) ) ){

            AggregationOperation validreguserIncomeMatch = Aggregation.match(Criteria.where("channel_member_aid").is(aid).and("crt_time").gte(timeStart / 1000).lte(timeEnd / 1000));
            AggregationOperation validreguserIncomeGroup = Aggregation.group("null").sum("awardmoney").as("rebateMoney");
            Aggregation validreguserIncomeAggregation = Aggregation.newAggregation(validreguserIncomeMatch,validreguserIncomeGroup);
            AggregationResults<DBObject> validreguserIncomeResults = mongoTemplate.aggregate(validreguserIncomeAggregation, "validreguser_balanceacct", DBObject.class);
            List<DBObject> validreguserIncomeFieldList = validreguserIncomeResults.getMappedResults();
            if(validreguserIncomeFieldList != null && !validreguserIncomeFieldList.isEmpty()) {
                if(validreguserIncomeFieldList.size()==1){
                    DBObject db = validreguserIncomeFieldList.get(0);
                    validReguserIncomeTotal = Long.parseLong(db.get("rebateMoney").toString());
                }
            }
        }

        resultMap.put("agentIncomeTotal", (long)agentIncomeTotal);
        resultMap.put("incomeTotal", (long)(channelIncomeTotal+headmanIncomeTotal));
        resultMap.put("memberIncomeTotal", (long)channelIncomeTotal);
        resultMap.put("headmanIncomeTotal", (long)headmanIncomeTotal);
        resultMap.put("validAgentIncomeTotal", validAgentIncomeTotal);
        resultMap.put("validReguserIncomeTotal", validReguserIncomeTotal);

        LOG.info("getAgentAccountInfo, 参数={}, 返回结果={}",
                params, resultMap);
        return resultMap;
    }

    /**
     * 查询代理员上周二到当前时间的账户信息接口
     * @param params
     * @return
     * @throws Exception
     */
    public List<Map<String, Object>> getAgentAccountInfoTwo(Map<String, Object> params) throws Exception {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        List<Map<String, Object>> resultList = new ArrayList<Map<String, Object>>();

        List<String> phoneList = (List<String>)params.get("phoneList");
        LOG.info("getAgentAccountInfoTwo, 参数={}", phoneList);

        Query agentQuery = new Query();
        agentQuery.addCriteria(Criteria.where("phone").in(phoneList));
        List<AgentEntity> agentEntitys = mongoTemplate.find(agentQuery, AgentEntity.class, "agent");
        if(agentEntitys == null || agentEntitys.size() == 0){
            return null;
        }

        Map<String, Object> resultMap = null;
        Map<String, Object> dataMap = null;
        for(AgentEntity agentEntity : agentEntitys){
            double agentIncomeTotal = 0;//代理收益
            double channelIncomeTotal = 0;//组员收益
            double headmanIncomeTotal = 0;//组长收益
            long validAgentIncomeTotal = 0;//有效代理收益
            long validReguserIncomeTotal = 0;//有效注册用户收益
            resultMap = new HashMap<String, Object>();

            String aid = agentEntity.getAid();
            LOG.info("getAgentAccountInfoTwo, phone={}, aid={}", agentEntity.getPhone(), aid);

            Map<String, Object> dateMap = getLastTuesdayToThisMondayDateStr();
            LOG.info("getAgentAccountInfoTwo, getLastTuesdayToThisMondayDateStr={}", dateMap);
            if(dateMap == null && dateMap.size() == 0){
                LOG.error("getAgentAccountInfoTwo, getLastTuesdayToThisMondayDateStr is null");
                continue;
            }

            long timeStart = sdf.parse((String)dateMap.get("beginDate")).getTime();
            long timeEnd = sdf.parse((String)dateMap.get("endDate")).getTime();

            //获取这个时间段内的代理收益
            /*Query agentIncomeQuery = new Query();
            agentIncomeQuery.addCriteria(Criteria.where("aid").is(aid));
            agentIncomeQuery.addCriteria(Criteria.where("recharge").gt(0));
            agentIncomeQuery.addCriteria(Criteria.where("ctime").gte(timeStart / 1000).lte(timeEnd / 1000));
            List<TransactionEntity> agentIncomeTransactionEntitys = mongoTemplate.find(agentIncomeQuery, TransactionEntity.class,"transaction");
            for(TransactionEntity agentIncomeTransactionEntity :agentIncomeTransactionEntitys){
                double buyCpMoney = agentIncomeTransactionEntity.getDay_for_agent();
                agentIncomeTotal = agentIncomeTotal+buyCpMoney;
            }*/

            AggregationOperation agentIncomeMatch = Aggregation.match(Criteria.where("aid").is(aid).and("recharge").gt(0).and("ctime").gte(timeStart / 1000).lte(timeEnd / 1000));
            AggregationOperation agentIncomeGroup = Aggregation.group("null").sum("day_for_agent").as("rebateMoney");
            Aggregation agentIncomeAggregation = Aggregation.newAggregation(agentIncomeMatch,agentIncomeGroup);
            AggregationResults<DBObject> agentIncomeResults = mongoTemplate.aggregate(agentIncomeAggregation, "transaction", DBObject.class);
            List<DBObject> agentIncomeFieldList = agentIncomeResults.getMappedResults();
            if(agentIncomeFieldList != null && !agentIncomeFieldList.isEmpty()) {
                if(agentIncomeFieldList.size()==1){
                    DBObject db = agentIncomeFieldList.get(0);
                    agentIncomeTotal = Double.parseDouble(db.get("rebateMoney").toString());
                }
            }

            //获取这个时间段内的组员收益
            String roletype = agentEntity.getRoletype();
            if(StringUtils.isNotBlank(roletype) && ( "2".equals(roletype) || "3".equals(roletype) ) ){
                //获取这个时间段内的组员收益
                /*Query channelIncomeQuery = new Query();
                channelIncomeQuery.addCriteria(Criteria.where("channelcd").is(agentEntity.getChannelcd()));
                channelIncomeQuery.addCriteria(Criteria.where("recharge").gt(0));
                channelIncomeQuery.addCriteria(Criteria.where("ctime").gte(timeStart / 1000).lte(timeEnd / 1000));
                List<TransactionEntity> channelIncomeTransactionEntitys = mongoTemplate.find(channelIncomeQuery, TransactionEntity.class,"channel_income");
                for(TransactionEntity channelIncomeTransactionEntity :channelIncomeTransactionEntitys){
                    double buyCpMoney = channelIncomeTransactionEntity.getChannel_income();
                    channelIncomeTotal = channelIncomeTotal+buyCpMoney;
                }*/

                AggregationOperation channelIncomeMatch = Aggregation.match(Criteria.where("channelcd").is(agentEntity.getChannelcd()).and("recharge").gt(0).and("ctime").gte(timeStart / 1000).lte(timeEnd / 1000));
                AggregationOperation channelIncomeGroup = Aggregation.group("null").sum("channel_income").as("rebateMoney");
                Aggregation channelIncomeAggregation = Aggregation.newAggregation(channelIncomeMatch,channelIncomeGroup);
                AggregationResults<DBObject> channelIncomeResults = mongoTemplate.aggregate(channelIncomeAggregation, "channel_income", DBObject.class);
                List<DBObject> channelIncomeFieldList = channelIncomeResults.getMappedResults();
                if(channelIncomeFieldList != null && !channelIncomeFieldList.isEmpty()) {
                    if(channelIncomeFieldList.size()==1){
                        DBObject db = channelIncomeFieldList.get(0);
                        channelIncomeTotal = Double.parseDouble(db.get("rebateMoney").toString());
                    }
                }

                //获取这个时间段内的组长收益
                if("2".equals(roletype)){
                    /*Query headmanIncomeQuery = new Query();
                    headmanIncomeQuery.addCriteria(Criteria.where("headman_aid").is(aid));
                    headmanIncomeQuery.addCriteria(Criteria.where("recharge").gt(0));
                    headmanIncomeQuery.addCriteria(Criteria.where("ctime").gte(timeStart / 1000).lte(timeEnd / 1000));
                    List<TransactionEntity> headmanIncomeTransactionEntitys = mongoTemplate.find(headmanIncomeQuery, TransactionEntity.class,"headman_income");for(TransactionEntity headmanIncomeTransactionEntity :headmanIncomeTransactionEntitys){
                        double buyCpMoney = headmanIncomeTransactionEntity.getHeadman_income();
                        headmanIncomeTotal = headmanIncomeTotal+buyCpMoney;
                    }*/

                    AggregationOperation headmanIncomeMatch = Aggregation.match(Criteria.where("headman_aid").is(aid).and("recharge").gt(0).and("ctime").gte(timeStart / 1000).lte(timeEnd / 1000));
                    AggregationOperation headmanIncomeGroup = Aggregation.group("null").sum("headman_income").as("rebateMoney");
                    Aggregation headmanIncomeAggregation = Aggregation.newAggregation(headmanIncomeMatch,headmanIncomeGroup);
                    AggregationResults<DBObject> headmanIncomeResults = mongoTemplate.aggregate(headmanIncomeAggregation, "headman_income", DBObject.class);
                    List<DBObject> headmanIncomeFieldList = headmanIncomeResults.getMappedResults();
                    if(headmanIncomeFieldList != null && !headmanIncomeFieldList.isEmpty()) {
                        if(headmanIncomeFieldList.size()==1){
                            DBObject db = headmanIncomeFieldList.get(0);
                            headmanIncomeTotal = Double.parseDouble(db.get("rebateMoney").toString());
                        }
                    }
                }
            }

            //获取这个时间段内的有效代理收益
            if(StringUtils.isNotBlank(roletype) && ( "2".equals(roletype) || "3".equals(roletype) ) ){
                //获取这个时间段内的有效代理收益
                /*Query validagentIncomeQuery = new Query();
                validagentIncomeQuery.addCriteria(Criteria.where("channel_member_aid").is(aid));
                validagentIncomeQuery.addCriteria(Criteria.where("crt_time").gte(timeStart / 1000).lte(timeEnd / 1000));
                List<ValidagentBalanceacctEntity> validagentBalanceacctEntitys = mongoTemplate.find(validagentIncomeQuery, ValidagentBalanceacctEntity.class,"validagent_balanceacct");
                for(ValidagentBalanceacctEntity validagentBalanceacctEntity : validagentBalanceacctEntitys){
                    long awardmoney = validagentBalanceacctEntity.getAwardmoney();
                    validAgentIncomeTotal = validAgentIncomeTotal + awardmoney;
                }*/

                AggregationOperation validagentIncomeMatch = Aggregation.match(Criteria.where("channel_member_aid").is(aid).and("crt_time").gte(timeStart / 1000).lte(timeEnd / 1000));
                AggregationOperation validagentIncomeGroup = Aggregation.group("null").sum("awardmoney").as("rebateMoney");
                Aggregation validagentIncomeAggregation = Aggregation.newAggregation(validagentIncomeMatch,validagentIncomeGroup);
                AggregationResults<DBObject> validagentIncomeResults = mongoTemplate.aggregate(validagentIncomeAggregation, "validagent_balanceacct", DBObject.class);
                List<DBObject> validagentIncomeFieldList = validagentIncomeResults.getMappedResults();
                if(validagentIncomeFieldList != null && !validagentIncomeFieldList.isEmpty()) {
                    if(validagentIncomeFieldList.size()==1){
                        DBObject db = validagentIncomeFieldList.get(0);
                        validAgentIncomeTotal = Long.parseLong(db.get("rebateMoney").toString());
                    }
                }
            }

            //获取这个时间段内的有效注册用户收益
            if(StringUtils.isNotBlank(roletype) && ( "2".equals(roletype) || "3".equals(roletype) ) ){

                AggregationOperation validreguserIncomeMatch = Aggregation.match(Criteria.where("channel_member_aid").is(aid).and("crt_time").gte(timeStart / 1000).lte(timeEnd / 1000));
                AggregationOperation validreguserIncomeGroup = Aggregation.group("null").sum("awardmoney").as("rebateMoney");
                Aggregation validreguserIncomeAggregation = Aggregation.newAggregation(validreguserIncomeMatch,validreguserIncomeGroup);
                AggregationResults<DBObject> validreguserIncomeResults = mongoTemplate.aggregate(validreguserIncomeAggregation, "validreguser_balanceacct", DBObject.class);
                List<DBObject> validreguserIncomeFieldList = validreguserIncomeResults.getMappedResults();
                if(validreguserIncomeFieldList != null && !validreguserIncomeFieldList.isEmpty()) {
                    if(validreguserIncomeFieldList.size()==1){
                        DBObject db = validreguserIncomeFieldList.get(0);
                        validReguserIncomeTotal = Long.parseLong(db.get("rebateMoney").toString());
                    }
                }
            }

            dataMap = new HashMap<String, Object>();

            dataMap.put("aid", aid);
            dataMap.put("phone", agentEntity.getPhone());
            dataMap.put("agentIncomeTotal", (long)agentIncomeTotal);
            dataMap.put("memberIncomeTotal", (long)channelIncomeTotal);
            dataMap.put("headmanIncomeTotal", (long)headmanIncomeTotal);
            dataMap.put("validAgentIncomeTotal", validAgentIncomeTotal);
            dataMap.put("validReguserIncomeTotal", validReguserIncomeTotal);
            resultMap.put(agentEntity.getPhone(), dataMap);

            resultList.add(resultMap);
        }

        LOG.info("getAgentAccountInfoTwo, 参数={}, resultList={}", params, resultList);
        return resultList;
    }
    
    
    public List<Map<String, Object>> queryAccountReportCurrentList(Map<String, Object> params) throws Exception {
    	
    	List<Map<String, Object>> resultList = apiMapper.queryAccountReportCurrentByPageList(params);
    	
    	LOG.info("queryAccountReportCurrentList, 参数={}, resultList={}", JSONObject.toJSONString(params), JSONObject.toJSONString(resultList));
        return resultList;
    }
    
    public List<Map<String, Object>> queryAccountReportList(Map<String, Object> params) throws Exception {
    	
    	List<Map<String, Object>> resultList = apiMapper.queryAccountReportByPageList(params);
    	
    	LOG.info("queryAccountReportList, 参数={}, resultList={}", JSONObject.toJSONString(params), JSONObject.toJSONString(resultList));
    	return resultList;
    }

    /**
     * 获取上周二到本周一的日期
     * @return
     */
    public Map<String, Object> getLastTuesdayToThisMondayDateStr(){
        Map<String, Object> resultMap = new HashMap<String, Object>();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String beginDate = null;
        String endDate = null;

        Calendar calendar = Calendar.getInstance();
        int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK) - 1;
        System.out.println(dayOfWeek);
        if(dayOfWeek == 1){//周一
            Calendar calendar1 = Calendar.getInstance();
            Calendar calendar2 = Calendar.getInstance();
            calendar1.add(Calendar.DATE, -6);
            calendar2.add(Calendar.DATE, 0);
            beginDate = sdf.format(calendar1.getTime());
            endDate = sdf.format(calendar2.getTime());
        }else if(dayOfWeek == 2){//周二
            Calendar calendar1 = Calendar.getInstance();
            Calendar calendar2 = Calendar.getInstance();
            calendar1.add(Calendar.DATE, -7);
            calendar2.add(Calendar.DATE, -1);
            beginDate = sdf.format(calendar1.getTime());
            endDate = sdf.format(calendar2.getTime());
        }else if(dayOfWeek == 3){//周三
            Calendar calendar1 = Calendar.getInstance();
            Calendar calendar2 = Calendar.getInstance();
            calendar1.add(Calendar.DATE, -8);
            calendar2.add(Calendar.DATE, -2);
            beginDate = sdf.format(calendar1.getTime());
            endDate = sdf.format(calendar2.getTime());
        }else if(dayOfWeek == 4){//周四
            Calendar calendar1 = Calendar.getInstance();
            Calendar calendar2 = Calendar.getInstance();
            calendar1.add(Calendar.DATE, -9);
            calendar2.add(Calendar.DATE, -3);
            beginDate = sdf.format(calendar1.getTime());
            endDate = sdf.format(calendar2.getTime());
        }else if(dayOfWeek == 5){//周五
            Calendar calendar1 = Calendar.getInstance();
            Calendar calendar2 = Calendar.getInstance();
            calendar1.add(Calendar.DATE, -10);
            calendar2.add(Calendar.DATE, -4);
            beginDate = sdf.format(calendar1.getTime());
            endDate = sdf.format(calendar2.getTime());
        }else if(dayOfWeek == 6){//周六
            Calendar calendar1 = Calendar.getInstance();
            Calendar calendar2 = Calendar.getInstance();
            calendar1.add(Calendar.DATE, -11);
            calendar2.add(Calendar.DATE, -5);
            beginDate = sdf.format(calendar1.getTime());
            endDate = sdf.format(calendar2.getTime());
        }else if(dayOfWeek == 0){//周日
            Calendar calendar1 = Calendar.getInstance();
            Calendar calendar2 = Calendar.getInstance();
            calendar1.add(Calendar.DATE, -12);
            calendar2.add(Calendar.DATE, -6);
            beginDate = sdf.format(calendar1.getTime());
            endDate = sdf.format(calendar2.getTime());
        }

        if(beginDate != null && endDate != null){
            beginDate = beginDate+" 00:00:00";
            endDate = endDate+" 23:59:59";

            resultMap.put("beginDate", beginDate);
            resultMap.put("endDate", endDate);
        }

        return resultMap;
    }

    
    public Map<String, Object> queryAccountReportTotail(Map<String, Object> params){
    	
    	Map<String, Object> resultMap = apiMapper.queryAccountReportTotail(params);
    	
    	LOG.info("queryAccountReportTotail, 参数={}, resultMap={}", JSONObject.toJSONString(params), JSONObject.toJSONString(resultMap));
    	return resultMap;
    	
    }
    
    public List<Map<String, Object>> queryLotteryRegisteredUsersCount(Map<String, Object> params){
    	
    	List<Map<String, Object>> resultList = apiMapper.queryLotteryRegisteredUsersCount(params);
    	
    	LOG.info("queryLotteryRegisteredUsersCount, 参数={}, resultMap={}", JSONObject.toJSONString(params), JSONObject.toJSONString(resultList));
    	return resultList;
    	
    }
    
    public List<Map<String, Object>> queryLotteryRegisteredUsersList(Map<String, Object> params){
    	
    	List<Map<String, Object>> resultList = apiMapper.queryLotteryRegisteredUsersList(params);
    	
    	LOG.info("queryLotteryRegisteredUsersList, 参数={}, resultMap={}", JSONObject.toJSONString(params), JSONObject.toJSONString(resultList));
    	return resultList;
    	
    }
    
    public List<Map<String, Object>> queryValidRegisteredUsersCount(Map<String, Object> params){
    	
    	List<Map<String, Object>> resultList = apiMapper.queryValidRegisteredUsersCount(params);
    	
    	LOG.info("queryValidRegisteredUsersCount, 参数={}, resultMap={}", JSONObject.toJSONString(params), JSONObject.toJSONString(resultList));
    	return resultList;
    	
    }
    
    public List<Map<String, Object>> queryValidRegisteredUsers(Map<String, Object> params){
    	
    	List<Map<String, Object>> resultList = apiMapper.queryValidRegisteredUsers(params);
    	
    	LOG.info("queryValidRegisteredUsers, 参数={}, resultMap={}", JSONObject.toJSONString(params), JSONObject.toJSONString(resultList));
    	return resultList;
    	
    }
    
    
}
