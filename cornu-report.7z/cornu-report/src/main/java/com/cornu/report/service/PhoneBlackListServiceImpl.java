
package com.cornu.report.service;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.cornu.report.utils.PhoneBlackUtil;

/**
 * //TODO
 *
 * @author zhouxw
 * @version nyservice 下午5:25:47
 * @since 1.0
 **/
@Service("phoneBlackListService")
public class PhoneBlackListServiceImpl{

    private static final Logger LOG = LoggerFactory.getLogger(PhoneBlackListServiceImpl.class.getName());
    
    /*@Autowired
    @Qualifier("com.yxqm.service.impl.app.DataCodeService")
    private DataCodeService dataCodeService;*/


    static String prefix = "手机号黑名单检查";

    public boolean validPhone(String phone) {

        if (!PhoneBlackUtil.phone(phone)) {
            LOG.info(prefix + ",验证的手机号是：{} ,不符合手机号样式", phone);
            return false; //正常号码
        }
        try {
            Map<String, String> map = new HashMap<String, String>();
            map.put("phone", phone);
            LOG.info(prefix + ",验证的手机号是：{} ,开始检查", phone);
            //查询第三方是否是黑名单
           /* String appkey = dataCodeService.getCodeValue("REG_LIMITER_CONFIG", "CHECK_MOBILE_BLACKLIST_APPKEY");
            String secertkey = dataCodeService.getCodeValue("REG_LIMITER_CONFIG", "CHECK_MOBILE_BLACKLIST_SECERTKEY");
            String url = dataCodeService.getCodeValue("REG_LIMITER_CONFIG", "CHECK_MOBILE_BLACKLIST_URL");
            String level = dataCodeService.getCodeValue("REG_LIMITER_CONFIG", "CHECK_MOBILE_BLACKLIST_LEVEL");
            LOG.info(prefix + ",短信黑名单配置appkey:{} ,secertkey:{} ,level:{},url:{} ,验证的手机号是：{}", appkey, secertkey, level, url, phone);
            , String agent , String ip
            , appkey, secertkey, url, level, returnData
            */
            /*Map<String, String> returnData = new HashMap<>();
            returnData.put("agent", agent);
            returnData.put("ip", ip);*/
            boolean valid = PhoneBlackUtil.validPhone(phone);
            if (valid) { //黑名单
                LOG.info(prefix + ",验证的手机号是：{}，属于黑名单手机号。", phone);
                return true;
            }

        } catch (Exception e) {

            LOG.info("查询黑名单数据出错,{}", e);
            return false;  //正常号码
            
        }

        LOG.info(prefix + ",验证的手机号是：{} ，属于正常手机号。检查完成", phone);
        return false;  //正常号码
    }

}
