package com.cornu.report.service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationOperation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.cornu.report.dao.bean.AgentEntity;
import com.cornu.report.dao.bean.ChannelEntity;
import com.cornu.report.dao.bean.RebateEntity;
import com.cornu.report.dao.bean.SendSmsmsgEntity;
import com.cornu.report.dao.bean.TransactionEntity;
import com.cornu.report.dao.mapper.ApiMapper;
import com.cornu.report.dao.mapper.StatMapper;
import com.mongodb.DBObject;

@Service("basicDataService")
public class BasicDataService {
	private static final Logger LOG = LoggerFactory.getLogger(BasicDataService.class);
	@Autowired
	MongoTemplate mongoTemplate;

	@Autowired(required = true)
	@Qualifier(value = "statMapper")
	StatMapper statMapper;
	
	@Autowired(required = true)
	@Qualifier(value = "apiMapper")
	ApiMapper apiMapper;
	
	//推广员提供比例，默认千分之二
	private static final double COMMISSION_VALUE = Double.parseDouble(System.getProperty("promoters.commission.value", "0.002"));

	//组长提供比例，默认千分之一
	private static final double HEADMAN_COMMISSION_VALUE = Double.parseDouble(System.getProperty("headman.commission.value", "0.001"));

	/**
	 * 统计每天基础数据 包括：新注册代理人数、新注册彩票人数、新注册且购彩人数、新注册且购彩金额、购彩人数、购彩金额
	 * 
	 * @throws Exception
	 */
	public void statBasicData(Date date) throws Exception {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

		String bDate = String.format("%tF", date);
		

		long timeStart = sdf.parse(String.format("%tF 00:00:00", date)).getTime();
		long timeEnd = sdf.parse(String.format("%tF 23:59:59", date)).getTime();

		//所有渠道
		List<ChannelEntity> channelEntitys = mongoTemplate.findAll(ChannelEntity.class,
				"channel_info");
		for (ChannelEntity channelEntity : channelEntitys) {
			String channelCd = channelEntity.getChannelcd();
			String channelName = channelEntity.getChannelname();
			String parentChannelCode = null;
			Query parentChannelQuery = new Query();
			parentChannelQuery.addCriteria(Criteria.where("channelcd").is(channelCd));
			parentChannelQuery.addCriteria(Criteria.where("roletype").in("2","3"));
			AgentEntity parentAgentEntity = mongoTemplate.findOne(parentChannelQuery,AgentEntity.class, "agent");
			if(parentAgentEntity != null){
				parentChannelCode = parentAgentEntity.getP_channelcd();
			}
			//通过渠道查询代理人员
			Query agentQuery = new Query();
			agentQuery.addCriteria(Criteria.where("channelcd").is(channelCd));
			List<AgentEntity> agentEntitys = mongoTemplate.find(agentQuery, AgentEntity.class, "agent");
			Object[] agents = new Object[agentEntitys.size()];
			int i=0;
			for(AgentEntity agentEntity : agentEntitys){
				String agentId = agentEntity.getAid();
				agents[i] = agentId;
				i++;
			}
			
			if(agents.length == 0){
				continue;
			}
			
			// 查询代理的app
			Query agentAppQuery = new Query();
			agentAppQuery.addCriteria(Criteria.where("aid").in(agents));
			List<RebateEntity> rebateEntitys = mongoTemplate.find(agentAppQuery, RebateEntity.class, "rebate");
			
			
			Map<String,String> apps = new HashMap<String,String>();
			for (RebateEntity rebateEntity : rebateEntitys) {
				String appid = rebateEntity.getAppid();
				String appName = rebateEntity.getAppname();
				apps.put(appid, appName);
			}
			
			Map<String, Object> stat = null;
			
			for (Map.Entry<String,String> entry : apps.entrySet()) {
				stat = new HashMap<String, Object>();
				stat.put("b_date", bDate);
				stat.put("b_channel_cd",channelCd);
				stat.put("b_channel_name", channelName);
				
				String appid = entry.getKey();
				stat.put("b_appno",appid);
				
				// 新注册彩票人数:由聚宝盆代理引导注册彩票的用户数
				Query appRegQuery = new Query();
				appRegQuery.addCriteria(Criteria.where("aid").in(agents));
				appRegQuery.addCriteria(Criteria.where("appid").is(appid));
				appRegQuery.addCriteria(Criteria.where("recharge").is(0));
				appRegQuery.addCriteria(Criteria.where("ctime").gte(timeStart / 1000).lte(timeEnd / 1000));
				List<TransactionEntity> appRegtransactionEntitys = mongoTemplate.find(appRegQuery, TransactionEntity.class, "transaction");
				Map<String,String> appNRegNum = new HashMap<String,String>();
				for(TransactionEntity transactionEntity : appRegtransactionEntitys){
					String uid = transactionEntity.getUid();
					String uName = transactionEntity.getUname();
					appNRegNum.put(uid, uName);
				}
				stat.put("b_newcpnum", appNRegNum.size());
				// 新注册且购彩人数:“新注册彩票人数”中有消费记录的用户数
				Query appBuyQuery = new Query();
				appBuyQuery.addCriteria(Criteria.where("aid").in(agents));
				appBuyQuery.addCriteria(Criteria.where("appid").is(appid));
				appBuyQuery.addCriteria(Criteria.where("recharge").gt(0));
				appBuyQuery.addCriteria(Criteria.where("ctime").gte(timeStart / 1000).lte(timeEnd / 1000));
				List<TransactionEntity> appBuytransactionEntitys = mongoTemplate.find(appBuyQuery, TransactionEntity.class,"transaction");

				Map<String,String> appRegBuyNum = new HashMap<String,String>();
				Map<String,String> appBuyCpUserNum = new HashMap<String,String>();
				long regBuyMoneyTotal = 0;
				long buyMoneyTotal = 0;
				for(TransactionEntity appBuyTransactionEntity :appBuytransactionEntitys){
					String appBuyUid = appBuyTransactionEntity.getUid();
					String appBuyUname = appBuyTransactionEntity.getUname();
					long buyCpMoney = appBuyTransactionEntity.getRecharge();
					appBuyCpUserNum.put(appBuyUid, appBuyUname);
					buyMoneyTotal = buyMoneyTotal+buyCpMoney;
					for(TransactionEntity appRegTransactionEntity :appRegtransactionEntitys){
						String appRegUid = appRegTransactionEntity.getUid();
						
						if(appRegUid.equals(appBuyUid)){
							long buyMoney = appBuyTransactionEntity.getRecharge();
							regBuyMoneyTotal=regBuyMoneyTotal+buyMoney;
							appRegBuyNum.put(appBuyUid, appBuyUname);
						}
					}
				}
				stat.put("b_newcpbuynum", appRegBuyNum.size());
				// 新注册且购彩金额:“新注册彩票人数”中有消费记录的总金额
				stat.put("b_newcpbuymoney", regBuyMoneyTotal);
				// 购彩人数:聚宝盆渠道当日总购彩用户数
				stat.put("b_buycpusernum",appBuyCpUserNum.size());
				// 购彩金额:聚宝盆渠道当日总购彩用户数产生的销量总额
				stat.put("b_buycpmoney", buyMoneyTotal);
				
				//提成值
				stat.put("b_promoters_income", buyMoneyTotal * COMMISSION_VALUE);//buyMoneyTotal单位分，提成金额也是分，会存在小数点的情况。
				//组长的渠道
				stat.put("b_p_channel_cd", parentChannelCode == null ? "" : parentChannelCode);
				// 添加数据
				try {
					statMapper.addBasicData(stat);
				} catch (DuplicateKeyException e) {
					LOG.info("更新基本数据:{}", bDate);
					statMapper.updateBasicData(stat);
				}
			}
			
			if(null!=parentChannelCode){
				Map<String, Object> headmanMap = new HashMap<String, Object>();
				headmanMap.put("headmanCommissionValue", HEADMAN_COMMISSION_VALUE);
				headmanMap.put("b_p_channel_cd", parentChannelCode);
//				statMapper.updateHeadmanCommissionMoney(headmanMap);
				headmanMap.put("b_date", bDate);
				statMapper.updateHeadmanCommissionMoneyByDate(headmanMap);
			}
		}
		LOG.info("统计基础记录完成....");
	}

	public void stat9999Basic(Date date) throws Exception {
		// 自然代理
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

		String bDate = String.format("%tF", date);

		long timeStart = sdf.parse(String.format("%tF 00:00:00", date)).getTime();
		long timeEnd = sdf.parse(String.format("%tF 23:59:59", date)).getTime();

		Query agentQuery = new Query();
		Criteria criteria = new Criteria()
        .orOperator(
            Criteria.where("channelcd").exists(false),
            Criteria.where("channelcd").is("null")
        );
		agentQuery.addCriteria(criteria);
		List<AgentEntity> agentEntitys = mongoTemplate.find(agentQuery, AgentEntity.class, "agent");
		Object[] agents = new Object[agentEntitys.size()];
		int i=0;
		for(AgentEntity agentEntity : agentEntitys){
			String agentId = agentEntity.getAid();
			agents[i] = agentId;
			i++;
		}
		
		if(agents.length == 0){
			return;
		}
		
		//查询所有自然人所代理的应用
		Query agentAppQuery = new Query();
		agentAppQuery.addCriteria(Criteria.where("aid").in(agents));
		List<RebateEntity> rebateEntitys = mongoTemplate.find(agentAppQuery, RebateEntity.class, "rebate");
		
		Map<String,String> apps = new HashMap<String,String>();
		for(RebateEntity rebateEntity : rebateEntitys){
			String appid = rebateEntity.getAppid();
			String appName = rebateEntity.getAppname();
			apps.put(appid,appName);
		}
		
		Map<String, Object> stat = null;
		for (Map.Entry<String,String> entry : apps.entrySet()) {
			stat = new HashMap<String, Object>();
			stat.put("b_date", bDate);
			stat.put("b_channel_cd","9999");
			stat.put("b_channel_name", "自然代理");
			
			String appid = entry.getKey();
			stat.put("b_appno",appid);
			
			// 新注册彩票人数:由聚宝盆代理引导注册彩票的用户数
			Query appRegQuery = new Query();
			appRegQuery.addCriteria(Criteria.where("aid").in(agents));
			appRegQuery.addCriteria(Criteria.where("appid").is(appid));
			appRegQuery.addCriteria(Criteria.where("recharge").is(0));
			appRegQuery.addCriteria(Criteria.where("ctime").gte(timeStart / 1000).lte(timeEnd / 1000));
			List<TransactionEntity> appRegtransactionEntitys = mongoTemplate.find(appRegQuery, TransactionEntity.class, "transaction");
			Map<String,String> appNRegNum = new HashMap<String,String>();
			for(TransactionEntity transactionEntity : appRegtransactionEntitys){
				String uid = transactionEntity.getUid();
				String uName = transactionEntity.getUname();
				appNRegNum.put(uid, uName);
			}
			stat.put("b_newcpnum", appNRegNum.size());
			
			
			// 新注册且购彩人数:“新注册彩票人数”中有消费记录的用户数
			Query appBuyQuery = new Query();
			appBuyQuery.addCriteria(Criteria.where("aid").in(agents));
			appBuyQuery.addCriteria(Criteria.where("appid").is(appid));
			appBuyQuery.addCriteria(Criteria.where("recharge").gt(0));
			appBuyQuery.addCriteria(Criteria.where("ctime").gte(timeStart / 1000).lte(timeEnd / 1000));
			List<TransactionEntity> appBuytransactionEntitys = mongoTemplate.find(appBuyQuery, TransactionEntity.class,"transaction");

			Map<String,String> appRegBuyNum = new HashMap<String,String>();
			Map<String,String> appBuyCpUserNum = new HashMap<String,String>();
			long regBuyMoneyTotal = 0;
			long buyMoneyTotal = 0;
			for(TransactionEntity appBuyTransactionEntity :appBuytransactionEntitys){
				String appBuyUid = appBuyTransactionEntity.getUid();
				String appBuyUname = appBuyTransactionEntity.getUname();
				long buyCpMoney = appBuyTransactionEntity.getRecharge();
				appBuyCpUserNum.put(appBuyUid, appBuyUname);
				buyMoneyTotal = buyMoneyTotal+buyCpMoney;
				for(TransactionEntity appRegTransactionEntity :appRegtransactionEntitys){
					String appRegUid = appRegTransactionEntity.getUid();
					
					if(appRegUid.equals(appBuyUid)){
						long buyMoney = appBuyTransactionEntity.getRecharge();
						regBuyMoneyTotal=regBuyMoneyTotal+buyMoney;
						appRegBuyNum.put(appBuyUid, appBuyUname);
					}
				}
			}
			stat.put("b_newcpbuynum", appRegBuyNum.size());
			// 新注册且购彩金额:“新注册彩票人数”中有消费记录的总金额
			stat.put("b_newcpbuymoney", regBuyMoneyTotal);
			// 购彩人数:聚宝盆渠道当日总购彩用户数
			stat.put("b_buycpusernum",appBuyCpUserNum.size());
			// 购彩金额:聚宝盆渠道当日总购彩用户数产生的销量总额
			stat.put("b_buycpmoney", buyMoneyTotal);
			//提成值
			stat.put("b_promoters_income", 0);
			//组长的渠道
			stat.put("b_p_channel_cd", "");
			// 添加数据
			try {
				statMapper.addBasicData(stat);
			} catch (DuplicateKeyException e) {
				LOG.info("更新基本数据:{}", bDate);
				statMapper.updateBasicData(stat);
			}
		}
		LOG.info("统计自然代理记录完成....");
	}

	public void statMixBasic(Date date) throws Exception {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

		String bDate = String.format("%tF", date);

		long timeStart = sdf.parse(String.format("%tF 00:00:00", date)).getTime();
		long timeEnd = sdf.parse(String.format("%tF 23:59:59", date)).getTime();

		//所有渠道
		List<ChannelEntity> channelEntitys = mongoTemplate.findAll(ChannelEntity.class,
						"channel_info");
		for(ChannelEntity channelEntity : channelEntitys){
			Map<String, Object> stat = new HashMap<String, Object>();
			stat.put("m_date", bDate);
			String channelCd = channelEntity.getChannelcd();
			String channelName = channelEntity.getChannelname();
			stat.put("m_channel_cd", channelCd);
			stat.put("m_channel_name", channelName);
			
			// 新注册代理人数:聚宝盆平台注册得用户数
			Query query = new Query();
			query.addCriteria(Criteria.where("ctime").gte(timeStart / 1000).lte(timeEnd / 1000));
			query.addCriteria(Criteria.where("channelcd").is(channelCd));
			
			List<AgentEntity> agentEntitys = mongoTemplate.find(query, AgentEntity.class, "agent");
			Map<String,String> nARegNum = new HashMap<String,String>();
			for(AgentEntity agentEntity:agentEntitys){
				String aid = agentEntity.getAid();
				String acode = agentEntity.getAcode();
				nARegNum.put(aid, acode);
			}
			stat.put("m_anewregnum", nARegNum.size());
			LOG.debug("nARegNum:{}", nARegNum.size());
			
			//有效代理人数: 比如：6月1日新注册人数5 有效代理人10
			Query validAgentQuery = new Query();
			validAgentQuery.addCriteria(Criteria.where("validTime").gte(timeStart / 1000).lte(timeEnd / 1000));
			validAgentQuery.addCriteria(Criteria.where("channelcd").is(channelCd));
			validAgentQuery.addCriteria(Criteria.where("isValid").is("1"));
			
			List<AgentEntity> validAgentEntitys = mongoTemplate.find(validAgentQuery, AgentEntity.class, "agent");
			
			stat.put("m_validagentnum", validAgentEntitys.size());
			
			
			//有效注册用户数
			Query validRegUserQuery = new Query();
			validRegUserQuery.addCriteria(Criteria.where("validTime").gte(timeStart / 1000).lte(timeEnd / 1000));
			validRegUserQuery.addCriteria(Criteria.where("channelcd").is(channelCd));
			validRegUserQuery.addCriteria(Criteria.where("isValid").is("1"));
			
			List<TransactionEntity> validRegUserEntitys = mongoTemplate.find(validRegUserQuery, TransactionEntity.class, "transaction");
			
			stat.put("m_validregnum", validRegUserEntitys.size());
			
			// 添加数据
			try {
				statMapper.addMixBasicData(stat);
			} catch (DuplicateKeyException e) {
				LOG.info("更新基本数据:{}", bDate);
				statMapper.updateMixBasicData(stat);
			}
		}
		LOG.info("统计混合基础记录完成....");
	}
	
	public void statDetailBasic(Date date) throws Exception {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

		String bDate = String.format("%tF", date);

		long timeStart = sdf.parse(String.format("%tF 00:00:00", date)).getTime();
		long timeEnd = sdf.parse(String.format("%tF 23:59:59", date)).getTime();
		
		//查询所有代理人
		List<AgentEntity> agentEntitys = mongoTemplate.findAll( AgentEntity.class, "agent");
		
		for(AgentEntity agentEntity:agentEntitys){
			String channelCd = agentEntity.getChannelcd();
			
			String aid = agentEntity.getAid();
			
			//查询代理人代理的app
			Query agentAppQuery = new Query();
			agentAppQuery.addCriteria(Criteria.where("aid").is(aid));
			List<RebateEntity> rebateEntitys = mongoTemplate.find(agentAppQuery, RebateEntity.class, "rebate");
			
			Map<String,String> apps = new HashMap<String,String>();
			for(RebateEntity rebateEntity : rebateEntitys){
				String appid = rebateEntity.getAppid();
				String appName = rebateEntity.getAppname();
				apps.put(appid,appName);
			}
			
			for(Map.Entry<String,String> entry : apps.entrySet()){
				Map<String, Object> stat = new HashMap<String, Object>();
				stat.put("d_date", bDate);
				//1自然代理，2渠道代理
				if(StringUtils.isBlank(channelCd)){
					stat.put("d_channle_type", 1);//自然代理
				}else{
					stat.put("d_channle_type", 2);//渠道代理
				}
				stat.put("d_aid", aid);
				
				String appid = entry.getKey();
				stat.put("d_appno", appid);
				
				//查询应用所有的新注册人数
				Query appRegQuery = new Query();
				appRegQuery.addCriteria(Criteria.where("aid").is(aid));
				appRegQuery.addCriteria(Criteria.where("appid").is(appid));
				appRegQuery.addCriteria(Criteria.where("recharge").is(0));
				appRegQuery.addCriteria(Criteria.where("ctime").gte(timeStart / 1000).lte(timeEnd / 1000));
				List<TransactionEntity> appRegtransactionEntitys = mongoTemplate.find(appRegQuery, TransactionEntity.class, "transaction");
				Map<String,String> appNRegNum = new HashMap<String,String>();
				for(TransactionEntity transactionEntity : appRegtransactionEntitys){
					String uid = transactionEntity.getUid();
					String uName = transactionEntity.getUname();
					appNRegNum.put(uid, uName);
				}
				stat.put("d_newcpnum", appNRegNum.size());
				
				// 新注册且购彩人数:“新注册彩票人数”中有消费记录的用户数
				Query appBuyQuery = new Query();
				appBuyQuery.addCriteria(Criteria.where("aid").is(aid));
				appBuyQuery.addCriteria(Criteria.where("appid").is(appid));
				appBuyQuery.addCriteria(Criteria.where("recharge").gt(0));
				appBuyQuery.addCriteria(Criteria.where("ctime").gte(timeStart / 1000).lte(timeEnd / 1000));
				List<TransactionEntity> appBuytransactionEntitys = mongoTemplate.find(appBuyQuery, TransactionEntity.class,"transaction");

				Map<String,String> appRegBuyNum = new HashMap<String,String>();
				Map<String,String> appBuyCpUserNum = new HashMap<String,String>();
				long regBuyMoneyTotal = 0;
				long buyMoneyTotal = 0;
				for(TransactionEntity appBuyTransactionEntity :appBuytransactionEntitys){
					String appBuyUid = appBuyTransactionEntity.getUid();
					String appBuyUname = appBuyTransactionEntity.getUname();
					long buyCpMoney = appBuyTransactionEntity.getRecharge();
					appBuyCpUserNum.put(appBuyUid, appBuyUname);
					buyMoneyTotal = buyMoneyTotal+buyCpMoney;
					for(TransactionEntity appRegTransactionEntity :appRegtransactionEntitys){
						String appRegUid = appRegTransactionEntity.getUid();
						
						if(appRegUid.equals(appBuyUid)){
							long buyMoney = appBuyTransactionEntity.getRecharge();
							regBuyMoneyTotal=regBuyMoneyTotal+buyMoney;
							appRegBuyNum.put(appBuyUid, appBuyUname);
						}
					}
				}
				stat.put("d_newcpbuynum", appRegBuyNum.size());
				// 新注册且购彩金额:“新注册彩票人数”中有消费记录的总金额
				stat.put("d_newcpbuymoney", regBuyMoneyTotal);
				// 购彩人数:聚宝盆渠道当日总购彩用户数
				stat.put("d_buycpusernum",appBuyCpUserNum.size());
				// 购彩金额:聚宝盆渠道当日总购彩用户数产生的销量总额
				stat.put("d_buycpmoney", buyMoneyTotal);
				//查询代理人当日获得提成金额
				AggregationOperation match = Aggregation.match(Criteria.where("aid").is(aid).and("appid").is(appid).and("ctime").gte(timeStart / 1000).lte(timeEnd / 1000));
			    AggregationOperation group = Aggregation.group("null").sum("day_for_agent").as("rabateMoney");
			    Aggregation aggregation = Aggregation.newAggregation(match,group);
				AggregationResults<DBObject> results = mongoTemplate.aggregate(aggregation, "transaction", DBObject.class);
				List<DBObject> fieldList = results.getMappedResults();
				long d_buyrebatemoney = 0;
				if(fieldList != null && !fieldList.isEmpty()) {
		            if(fieldList.size()==1){
		            	DBObject db = fieldList.get(0);
		            	d_buyrebatemoney = (long)Double.parseDouble(db.get("rabateMoney").toString());
		            }
		        }
				stat.put("d_buyrebatemoney", d_buyrebatemoney);
				// 添加数据
				try {
					statMapper.addDetailBasicData(stat);
				} catch (DuplicateKeyException e) {
					LOG.info("更新详细基本数据:{}", bDate);
					statMapper.updateDetailBasicData(stat);
				}
			}
			
		}
		LOG.info("统计混合基础记录完成....");
	}
	
	/**
	 * 根据手机号，查询最新验证码
	 * 
	 * @param phone
	 * @return
	 * @throws Exception
	 */
	public String queryCodeByPhone(String phone) throws Exception {
		
		String smsCode = "";
		
		Query query = new Query();
		query.addCriteria(Criteria.where("phone").is(phone));
		query.with(new Sort(new Sort.Order(Sort.Direction.DESC, "ctime")));
		List<SendSmsmsgEntity> smsCodeList = mongoTemplate.find(query, SendSmsmsgEntity.class,"send_smsmsg");
		
		if(smsCodeList != null && smsCodeList.size() > 0){
			
			smsCode = smsCodeList.get(0).getSms_code();
			
		}
		
		return smsCode;
		
	}
	
	public void statAccountReportBasic(Map<String, Object> paramMap) throws Exception {
		try {
			
			List<Map<String, Object>> accountList = apiMapper.queryAccountReportList(paramMap);
			
			for (Map<String, Object> map : accountList) {
				try {
					map.put("AR_START_DATE", paramMap.get("startDate"));
					map.put("AR_END_DATE", paramMap.get("endDate"));
					statMapper.saveAccountReport(map);
				} catch (Exception e) {
					LOG.info("更新财务对账数据:{}", JSONObject.toJSONString(map));
					statMapper.updateAccountReport(map);
				}
			}
			
		} catch (DuplicateKeyException e) {
			LOG.info("添加财务对账数据查询异常:{},{}", paramMap.get("startDate"), paramMap.get("endDate"));
		}
		LOG.info("添加财务对账数据完成....");
	}
	
}
