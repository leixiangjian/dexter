package com.cornu.report.dao.bean;

/**
 * Created by Dell on 2017/7/11.
 */
public class ValidagentBalanceacctEntity {
    private String phone;
    private String mod_time_str;
    private String crt_time_str;
    private String channel_member_aid;
    private long mod_time;
    private String appid;
    private String channelcd;
    private String aid;
    private long awardmoney;
    private String channel_member_phone;
    private long validtime;
    private long crt_time;

    public String getAid() {
        return aid;
    }

    public void setAid(String aid) {
        this.aid = aid;
    }

    public String getAppid() {
        return appid;
    }

    public void setAppid(String appid) {
        this.appid = appid;
    }

    public long getAwardmoney() {
        return awardmoney;
    }

    public void setAwardmoney(long awardmoney) {
        this.awardmoney = awardmoney;
    }

    public String getChannel_member_aid() {
        return channel_member_aid;
    }

    public void setChannel_member_aid(String channel_member_aid) {
        this.channel_member_aid = channel_member_aid;
    }

    public String getChannel_member_phone() {
        return channel_member_phone;
    }

    public void setChannel_member_phone(String channel_member_phone) {
        this.channel_member_phone = channel_member_phone;
    }

    public String getChannelcd() {
        return channelcd;
    }

    public void setChannelcd(String channelcd) {
        this.channelcd = channelcd;
    }

    public long getCrt_time() {
        return crt_time;
    }

    public void setCrt_time(long crt_time) {
        this.crt_time = crt_time;
    }

    public String getCrt_time_str() {
        return crt_time_str;
    }

    public void setCrt_time_str(String crt_time_str) {
        this.crt_time_str = crt_time_str;
    }

    public long getMod_time() {
        return mod_time;
    }

    public void setMod_time(long mod_time) {
        this.mod_time = mod_time;
    }

    public String getMod_time_str() {
        return mod_time_str;
    }

    public void setMod_time_str(String mod_time_str) {
        this.mod_time_str = mod_time_str;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public long getValidtime() {
        return validtime;
    }

    public void setValidtime(long validtime) {
        this.validtime = validtime;
    }
}
