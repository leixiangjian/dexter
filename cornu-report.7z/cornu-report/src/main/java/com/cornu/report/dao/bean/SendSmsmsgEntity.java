package com.cornu.report.dao.bean;

/**
 * @author 作者：yca
 * @date 2017年7月18日上午10:34:35
 */

public class SendSmsmsgEntity {
	
	private String sms_code;
	private String phone;
	private String ctime;
	
	public String getSms_code() {
		return sms_code;
	}
	public void setSms_code(String sms_code) {
		this.sms_code = sms_code;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getCtime() {
		return ctime;
	}
	public void setCtime(String ctime) {
		this.ctime = ctime;
	}
}
