package com.cornu.report.service;

import com.cornu.report.dao.bean.AgentEntity;
import com.cornu.report.dao.bean.ChannelEntity;
import com.cornu.report.dao.bean.ChannelIncomeEntity;
import com.cornu.report.dao.bean.TransactionEntity;
import com.cornu.report.dao.mapper.ApiMapper;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.springframework.data.mongodb.core.query.Criteria.where;

/**
 * Created by Dell on 2017/7/3.
 */
@Service("refreshPromotersIncomeService")
public class RefreshPromotersIncomeService {
    private static final Logger LOG = LoggerFactory.getLogger(RefreshPromotersIncomeService.class);

    @Autowired
    MongoTemplate mongoTemplate;

    @Autowired(required = true)
    @Qualifier(value = "apiMapper")
    ApiMapper apiMapper;

    public void refreshPromotersIncomeData(Map<String, Object> params) throws Exception{
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date currentTime = new Date();
        String currentDate = String.format("%tF", currentTime);

        long timeStart = sdf.parse(String.format("%s 00:00:00", currentDate)).getTime();
        long timeEnd = sdf.parse(String.format("%s 23:59:59", currentDate)).getTime();

        //查询渠道收益数据
        List<Map<String, Object>> channelIncomeList = apiMapper.queryChannelIncomeList(params);
        if(channelIncomeList != null && channelIncomeList.size() > 0){
            for(Map<String, Object> map : channelIncomeList){
                String channelcd = (String)map.get("B_CHANNEL_CD");
                Double channelIncome = Double.parseDouble(map.get("B_PROMOTERS_INCOME").toString());
                Double currentDateChannelIncome = 0d;
                //查询今日的渠道收益
                Query channelIncomeQuery = new Query();
                channelIncomeQuery.addCriteria(where("channelcd").is(channelcd));
                channelIncomeQuery.addCriteria(Criteria.where("ctime").gte(timeStart / 1000).lte(timeEnd / 1000));
                List<ChannelIncomeEntity> channelIncomeEntitys = mongoTemplate.find(channelIncomeQuery, ChannelIncomeEntity.class, "channel_income");
                for(ChannelIncomeEntity channelIncomeEntity : channelIncomeEntitys){
                    if(channelIncomeEntity.getChannel_income() > 0){
                        currentDateChannelIncome = currentDateChannelIncome + channelIncomeEntity.getChannel_income();
                    }
                }

                //查询渠道推广员
                Query query = new Query();
                query.addCriteria(where("channelcd").is(channelcd));

                Query channelAgentQuery = new Query();
                channelAgentQuery.addCriteria(Criteria.where("channelcd").is(channelcd));
                channelAgentQuery.addCriteria(Criteria.where("roletype").in("2","3"));
                AgentEntity channelAgentEntity = mongoTemplate.findOne(channelAgentQuery, AgentEntity.class, "agent");
                if(channelAgentEntity == null){
                    continue;
                }
                Map<String, Object> insertParams = new HashMap<String, Object>();
                insertParams.put("RPI_DATE", params.get("bDateLong").toString() +"-"+ params.get("eDateLong").toString() );
                insertParams.put("RPI_CHANNEL_CD", channelcd);
                insertParams.put("RPI_PROMOTERS_INCOME", channelIncome);
                insertParams.put("RPI_AID", channelAgentEntity.getAid());
                insertParams.put("RPI_PHONE", channelAgentEntity.getPhone());
                Double rpi_tincome = Double.parseDouble(StringUtils.isBlank(channelAgentEntity.getTincome()) ?"0":channelAgentEntity.getTincome()) - Double.parseDouble(StringUtils.isBlank(channelAgentEntity.getChannel_total_income()) ? "0": channelAgentEntity.getChannel_total_income());
                insertParams.put("RPI_TINCOME", rpi_tincome);
                insertParams.put("RPI_TODAY_CHANNEL_TOTAL_INCOME", currentDateChannelIncome);

                Double rpi_final_channel_total_income = channelIncome + currentDateChannelIncome;
                insertParams.put("RPI_FINAL_CHANNEL_TOTAL_INCOME", rpi_final_channel_total_income);

                Double rpi_final_tincome = rpi_tincome + rpi_final_channel_total_income + currentDateChannelIncome;
                insertParams.put("RPI_FINAL_TINCOME", rpi_final_tincome);

                try {
                    apiMapper.addRefreshPromotersIncome(insertParams);
                    LOG.info("addRefreshPromotersIncome记录成功, insertParams={}", insertParams);
                }catch(DuplicateKeyException e){
                    LOG.error("addRefreshPromotersIncome记录已存在, insertParams={}", insertParams);
                    continue;
                }

                Query updateAgentInfoQuery = new Query();
                updateAgentInfoQuery.addCriteria(new Criteria("aid").is(channelAgentEntity.getAid()));
                Update update = new Update();
                update.set("tincome", rpi_final_tincome);
                update.set("channel_total_income", rpi_final_channel_total_income);

                try{
                    this.mongoTemplate.updateFirst(updateAgentInfoQuery, update, "agent");
                }catch (Exception e){
                    LOG.error("updateAgentInfo, fail, insertParams={}", insertParams);
                }

                LOG.info("updateAgentInfo, success, insertParams={}", insertParams);
            }
        }

    }


}
