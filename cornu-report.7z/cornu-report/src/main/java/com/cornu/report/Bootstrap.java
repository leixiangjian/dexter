package com.cornu.report;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.mongo.MongoProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.ImportResource;

/**
 * 启动 spring-boot
 * @author DEXTER
 *
 */
@ImportResource({"classpath:applicationContext.xml","classpath:applicationContext-job.xml","classpath:applicationContext-dao.xml"})
@SpringBootApplication
@EnableConfigurationProperties(MongoProperties.class)//改成单例模式
public class Bootstrap{
	public static void main(String[] args) {
		SpringApplication.run(Bootstrap.class, args);
	}

}
