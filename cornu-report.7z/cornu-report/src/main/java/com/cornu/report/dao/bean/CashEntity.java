package com.cornu.report.dao.bean;

public class CashEntity {
	private String aid;
	private String cid;
	private long amount;
	private double status;
	private long ctime;
	private long mtime;
	private String extra;
	
	private Long final_amount;
	private Long current_amount;
	
	public String getExtra() {
		return extra;
	}

	public void setExtra(String extra) {
		this.extra = extra;
	}

	public String getAid() {
		return aid;
	}

	public void setAid(String aid) {
		this.aid = aid;
	}

	public String getCid() {
		return cid;
	}

	public void setCid(String cid) {
		this.cid = cid;
	}

	public long getAmount() {
		return amount;
	}

	public void setAmount(long amount) {
		this.amount = amount;
	}

	public double getStatus() {
		return status;
	}

	public void setStatus(double status) {
		this.status = status;
	}

	public long getCtime() {
		return ctime;
	}

	public void setCtime(long ctime) {
		this.ctime = ctime;
	}

	public long getMtime() {
		return mtime;
	}

	public void setMtime(long mtime) {
		this.mtime = mtime;
	}

	public Long getFinal_amount() {
		return final_amount;
	}

	public void setFinal_amount(Long final_amount) {
		this.final_amount = final_amount;
	}

	public Long getCurrent_amount() {
		return current_amount;
	}

	public void setCurrent_amount(Long current_amount) {
		this.current_amount = current_amount;
	}

}
