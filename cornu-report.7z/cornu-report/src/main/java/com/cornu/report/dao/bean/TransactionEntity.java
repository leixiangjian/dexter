package com.cornu.report.dao.bean;

public class TransactionEntity {
	private String aid;
	private String appid;
	private String did;
	private String uid;
	private String uname;
	private String oid;
	private long otime;
	private String ip;
	private long recharge;
	private String retrade;
	private String status;
	private long ctime;
	private long mtime;
	private long day_for_agent;
	private String channelcd;
	private double channel_income;
	private String member_channelcd;
	private String headman_channelcd;
	private double headman_income;
	private String headman_aid;
	private String isValid;
	private long validTime;

	public double getDay_for_agent() {
		return day_for_agent;
	}

	public void setDay_for_agent(long day_for_agent) {
		this.day_for_agent = day_for_agent;
	}

	public String getAid() {
		return aid;
	}

	public void setAid(String aid) {
		this.aid = aid;
	}

	public String getAppid() {
		return appid;
	}

	public void setAppid(String appid) {
		this.appid = appid;
	}

	public String getDid() {
		return did;
	}

	public void setDid(String did) {
		this.did = did;
	}

	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	public String getOid() {
		return oid;
	}

	public void setOid(String oid) {
		this.oid = oid;
	}

	public long getOtime() {
		return otime;
	}

	public void setOtime(long otime) {
		this.otime = otime;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public long getRecharge() {
		return recharge;
	}

	public void setRecharge(long recharge) {
		this.recharge = recharge;
	}

	public String getRetrade() {
		return retrade;
	}

	public void setRetrade(String retrade) {
		this.retrade = retrade;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public long getCtime() {
		return ctime;
	}

	public void setCtime(long ctime) {
		this.ctime = ctime;
	}

	public long getMtime() {
		return mtime;
	}

	public void setMtime(long mtime) {
		this.mtime = mtime;
	}

	public double getChannel_income() {
		return channel_income;
	}

	public void setChannel_income(double channel_income) {
		this.channel_income = channel_income;
	}

	public String getChannelcd() {
		return channelcd;
	}

	public void setChannelcd(String channelcd) {
		this.channelcd = channelcd;
	}

	public String getHeadman_aid() {
		return headman_aid;
	}

	public void setHeadman_aid(String headman_aid) {
		this.headman_aid = headman_aid;
	}

	public String getHeadman_channelcd() {
		return headman_channelcd;
	}

	public void setHeadman_channelcd(String headman_channelcd) {
		this.headman_channelcd = headman_channelcd;
	}

	public double getHeadman_income() {
		return headman_income;
	}

	public void setHeadman_income(double headman_income) {
		this.headman_income = headman_income;
	}

	public String getMember_channelcd() {
		return member_channelcd;
	}

	public void setMember_channelcd(String member_channelcd) {
		this.member_channelcd = member_channelcd;
	}

	public String getIsValid() {
		return isValid;
	}

	public void setIsValid(String isValid) {
		this.isValid = isValid;
	}

	public long getValidTime() {
		return validTime;
	}

	public void setValidTime(long validTime) {
		this.validTime = validTime;
	}
}
