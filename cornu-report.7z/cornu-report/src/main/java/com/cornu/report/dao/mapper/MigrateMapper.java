package com.cornu.report.dao.mapper;

import java.util.Map;

public interface MigrateMapper {
	public void addAgent(Map<String,Object> map);
	public void updateAgent(Map<String,Object> map);
	
	public void addApp(Map<String,Object> map);
	public void updateApp(Map<String,Object> map);
	
	public void addAppDayBook(Map<String,Object> map);
	public void deleteAppDayBook(Map<String,Object> map);
	
	public void addCash(Map<String,Object> map);
	public void updateCash(Map<String,Object> map);
	
	public void addChannel(Map<String,Object> map);
	public void updateChannel(Map<String,Object> map);
	
	public void addDayBook(Map<String,Object> map);
	public void deleteDayBook(Map<String,Object> map);
	
	public void addDev(Map<String,Object> map);
	public void updateDev(Map<String,Object> map);
	
	public void addGlobalDayBook(Map<String,Object> map);
	public void deleteGlobalDayBook(Map<String,Object> map);
	
	public void addLog(Map<String,Object> map);
	public void deleteLog(Map<String,Object> map);
	
	public void addRebate(Map<String,Object> map);
	public void updateRebate(Map<String,Object> map);
	
	public void addTransaction(Map<String,Object> map);
	public void deleteTransaction(Map<String,Object> map);
	
	public void addWhite(Map<String,Object> map);
	public void updateWhite(Map<String,Object> map);
	
	public void addSysUser(Map<String,Object> map);
	public void updateSysUser(Map<String,Object> map);

	public void addChannelIncome(Map<String,Object> map);
	public void deleteChannelIncome(Map<String,Object> map);

	public void addHeadmanIncome(Map<String,Object> map);
	public void deleteHeadmanIncome(Map<String,Object> map);

	public void saveAccountReportCurrent(Map<String,Object> map);
	public void updateAccountReportCurrent(Map<String,Object> map);
}
