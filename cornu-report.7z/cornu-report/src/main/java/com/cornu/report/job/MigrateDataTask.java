package com.cornu.report.job;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.cornu.report.service.MigrateDataService;

/**
 * 迁移数据
 * 
 * @author lenovo01
 *
 */
@Component("migrateDataTask")
public class MigrateDataTask {
	private static final Logger LOG = LoggerFactory.getLogger(MigrateDataTask.class);
	@Autowired(required = true)
	@Qualifier(value = "migrateDataService")
	MigrateDataService migrateDataService;

	@Value("${migrate.enabled}")
	String enabled;

	public void migrateAgent() {
		try {
			if (!Boolean.parseBoolean(enabled)) {
				return;
			}

			migrateDataService.migrateAgent();
			LOG.info("thread:{},迁移migrateAgent数据......", Thread.currentThread().getId());
		} catch (Exception e) {
			LOG.error("thread:{},迁移migrateAgent数据异常", Thread.currentThread().getId(), e);
		}
	}
	
	public void migrateApp(){
		try {
			if (!Boolean.parseBoolean(enabled)) {
				return;
			}

			migrateDataService.migrateApp();
			LOG.info("thread:{},迁移migrateApp数据......", Thread.currentThread().getId());
		} catch (Exception e) {
			LOG.error("thread:{},迁移migrateApp数据异常", Thread.currentThread().getId(), e);
		}
	}
	
	public void migrateCash(){
		try {
			if (!Boolean.parseBoolean(enabled)) {
				return;
			}

			migrateDataService.migrateCash();
			LOG.info("thread:{},迁移migrateCash数据......", Thread.currentThread().getId());
		} catch (Exception e) {
			LOG.error("thread:{},迁移migrateCash数据异常", Thread.currentThread().getId(), e);
		}
	}
	
	public void migrateChannel(){
		try {
			if (!Boolean.parseBoolean(enabled)) {
				return;
			}

			migrateDataService.migrateChannel();
			LOG.info("thread:{},迁移migrateChannel数据......", Thread.currentThread().getId());
		} catch (Exception e) {
			LOG.error("thread:{},迁移migrateChannel数据异常", Thread.currentThread().getId(), e);
		}
	}
	
	public void migrateDayBook(){
		try {
			if (!Boolean.parseBoolean(enabled)) {
				return;
			}

			migrateDataService.migrateDayBook();
			LOG.info("thread:{},迁移migrateDayBook数据......", Thread.currentThread().getId());
		} catch (Exception e) {
			LOG.error("thread:{},迁移migrateDayBook数据异常", Thread.currentThread().getId(), e);
		}
	}
	
	public void migrateDev(){
		try {
			if (!Boolean.parseBoolean(enabled)) {
				return;
			}

			migrateDataService.migrateDev();
			LOG.info("thread:{},迁移migrateDev数据......", Thread.currentThread().getId());
		} catch (Exception e) {
			LOG.error("thread:{},迁移migrateDev数据异常", Thread.currentThread().getId(), e);
		}
	}
	
	public void migrateGlobalDayBook(){
		try {
			if (!Boolean.parseBoolean(enabled)) {
				return;
			}

			migrateDataService.migrateGlobalDayBook();
			LOG.info("thread:{},迁移migrateGlobalDayBook数据......", Thread.currentThread().getId());
		} catch (Exception e) {
			LOG.error("thread:{},迁移migrateGlobalDayBook数据异常", Thread.currentThread().getId(), e);
		}
	}
	
	public void migrateRebate(){
		try {
			if (!Boolean.parseBoolean(enabled)) {
				return;
			}

			migrateDataService.migrateRebate();
			LOG.info("thread:{},迁移migrateRebate数据......", Thread.currentThread().getId());
		} catch (Exception e) {
			LOG.error("thread:{},迁移migrateRebate数据异常", Thread.currentThread().getId(), e);
		}
	}
	
	public void migrateWhite(){
		try {
			if (!Boolean.parseBoolean(enabled)) {
				return;
			}

			migrateDataService.migrateWhite();
			LOG.info("thread:{},迁移migrateWhite数据......", Thread.currentThread().getId());
		} catch (Exception e) {
			LOG.error("thread:{},迁移migrateWhite数据异常", Thread.currentThread().getId(), e);
		}
	}
	
	public void migrateAppDayBook(){
		try {
			if (!Boolean.parseBoolean(enabled)) {
				return;
			}

			migrateDataService.migrateAppDayBook();
			LOG.info("thread:{},迁移migrateAppDayBook数据......", Thread.currentThread().getId());
		} catch (Exception e) {
			LOG.error("thread:{},迁移migrateAppDayBook数据异常", Thread.currentThread().getId(), e);
		}
	}
	
	public void migrateLog(){
		try {
			if (!Boolean.parseBoolean(enabled)) {
				return;
			}

			migrateDataService.migrateLog();
			LOG.info("thread:{},迁移migrateLog数据......", Thread.currentThread().getId());
		} catch (Exception e) {
			LOG.error("thread:{},迁移migrateLog数据异常", Thread.currentThread().getId(), e);
		}
	}
	
	public void migrateTransaction(){
		try {
			if (!Boolean.parseBoolean(enabled)) {
				return;
			}

			migrateDataService.migrateTransaction();
			LOG.info("thread:{},迁移migrateTransaction数据......", Thread.currentThread().getId());
		} catch (Exception e) {
			LOG.error("thread:{},迁移migrateTransaction数据异常", Thread.currentThread().getId(), e);
		}
	}

	public void migrateChannelIncome(){
		try {
			if (!Boolean.parseBoolean(enabled)) {
				return;
			}

			migrateDataService.migrateChannelIncome();
			LOG.info("thread:{},迁移migrateChannelIncome数据......", Thread.currentThread().getId());
		} catch (Exception e) {
			LOG.error("thread:{},迁移migrateChannelIncome数据异常", Thread.currentThread().getId(), e);
		}
	}

	public void migrateHeadmanIncome(){
		try {
			if (!Boolean.parseBoolean(enabled)) {
				return;
			}

			migrateDataService.migrateHeadmanIncome();
			LOG.info("thread:{},迁移migrateHeadmanIncome数据......", Thread.currentThread().getId());
		} catch (Exception e) {
			LOG.error("thread:{},迁移migrateHeadmanIncome数据异常", Thread.currentThread().getId(), e);
		}
	}
	
	public void migrateAccountReport(){
		try {
			if (!Boolean.parseBoolean(enabled)) {
				return;
			}
			
			migrateDataService.migrateAccountReport();
			LOG.info("thread:{},迁移migrateAccountReport数据......", Thread.currentThread().getId());
		} catch (Exception e) {
			LOG.error("thread:{},迁移migrateAccountReport数据异常", Thread.currentThread().getId(), e);
		}
	}

}
