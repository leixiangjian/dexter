(function ($) {

    var pri = {
        conf: {
            api: {
                agentSet: '/cornu/agent/set', // 设置个人信息
                agentGet: '/cornu/agent/get', // 获取个人信息
                cashAdd: '/cornu/cash/add', // 提现
                cashList: '/cornu/cash/list', // 提现记录
                logout: '/cornu/agent/logout', // 登出
                tokenSend: '/cornu/token/send'  // 获取验证码
            },
            cashList: {
                page: 1,
                limit: 20
            }
        },
        eventHandle: function () {
            // 左侧nav栏
            $('[node-type="passwd-change"]').on('click', function () {
                $(this).siblings().removeClass('active');
                $(this).addClass('active');
                pri.render.updatePasswdChangeView();
            });
            $('[node-type="revenue"]').on('click', function () {
                $(this).siblings().removeClass('active');
                $(this).addClass('active');
                pri.getData.getAgentIncome();
                pri.getData.getAgentCashList();
            });
            $('[node-type="bank-card"]').on('click', function () {
                $(this).siblings().removeClass('active');
                $(this).addClass('active');
                pri.getData.getAgentBankCard();
            });
            // 获取验证码（改密表单）
            $('#getVcode-pwchange').on('click', function () {
                var phone = $.trim($('#phone-pwchange').val());
                if (!phone) {
                    $('#phone-pwchange').parent('.form-group').addClass('has-error').
                    find('.control-label').text('请先输入手机号！');
                    return;
                }
                if ($(this).hasClass('disable')) {
                    return;
                }
                $(this).addClass('disable');
                pri.method.countdown(60, $('#getVcode-pwchange'));
                pri.method.getVcode(phone);
            });
            // 修改密码提交
            $('[node-type="passwd-change-submit"]').on('click', function (e) {
                e.preventDefault();
                var data = userinfoValidator.passwdChangeValidator();
                if (data) {
                    pri.method.passwdChange(data);
                }
            });

            // 获取验证码（提现表单）
            $('#getVcode-add-income').on('click', function () {
                var phone = $.trim($('#phone-add-income').val());
                if (!phone) {
                    $('#phone-add-income').parent('.form-group').addClass('has-error').
                    find('.control-label').text('请先输入手机号！');
                    return;
                }
                if ($(this).hasClass('disable')) {
                    return;
                }
                $(this).addClass('disable');
                pri.method.countdown(60, $('#getVcode-add-income'));
                pri.method.getVcode(phone);
            });
            // 提现提交按钮
            if (new Date().getDay() === 2) {
                $('[node-type="add-income-submit"]').on('click', function (e) {
                    e.preventDefault();
                    var data = userinfoValidator.addIncomeValidator(pri.currentincome);
                    if (data) {
                        pri.method.addCash(data);
                    }
                });
            } else {
                $('[node-type="add-income-submit"]').attr('disabled', 'disabled');
            }
            $('[node-type="cash-list-prev-page"]').on('click', function (e) {
                e.preventDefault();
                if (pri.conf.cashList.page > 1) {
                    pri.conf.cashList.page--;
                    pri.getData.getAgentCashList();
                }
            });
            $('[node-type="cash-list-next-page"]').on('click', function (e) {
                e.preventDefault();
                pri.conf.cashList.page++;
                pri.getData.getAgentCashList();
            });


            // 获取验证码（修改银行卡表单）
            $('#getVcode-change-card').on('click', function () {
                var phone = $.trim($('#phone-change-card').val());
                if (!phone) {
                    $('#phone-change-card').parent('.form-group').addClass('has-error').
                    find('.control-label').text('请先输入手机号！');
                    return;
                }
                if ($(this).hasClass('disable')) {
                    return;
                }
                $(this).addClass('disable');
                pri.method.countdown(60, $('#getVcode-change-card'));
                pri.method.getVcode(phone);
            });
            // 银行卡表单提交
            $('[node-type="bankcard-submit"]').on('click', function (e) {
                e.preventDefault();
                var data = userinfoValidator.bankcardValidator();
                if (data) {
                    pri.method.changeCard(data);
                }
            });

            // 登出
            $('#logout').on('click', function () {
                pri.method.logout();
            });

            // 左侧栏显示
            $('[node-type="menu-toggle"]').on('click', function () {
                pri.render.showMenu(true);
                $('#mainContent').on('click', function () {
                    pri.render.showMenu(false);
                });
                $('#appItems').on('click', function () {
                    pri.render.showMenu(false);
                });
            });
        },
        render: {
            resizeHandle: function () {
                var w = $(window).width();
                var h = $(window).height();
                // 重置页面高度
                $('.main-h').css({
                    'height': h - 60
                });
                $('#mainContent').height(h - 60 - 46);
            },
            // 显示修改密码视图
            updatePasswdChangeView: function () {
                $('#PasswdChange').hide();
                $('#Income').hide();
                $('#BankCard').hide();
            },
            // 显示总收入视图
            updateIncomeView: function (data) {
                pri.conf.tincome = data.tincome;
                pri.currentincome = data.tincome - data.ttake;
                $('[node-type="total-income"]').text(pri.conf.tincome);
                $('[node-type="current-income"]').text(pri.currentincome);
                if (pri.currentincome > 100) {
                    $('[node-type="add-income-form"]').show();
                    $('[node-type="add-income"]').val('');
                } else {
                    $('[node-type="add-income-form"]').hide();
                }
                $('#PasswdChange').hide();
                $('#Income').hide();
                $('#BankCard').hide();
            },
            updateCashList: function (res) {
                var list = res.list;
                var has_more = res.has_more;
                if (list && list.length) {
                    var cashItemArr = [];
                    var statusText = '';
                    for (var i = 0; i < list.length; i++) {
                        var item = list[i];
                        if (item.status == 0) {
                            statusText = '提款中';
                        } else if (item.status == 1) {
                            statusText = '已受理';
                        } else if (item.status == 2) {
                            statusText = '成功提款';
                        } else {
                            statusText = '提款失败';
                        }
                        var tmpl = [
                            '<tr>',
                            '    <td>' + window.cornu.parseDate(item.ctime) + '</td>',
                            '    <td>' + item.amount + '</td>',
                            '    <td>' + (item.extra ? item.extra : '') + '</td>',
                            '    <td>' + statusText + '</td>',
                            '</tr>'
                        ].join('');
                        cashItemArr.push(tmpl);
                    }
                    $('[node-type="cash-add-list"]').html(cashItemArr.join(''));

                    // 上一页
                    $('[node-type="cash-list-prev-page"]').toggle(pri.conf.cashList.page > 1);
                    // 下一页
                    $('[node-type="cash-list-next-page"]').toggle(!!has_more);

                    $('[node-type="cash-add-detail"]').show();
                } else {
                    $('[node-type="cash-add-detail"]').hide();
                }
            },
            // 显示银行卡视图
            updateBankCardView: function (data) {
                $('[node-type="bankname"]').val(data.bankname);
                $('[node-type="cardno"]').val(data.cardno);
                $('[node-type="username"]').val(data.username);
                if (!data.cardno) {
                    $('[node-type="bankcard-submit"]').text('添加银行卡');
                } else {
                    $('[node-type="bankcard-submit"]').text('修改银行卡');
                }
                $('#PasswdChange').hide();
                $('#Income').hide();
                $('#BankCard').hide();
            },
            // 收起，展示左侧列表
            showMenu: function (flag) {
                if (flag) {
                    $('#appItems').animate({
                        left: '0rem'
                    });
                    $('#logo').animate({
                        left: '0rem'
                    });
                } else {
                    $('#appItems').animate({
                        left: '-15rem'
                    });
                    $('#logo').animate({
                        left: '-15rem'
                    });
                }
            }
        },
        getData: {
            // 获取收入情况
            getAgentIncome: function () {
                pri.method.sendAjax({
                    url: pri.conf.api.agentGet,
                    success: function (res) {
                        if (res.list) {
                            pri.render.updateIncomeView(res.list[0]);
                        } else {
                            window.cornu.tip.show({
                                type: 'warn',
                                msg: '没有数据'
                            });
                        }
                    }
                });
            },
            // 提现记录list
            getAgentCashList: function () {
                var start = (pri.conf.cashList.page - 1) * 20;
                pri.method.sendAjax({
                    url: pri.conf.api.cashList,
                    data: {
                        start: start,
                        limit: pri.conf.cashList.limit
                    },
                    success: function (res) {
                        pri.render.updateCashList(res);
                    }
                });
            },
            getAgentBankCard: function () {
                pri.method.sendAjax({
                    url: pri.conf.api.agentGet,
                    success: function (res) {
                        if (res.list) {
                            pri.render.updateBankCardView(res.list[0]);
                        } else {
                            window.cornu.tip.show({
                                type: 'warn',
                                msg: '没有数据'
                            });
                        }
                    }
                });
            }
        },
        method: {
            // 修改密码
            passwdChange: function (data) {
                pri.method.sendAjax({
                    url: pri.conf.api.agentSet,
                    data: data,
                    success: function () {
                        window.cornu.tip.show({
                            type: 'success',
                            msg: '重置密码成功'
                        });
                        $('[node-type="oldpasswd"]').val('');
                        $('[node-type="passwd"]').val('');
                        $('[node-type="passwd-confirm"]').val('');
                    }
                })
            },
            // 提现
            addCash: function (data) {
                pri.method.sendAjax({
                    url: pri.conf.api.cashAdd,
                    data: data,
                    success: function () {
                        window.cornu.tip.show({
                            type: 'success',
                            msg: '申请提交成功'
                        });
                        pri.getData.getAgentIncome();
                        pri.getData.getAgentCashList();
                    }
                })
            },
            changeCard: function (data) {
                pri.method.sendAjax({
                    url: pri.conf.api.agentSet,
                    data: data,
                    success: function () {
                        window.cornu.tip.show({
                            type: 'success',
                            msg: '修改银行卡成功！'
                        });
                    }
                })
            },
            countdown: function (c, dom) {
                if (!c) {
                    dom.removeClass('disable').text('获取验证码');
                    return;
                }
                c--;
                $('#getVcode').text(c + 's后可重新获取');
                setTimeout(function () {
                    pri.method.countdown(c, dom);
                }, 1000);
            },
            getVcode: function (phone) {
                $.ajax({
                    url: pri.conf.api.tokenSend,
                    data: {
                        phone: phone
                    }
                }).then(function (res) {
                    if (res && res.errno == 0) {
                        window.cornu.tip.show({
                            type: 'success',
                            msg: '请查收短信验证码'
                        });
                    } else if (res && res.errno) {
                        window.cornu.tip.show({
                            type: 'warn',
                            msg: (window.cornu.errorMsg[res.errno] || '操作异常')
                        });
                    } else {
                        window.cornu.tip.show({
                            type: 'warn',
                            msg: '操作异常'
                        });
                    }
                }, function () {
                    window.cornu.tip.show({
                        type: 'failure',
                        msg: '网络异常'
                    });
                });
            },
            // 登出
            logout: function () {
                pri.method.sendAjax({
                    url: pri.conf.api.logout,
                    success: function () {
                        location.href = location.protocol + '//' + location.host + '/cornu/login';
                    }
                });
            },
            sendAjax: function (options) {
                $.ajax({
                    url: options.url,
                    data: options.data
                }).then(function (res) {
                    if (res && res.errno == 0) {
                        typeof options.success === 'function' && options.success(res);
                    } else if (res && res.errno) {
                        window.cornu.tip.show({
                            type: 'warn',
                            msg: (window.cornu.errorMsg[res.errno] || '操作异常')
                        });
                    } else {
                        window.cornu.tip.show({
                            type: 'warn',
                            msg: '操作异常'
                        });
                    }
                    typeof options.always === 'function' && options.always(res);
                }, function (res) {
                    window.cornu.tip.show({
                        type: 'failure',
                        msg: '网络异常'
                    });
                    typeof options.error === 'function' && options.error(res);
                    typeof options.always === 'function' && options.always(res);
                });
            }
        }
    };

    var pub = {
        init: function () {
            var execResize;
            pri.render.resizeHandle();
            $(window).on('resize', function () {
                if (execResize) {
                    clearTimeout(execResize);
                }
                execResize = setTimeout(pri.render.resizeHandle, 600);
            });
            pri.eventHandle();
            pri.getData.getAgentIncome();
            pri.getData.getAgentCashList();
        }
    };

    pub.init();
})($);
