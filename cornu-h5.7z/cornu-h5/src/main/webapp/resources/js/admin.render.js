(function ($) {

    var adminRender = {
        resizeHandle: function () {
            var w = $(window).width();
            var h = $(window).height();
            // 重置页面高度
            $('.main-h').css({
                'height': h - 60
            });
            $('#mainContent').height(h - 60);
        },
        updateAgentInfo: function (data) {
            $('#agentDetailApproveModal').find('[node-type="agent-phone"]').text(data.agent_info.phone);
            $('#agentDetailApproveModal').find('[node-type="agent-amount"]').text(data.amount);
            $('#agentDetailApproveModal').find('[node-type="agent-cardno"]').text(data.agent_info.cardno);
            $('#agentDetailApproveModal').find('[node-type="agent-username"]').text(data.agent_info.username);
            $('#agentDetailApproveModal').find('[node-type="agent-bankname"]').text(data.agent_info.bankname);
            $('#agentDetailApproveModal').modal('show');
        },
        updateCashList: function (list, currentPage, has_more) {
            if (list && list.length) {
                var cashItemArr = [];
                var statusText = '';
                for (var i = 0; i < list.length; i++) {
                    var item = list[i];
                    var t = window.cornu.parseDate(item.ctime, true);
                    var confirmButtonType = '';
                    var refuseButtonType = '';
                    var disable = '';
                    if (item.status == 1) {
                        confirmButtonType = ' node-type="money-given-button"';
                        refuseButtonType = ' node-type="money-given-refuse"';
                        statusText = '处理中';
                    } else if (item.status == 2) {
                        disable = ' disabled="disabled"';
                        statusText = '已打款';
                    } else if (item.status == 3) {
                        disable = ' disabled="disabled"';
                        statusText = '已拒绝受理';
                    }
                    var confrimBt = '<button type="button"' + disable + confirmButtonType + ' class="btn btn-primary">打钱确认</button>';
                    var refuseBt = '<button type="button"' + disable + refuseButtonType + ' class="btn btn-danger">拒绝受理</button>'
                    try {
                        var tmpl = [
                            '<tr data-index="' + i + '" data-cid="' + item.cid + '" data-status="' + item.status + '" data-aid="' + item.aid + '">',
                            '    <td><a title="点击查看银行卡信息" href="javascript:;" node-type="show-agent-detail">' + item.agent_info.username + '</a></td>',
                            '    <td>' + t + '</td>',
                            '    <td>' + item.amount + '</td>',
                            '    <td>' + statusText + '</td>',
                            '    <td>' + (item.extra ? item.extra : '') + '</td>',
                            '    <td>' + confrimBt + '&nbsp;&nbsp;' + refuseBt + '</td>',
                            '</tr>'
                        ].join('');
                        cashItemArr.push(tmpl);
                    } catch (e) {}
                }
                $('[node-type="cash-get-list"]').html(cashItemArr.join(''));

                $('[node-type="cash-add-detail"]').show();
            } else {
                $('[node-type="cash-get-list"]').html('<tr class="none-list"><td colspan="6it ">暂无数据</td></tr>');
            }
            // 上一页
            $('[node-type="prev-page"]').toggle(currentPage > 0);
            // 下一页
            $('[node-type="next-page"]').toggle(!!has_more);
        },
        updateAppIncomeList: function (list, currentPage, has_more) {
            if (list && list.length) {
                var appSumItemArr = [];
                var tmpl = [
                    '<tr>' +
                    '<th>应用名称</th>'+
                    '<th>消费总额（元）</th>'+
                    '<th>平台收入（元）</th>'+
                    '<th>代理收入（元）</th>'+
                    '<th>支付金额（元）</th>'+
                    '<th>操作</th>'+
                    '</tr>'
                ].join('');
                appSumItemArr.push(tmpl);
                for (var i = 0; i < list.length; i++) {
                    var item = list[i];
                    var confirmButtonType = ' node-type="money-give-cornu"';
                    var confrimBt = '<button type="button"'  + confirmButtonType + ' class="btn btn-primary">确认收款</button>';
                    try {
                        var tmpl = [
                            '<tr data-index="' + i + '" data-appid="' + item.appid + '" data-totalsum="'
                            + item.totalsum +'" data-selfsum="' + item.selfsum +'" data-agentsum="'
                            + item.agentsum +'" data-paysum="' + item.paysum + '">',
                            '    <td>' + item.appname + '</a></td>',
                            '    <td>' + item.totalsum + '</td>',
                            '    <td>' + item.selfsum + '</td>',
                            '    <td>' + item.agentsum + '</td>',
                            '    <td>' + item.paysum + '</td>',
                            '    <td>' + confrimBt +'</td>',
                            '</tr>'
                        ].join('');
                        appSumItemArr.push(tmpl);
                    } catch (e) {}
                }
                $('[node-type="app-income-get-list"]').html(appSumItemArr.join(''));

            } else {
                $('[node-type="app-income-get-list"]').html('<tr class="none-list"><td colspan="6">暂无数据</td></tr>');
            }
            // 上一页
            $('[node-type="prev-page"]').toggle(currentPage > 0);
            // 下一页
            $('[node-type="next-page"]').toggle(!!has_more);
        },

        updateOperList: function (list, currentPage, has_more) {
            if (list && list.length) {
                var appSumItemArr = [];
                var tmpl = [
                    '<tr>' +
                    '<th>客服名称</th>'+
                    '<th>操作类型</th>'+
                    '<th>操作对象</th>'+
                    '<th>具体内容</th>'+
                    '<th>操作时间</th>'+
                    '<th>操作ip</th>'+
                    '</tr>'
                ].join('');
                appSumItemArr.push(tmpl);
                for (var i = 0; i < list.length; i++) {
                    var item = list[i];
                    try {
                        var tmpl = [
                            '<tr>',
                            '    <td>' + item.op_phone + '</a></td>',
                            '    <td>' + item.type_str + '</td>',
                            '    <td>' + item.oper_str + '</td>',
                            '    <td>' + item.msg + '</td>',
                            '    <td>' + window.cornu.parseDate(item.ctime, true) + '</td>',
                            '    <td>' + item.ip +'</td>',
                            '</tr>'
                        ].join('');
                        appSumItemArr.push(tmpl);
                    } catch (e) {}
                }
                $('[node-type="oper-get-list"]').html(appSumItemArr.join(''));

            } else {
                $('[node-type="oper-get-list"]').html('<tr class="none-list"><td colspan="6">暂无数据</td></tr>');
            }
            // 上一页
            $('[node-type="prev-page"]').toggle(currentPage > 0);
            // 下一页
            $('[node-type="next-page"]').toggle(!!has_more);
        },

        updateDevList: function (list) {
            if (list && list.length) {
                var devItemArr = [];
                for (var i = 0; i < list.length; i++) {
                    var item = list[i];
                    var tmpl = [
                        '<li ' + (i ? '' : 'class="current"') + ' data-did="' + item.did + '" node-type="dev-list-li">',
                        '    <span node-type="dev-name">' + item.uname + '</span>',
                        '    <a href="javascript:;" class="operate-delete" data-did="' + item.did + '" node-type="dev-delete-button">',
                        '        删除',
                        '    </a>',
                        '    <a href="javascript:;" class="operate-edit" data-did="' + item.did + '" node-type="dev-edit-button">',
                        '        编辑',
                        '    </a>',
                        '    <a href="javascript:;" class="operate-detail" data-did="' + item.did + '" node-type="dev-detail-button">',
                        '        详情',
                        '    </a>',
                        '</li>'
                    ].join('');
                    devItemArr.push(tmpl);
                }
                $('[node-type="dev-list"]').html(devItemArr.join(''));
            } else {
                $('[node-type="dev-list"]').html('<li class="current">暂无数据</li>');
            }
        },
        // 更新研发商详情展示弹框
        updateDevDetailModalView: function (data) {
            $devDetailModal = $('#devDetailModal');
            $devDetailModal.find('[node-type="dev-did"]').text(data.did ? data.did : '');
            $devDetailModal.find('[node-type="dev-uname"]').text(data.uname ? data.uname : '');
            $devDetailModal.find('[node-type="dev-phone"]').text(data.phone ? data.phone : '');
            $devDetailModal.find('[node-type="dev-stoken"]').text(data.stoken ? data.stoken : '');
        },
        updateDevFormModalView: function (method, data) {
            $devFormModal = $('#devFormModal');
            $devFormModal.find('[node-type="dev-id"]').val(data.did ? data.did : '');
            $devFormModal.find('[node-type="dev-phone"]').val(data.phone ? data.phone : '');
            $devFormModal.find('[node-type="dev-desc"]').val(data.desc ? data.desc : '');

            if (method === 'register') {
                $devFormModal.find('[node-type="dev-form-modal-title"]').text('添加');
                $devFormModal.find('[node-type="dev-uname"]').val('').parent().show();
            } else {
                $devFormModal.find('[node-type="dev-form-modal-title"]').text('编辑');
                $devFormModal.find('[node-type="dev-uname"]').parent().hide();
            }
        },
        updateDevAppList: function (list, currentPage, has_more) {
            if (list && list.length) {
                var appItemArr = [];
                for (var i = 0; i < list.length; i++) {
                    var item = list[i];
                    var statusText = '';
                    switch (item.status) {
                        // 重置当前页面
                        case 0:
                            statusText = '审核中';
                            break;
                        case 1:
                            statusText = '已上架';
                            break;
                        case 2:
                            statusText = '已下架';
                            break;
                    }
                    var tmpl = [
                        '<div class="app-list-item">',
                        '    <table class="table app-infos">',
                        '        <tr>',
                        '            <td rowspan="3" style="text-align:center;"><img src="' + item.applogo + '" alt="" node-type="app-applogo" class="app-applogo"></td>',
                        '            <td class="text-left"><strong>appID：</strong></td>',
                        '            <td class="text-left" node-type="app-appid" colspan="3">' + item.appid + '</td>',
                        '        </tr>',
                        '        <tr>',
                        '            <td class="text-left"><strong>app描述：</strong></td>',
                        '            <td class="text-left" node-type="app-version" colspan="3">',
                        '               <textarea readonly class="form-control" rows="3">' + item.desc + '</textarea>',
                        '            </td>',
                        '        </tr>',
                        '        <tr>',
                        '            <td class="text-left"><strong>推广语模板：</strong></td>',
                        '            <td class="text-left" node-type="app-version" colspan="3">',
                        '               <textarea readonly class="form-control" rows="3">' + item.spread+ '</textarea>',
                        '            </td>',
                        '            <td></td>',
                        '        </tr>',
                        '        <tr>',
                        '            <td></td>',
                        '            <td class="text-left"><strong>app等级：</strong></td>',
                        '            <td class="text-left" node-type="app-version">' + item.level + '</td>',
                        '            <td class="text-left">创建时间：</td>',
                        '            <td class="text-left" node-type="app-apptime">' + window.cornu.parseDate(item.apptime, true) + '</td>',
                        '        </tr>',
                        '        <tr>',
                        '            <td node-type="app-name" style="text-align:center;">' + item.appname + '</td>',
                        '            <td class="text-left"><strong>软件大小：</strong></td>',
                        '            <td class="text-left" node-type="app-size">' + item.size + '</td>',
                        '            <td class="text-left"><strong>开发语言：</strong></td>',
                        '            <td class="text-left" node-type="app-language">' + item.language + '</td>',
                        '        </tr>',
                        '        <tr>',
                        '            <td></td>',
                        '            <td class="text-left"><strong>软件版本：</strong></td>',
                        '            <td class="text-left" node-type="app-version">' + item.version + '</td>',
                        '            <td class="text-left"><strong>支持系统：</strong></td>',
                        '            <td class="text-left" node-type="app-system">' + item.system + '</td>',
                        '        </tr>',
                        '        <tr>',
                        '            <td></td>',
                        '            <td class="text-left" colspan="2"><strong>研发商与平台分成比例：</strong></td>',
                        '            <td class="text-left" colspan="2"><strong>代理商与平台分成比例：</strong></td>',
                        '        </tr>',
                        '        <tr>',
                        '            <td></td>',
                        '            <td class="text-left" node-type="app-language" colspan="2">' + item.rate + '%</td>',
                        '            <td class="text-left" node-type="app-language" colspan="2">' + item.proportion + '%</td>',
                        '        </tr>',
                        '        <tr>',
                        '            <td></td>',
                        '            <td class="text-left"><strong>实时奖励：</strong></td>',
                        '            <td class="text-left" node-type="app-status">' + (item.rltimeret ? '是' : '否') + '</td>',
                        '            <td class="text-left"><strong>图片推广：</strong></td>',
                        '            <td class="text-left" node-type="app-status">' + (item.pic_type ? '是' : '否') + '</td>',
                        '            <td class="text-left"><strong>首充奖励：</strong></td>',
                        '            <td class="text-left" node-type="app-status">' + (item.ftrade/100) + '元</td>',
                        '        </tr>',
                        '        <tr>',
                        '            <td></td>',
                        '            <td class="text-left"><strong>应用状态：</td>',
                        '            <td class="text-left" node-type="app-status">' + statusText + '</td>',
                        '        </tr>',
                        '        <tr>',
                        '            <td></td>',
                        '            <td class="text-left"><strong>下载地址：</td>',
                        '            <td class="text-left" node-type="app-dlink" colspan="3" rowspan="3">',
                        '               <textarea readonly class="form-control" rows="3">' + item.dlink + '</textarea>',
                        '            </td>',
                        '        </tr>',
                        '        <tr>',
                        '        </tr>',
                        '        <tr>',
                        '        </tr>',
                        '        <tr>',
                        '            <td></td>',
                        '            <td>',
                        '                <a href="javascript:;" class="operate-edit" node-type="app-edit" data-appid="' + item.appid + '">编辑信息</a>',
                        '            </td>',
                        '            <td></td>',
                        '            <td></td>',
                        '            <td></td>',
                        '        </tr>',
                        '    </table>',
                        '</div>'
                    ];
                    appItemArr.push(tmpl.join(''));
                }

                $('[node-type="app-list"]').html(appItemArr.join(''));
            } else {
                $('[node-type="app-list"]').html('该研发商尚未添加App');
            }

            // 上一页
            $('[node-type="applist-prev-page"]').toggle(currentPage > 0);
            // 下一页
            $('[node-type="applist-next-page"]').toggle(!!has_more);
        },
        updateDevAppFormModalView: function (method, data) {
            $devAppFormModal = $('#devAppFormModal');
            $devAppFormModal.find('[node-type="dev-id"]').val(data.did ? data.did : '');
            $devAppFormModal.find('[node-type="app-id"]').val(data.appid ? data.appid : '');
            $devAppFormModal.find('[node-type="dev-appname"]').val(data.appname ? data.appname : '');
            $devAppFormModal.find('[node-type="dev-applevel"]').val(data.level ? data.level : '0');
            $devAppFormModal.find('[node-type="dev-applogo"]').val(data.applogo ? data.applogo : '');
            $devAppFormModal.find('[node-type="dev-appdesc"]').val(data.desc ? data.desc : '');
            $devAppFormModal.find('[node-type="dev-appversion"]').val(data.version ? data.version : '');
            $devAppFormModal.find('[node-type="dev-appsize"]').val(data.size ? data.size : '');
            $devAppFormModal.find('[node-type="dev-applanguage"]').val(data.language ? data.language : '');
            $devAppFormModal.find('[node-type="dev-appsystem"]').val(data.system ? data.system : '');
            $devAppFormModal.find('[node-type="dev-appdlink"]').val(data.dlink ? data.dlink : '');
            $devAppFormModal.find('[node-type="dev-appbackgroud"]').val(data.backgroud ? data.backgroud : '');
            $devAppFormModal.find('[node-type="dev-appspread"]').val(data.spread ? data.spread : '');
            $devAppFormModal.find('[node-type="dev-apprate"]').val(data.rate ? data.rate : '');
            $devAppFormModal.find('[node-type="dev-appftrade"]').val(data.ftrade ? data.ftrade : '');
            $devAppFormModal.find('[node-type="dev-appproportion"]').val(data.proportion ? data.proportion : '');

            if (data.status !== undefined) {
                $devAppFormModal.find("input[name='dev-appstatus']").eq(data.status).attr('checked', 'true');
            } else {
                $devAppFormModal.find("input[name='dev-appstatus']").eq(0).attr('checked', 'true');
            }
            if (data.rltimeret !== undefined) {
                $devAppFormModal.find("input[name='dev-apprltimeret']").eq(data.rltimeret).attr('checked', 'true');
            } else {
                $devAppFormModal.find("input[name='dev-apprltimeret']").eq(0).attr('checked', 'true');
            }
            if (data.pic_type !== undefined) {
                $devAppFormModal.find("input[name='dev-apppictype']").eq(data.pic_type).attr('checked', 'true');
            } else {
                $devAppFormModal.find("input[name='dev-apppictype']").eq(0).attr('checked', 'true');
            }

            if (method === 'add') {
                $devAppFormModal.find('[node-type="dev-app-form-modal-title"]').text('添加');
            } else {
                $devAppFormModal.find('[node-type="dev-app-form-modal-title"]').text('修改');
            }
        },
        updateAgentList: function (list, currentPage, has_more) {
            if (list && list.length) {
                var agentItemArr = [];
                for (var i = 0; i < list.length; i++) {
                    var item = list[i];
                    var tmpl = [
                        '<div class="app-list-item">',
                        '    <table class="table agent-infos">',
                        '        <tr>',
                        '            <td class="text-left">代理商名称：</td>',
                        '            <td class="text-left" node-type="agent-list-username">' + (item.username ? item.username : '') + '</td>',
                        '            <td class="text-left">代理商手机号：</td>',
                        '            <td class="text-left" node-type="agent-list-phone">' + (item.phone ? item.phone : '') + '</td>',
                        '            <td class="text-left">代理商总收入：</td>',
                        '            <td class="text-left" node-type="agent-list-tincome">' + (item.tincome !== undefined ? (item.tincome)/100 : 0)+'元'+ '</td>',
                        '        </tr>',
                        '        <tr>',
                        '            <td class="text-left">总提成次数：</td>',
                        '            <td class="text-left" node-type="agent-list-tcount">' + (item.tcount !== undefined ? item.tcount : 0) + '</td>',
                        '            <td class="text-left">总提现：</td>',
                        '            <td class="text-left" node-type="agent-list-ttake">' + (item.ttake !== undefined ? (item.ttake/100) : 0) +'元'+ '</td>',
                        '            <td class="text-left">总提现次数：</td>',
                        '            <td class="text-left" node-type="agent-list-tocount">' + (item.tocount !== undefined ? item.tocount : 0) + '</td>',
                        '        </tr>',
                        '        <tr>',
                        '            <td class="text-left">代理商等级：</td>',
                        '            <td class="text-left" node-type="agent-list-level">' + (item.level ? item.level : '') + '</td>',
                        '            <td class="text-left">银行名称：</td>',
                        '            <td class="text-left" node-type="agent-list-bankname">' + (item.bankname ? item.bankname : '') + '</td>',
                        '            <td class="text-left">银行卡号：</td>',
                        '            <td class="text-left" node-type="agent-list-cardno">' + (item.cardno ? item.cardno : '') + '</td>',
                        '        </tr>',
                        '        <tr>',
                        '            <td><a href="javascript:;" class="operate-edit" node-type="agent-delete" data-aid="' + item.aid + '">删除代理商</a></td>',
                        '            <td></td>',
                        '            <td></td>',
                        '            <td></td>',
                        '            <td></td>',
                        '            <td></td>',
                        '        </tr>',
                        '    </table>',
                        '</div>'
                    ];
                    agentItemArr.push(tmpl.join(''));
                }

                // 上一页
                $('[node-type="prev-page"]').toggle(currentPage > 0);
                // 下一页
                $('[node-type="next-page"]').toggle(!!has_more);

                $('[node-type="agent-list-content"]').html(agentItemArr.join(''));
            } else {
                $('[node-type="agent-list-content"]').html('未有任何代理商信息。');
            }
        },

        updateQuerySystemList: function (list, currentPage, has_more) {
            if (list && list.length) {
                var querySystem = [];
                var start = [
                    '<div class="app-query-system-item">',
                    '    <table class="table query-system-infos">',
                    '        <tr>',
                ];
                querySystem.push(start.join(''));

                for (var i = 0; i < list.length; i++) {
                    var item = list[i];
                    var tmpl = [
                        '            <td><a href="' + item.url + '" class="query-list" >' + item.desc + '</a></td>',
                    ];
                    querySystem.push(tmpl.join(''));
                    if( i>0 && ((i%3) == 0) ){
                        var append = [
                            '        </tr>',
                            '        <tr>',
                        ];
                        querySystem.push(append.join(''));
                    }
                }

                var end = [
                    '        </tr>',
                    '    </table>',
                    '</div>'
                ];
                querySystem.push(end.join(''));

                // 上一页
                $('[node-type="prev-page"]').toggle(currentPage > 0);
                // 下一页
                $('[node-type="next-page"]').toggle(!!has_more);

                $('[node-type="query-system-get-list"]').html(querySystem.join(''));
            } else {
                $('[node-type="query-system-get-list"]').html('查询平台暂无信息。');
            }
        },

        // 收起，展示左侧列表
        showMenu: function (flag) {
            if (flag) {
                $('#appItems').animate({
                    left: '0rem'
                });
                $('#logo').animate({
                    left: '0rem'
                });
            } else {
                $('#appItems').animate({
                    left: '-15rem'
                });
                $('#logo').animate({
                    left: '-15rem'
                });
            }
        }
    }

    window.adminRender = adminRender;

})($);
