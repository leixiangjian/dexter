(function ($) {

    var pri;
    var pub;

    pri = {
        conf: {
            api: {
                register: '/cornu/agent/register',
                tokenSend: '/cornu/token/send'
            },
            getting: false
        },

        eventHandle: function () {
            $('#getVcode').on('click', function () {
                var phone = $.trim($('#phone').val());
                if (!phone) {
                    $('#phone').parent('.form-group').addClass('has-error').
                    find('.control-label').text('请先输入手机号！');
                    return;
                }
                if ($(this).hasClass('disable')) {
                    return;
                }
                $(this).addClass('disable');
                pri.method.countdown(60);
                pri.method.getVcode(phone);
            });
            $('#submitButton').on('click', function (e) {
                e.preventDefault();
                var phone = $.trim($('#phone').val());
                var vcode = $.trim($('#vcode').val());
                var passwd = $.trim($('#passwd').val());
                var from = $.trim($('#register_from').val());
                var passwdConfrim = $.trim($('#passwd-confirm').val());
                if (!phone) {
                    $('#phone').parent('.form-group').addClass('has-error').
                    find('.control-label').text('请输入正确的手机号！');
                    return;
                }
                if (!vcode) {
                    $('#vcode').parent('.form-group').addClass('has-error').
                    find('.control-label').text('请输入手机验证码！');
                    return;
                }
                if (!passwd) {
                    $('#passwd').parent('.form-group').addClass('has-error').
                    find('.control-label').text('请输入密码！');
                    return;
                }
                if (passwd != passwdConfrim) {
                    $('#passwd-confrim').parent('.form-group').addClass('has-error').
                    find('.control-label').text('两次输入密码不一致！');
                    return;
                }
                // passwd = window.cornu.MD5(passwd);
                pri.method.register({
                    phone: phone,
                    vcode: vcode,
                    passwd: passwd,
                    from: from,
                });
            });
        },

        method: {
            init: function () {
                pri.eventHandle();
            },

            countdown: function (c) {
                if (!c) {
                    $('#getVcode').removeClass('disable').text('获取验证码');
                    return;
                }
                c--;
                $('#getVcode').text(c + 's后可重新获取');
                setTimeout(function () {
                    pri.method.countdown(c);
                }, 1000);
            },
            getVcode: function (phone) {
                $.ajax({
                    url: pri.conf.api.tokenSend,
                    data: {
                        phone: phone
                    }
                }).then(function (res) {
                    if (res && res.errno == 0) {
                        window.cornu.tip.show({
                            type: 'success',
                            msg: '请查收短信验证码'
                        });
                    } else if (res && res.errno) {
                        window.cornu.tip.show({
                            type: 'warn',
                            msg: (window.cornu.errorMsg[res.errno] || '操作异常')
                        });
                    } else {
                        window.cornu.tip.show({
                            type: 'warn',
                            msg: '操作异常'
                        });
                    }
                }, function () {
                    window.cornu.tip.show({
                        type: 'failure',
                        msg: '网络异常'
                    });
                });
            },
            register: function (data) {
                $.ajax({
                    url: pri.conf.api.register,
                    data: data
                }).then(function (res) {
                    if (res && res.errno == 0) {
                        location.href = location.protocol + '//' + location.host + '/cornu/login';
                    } else if (res && res.errno) {
                        alert(window.cornu.errorMsg[res.errno]);
                    } else {
                        alert('操作异常');
                    }
                }, function () {
                    window.cornu.tip.show({
                        type: 'failure',
                        msg: '网络异常'
                    });
                });
            }

        }
    };

    pub = {

    };

    pri.method.init();

})($);
