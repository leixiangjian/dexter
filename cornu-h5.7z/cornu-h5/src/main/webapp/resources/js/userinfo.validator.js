(function ($) {
    userinfoValidator = {
        passwdChangeValidator: function () {
            var phone = $.trim($('#phone-pwchange').val());
            var vcode = $.trim($('#vcode-pwchange').val());
            var oldpasswd = $.trim($('[node-type="oldpasswd"]').val());
            var passwd = $.trim($('[node-type="passwd"]').val());
            var passwdconfirm = $.trim($('[node-type="passwd-confirm"]').val());
            if (!phone) {
                $('#phone-pwchange').parent('.form-group').addClass('has-error').
                find('.control-label').text('请输入正确的手机号！');
                return;
            }
            if (!vcode) {
                $('#vcode-pwchange').parents('.form-group').addClass('has-error').
                find('.control-label').text('请输入手机验证码！');
                return;
            }
            if (!oldpasswd) {
                $('[node-type="oldpasswd"]').parent('.form-group').addClass('has-error').
                find('.control-label').text('请输入旧密码！');
                return;
            }
            if (!passwd) {
                $('[node-type="passwd"]').parent('.form-group').addClass('has-error').
                find('.control-label').text('请输入新密码！');
                return;
            }
            if (!passwdconfirm) {
                $('[node-type="passwd-confirm"]').parent('.form-group').addClass('has-error').
                find('.control-label').text('请确认新密码！');
                return;
            }
            if (passwdconfirm !== passwd) {
                $('[node-type="passwd-confirm"]').parent('.form-group').addClass('has-error').
                find('.control-label').text('两次输入密码不一致！');
                return;
            }

            return {
                phone: phone,
                vcode: vcode,
                oldpasswd: oldpasswd,
                passwd: passwd
            }
        },
        addIncomeValidator: function (currentincome) {
            var phone = $.trim($('#phone-add-income').val());
            var vcode = $.trim($('#vcode-add-income').val());
            var addincome = $.trim($('[node-type="add-income"]').val());
            if (!phone) {
                $('#phone-add-income').parent('.form-group').addClass('has-error').
                find('.control-label').text('请输入正确的手机号！');
                return;
            }
            if (!vcode) {
                $('#vcode-add-income').parents('.form-group').addClass('has-error').
                find('.control-label').text('请输入手机验证码！');
                return;
            }
            if (!addincome) {
                $('[node-type="add-income"]').parent('.form-group').addClass('has-error').
                find('.control-label').text('请输入您要体现的金额！');
                return;
            }

            if (isNaN(addincome)) {
                $('[node-type="add-income"]').parent('.form-group').addClass('has-error').
                find('.control-label').text('只允许输入数字！');
                return;
            }

            if (addincome < 100) {
                $('[node-type="add-income"]').parent('.form-group').addClass('has-error').
                find('.control-label').text('输入额度过小！');
                return;
            }

            if (addincome > currentincome) {
                $('[node-type="add-income"]').parent('.form-group').addClass('has-error').
                find('.control-label').text('输入额度大于可提现额度！');
                return;
            }

            return {
                phone: phone,
                vcode: vcode,
                amount: addincome
            }
        },
        bankcardValidator: function () {
            var phone = $.trim($('#phone-change-card').val());
            var vcode = $.trim($('#vcode-change-card').val());
            var bankname = $.trim($('[node-type="bankname"]').val());
            var cardno = $.trim($('[node-type="cardno"]').val());
            var username = $.trim($('[node-type="username"]').val());

            if (!phone) {
                $('#phone-change-card').parent('.form-group').addClass('has-error').
                find('.control-label').text('请输入正确的手机号！');
                return;
            }
            if (!vcode) {
                $('#vcode-change-card').parents('.form-group').addClass('has-error').
                find('.control-label').text('请输入手机验证码！');
                return;
            }
            if (!/^[A-Za-z0-9_()（）\-\u4e00-\u9fa5]+$/.test(bankname)) {
                $('[node-type="bankname"]').parent('.form-group').addClass('has-error').
                find('.control-label').text('请输入正确的开户行名称！');
                return;
            }

            if (!/^[1-9]\d*$/.test(cardno)) {
                $('[node-type="cardno"]').parent('.form-group').addClass('has-error').
                find('.control-label').text('请输入正确的银行卡号！');
                return;
            }

            if (!/^[A-Za-z0-9\u4e00-\u9fa5]+$/.test(username)) {
                $('[node-type="username"]').parent('.form-group').addClass('has-error').
                find('.control-label').text('请输入正确的个人姓名！');
                return;
            }

            return {
                phone: phone,
                vcode: vcode,
                bankname: bankname,
                cardno: cardno,
                username: username
            };
        }
    };

    window.userinfoValidator = userinfoValidator;
})($);
