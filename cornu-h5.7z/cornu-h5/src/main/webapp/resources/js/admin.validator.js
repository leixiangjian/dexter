(function ($) {

    var adminValidator = {
        devFormValidator: function (method) {
            $devFormModal = $('#devFormModal');
            var did = $.trim($devFormModal.find('[node-type="dev-id"]').val());
            var uname = $.trim($devFormModal.find('[node-type="dev-uname"]').val());
            var phone = $.trim($devFormModal.find('[node-type="dev-phone"]').val());
            var desc = $.trim($devFormModal.find('[node-type="dev-desc"]').val());
            if (method === 'register' && !/^[A-Za-z0-9_\-\u4e00-\u9fa5]+$/.test(uname)) {
                $devFormModal.find('[node-type="dev-uname"]')
                    .parent('.form-group').addClass('has-error')
                    .find('.control-label').text('请输入研发商名称！');
                return false;
            }
            if (!/^([+-]?)\d*\.?\d+$/.test(phone)) {
                $devFormModal.find('[node-type="dev-phone"]')
                    .parent('.form-group').addClass('has-error')
                    .find('.control-label').text('请输入合法的手机号！');
                return false;
            }
            if (!desc) {
                $devFormModal.find('[node-type="dev-desc"]')
                    .parent('.form-group').addClass('has-error')
                    .find('.control-label').text('请输入研发商描述！');
                return false;
            }
            return {
                did: did,
                uname: uname,
                phone: phone,
                desc: desc
            };
        },
        devAppFormValidator: function () {
            $devAppFormModal = $('#devAppFormModal');
            var did = $.trim($devAppFormModal.find('[node-type="dev-id"]').val());
            var appid = $.trim($devAppFormModal.find('[node-type="app-id"]').val());
            var appname = $.trim($devAppFormModal.find('[node-type="dev-appname"]').val());
            var applogo = $.trim($devAppFormModal.find('[node-type="dev-applogo"]').val());
            var desc = $.trim($devAppFormModal.find('[node-type="dev-appdesc"]').val());
            var level = $.trim($devAppFormModal.find('[node-type="dev-applevel"]').val());
            var version = $.trim($devAppFormModal.find('[node-type="dev-appversion"]').val());
            var size = $.trim($devAppFormModal.find('[node-type="dev-appsize"]').val());
            var language = $.trim($devAppFormModal.find('[node-type="dev-applanguage"]').val());
            var system = $.trim($devAppFormModal.find('[node-type="dev-appsystem"]').val());
            var dlink = $.trim($devAppFormModal.find('[node-type="dev-appdlink"]').val());
            var backgroud = $.trim($devAppFormModal.find('[node-type="dev-appbackgroud"]').val());
            var spread = $.trim($devAppFormModal.find('[node-type="dev-appspread"]').val());
            var rate = $.trim($devAppFormModal.find('[node-type="dev-apprate"]').val());
            var ftrade = $.trim($devAppFormModal.find('[node-type="dev-appftrade"]').val());
            var proportion = $.trim($devAppFormModal.find('[node-type="dev-appproportion"]').val());
            var status = $.trim($devAppFormModal.find('input[name="dev-appstatus"]:checked').val());
            var rltimeret = $.trim($devAppFormModal.find('input[name="dev-apprltimeret"]:checked').val());
            var pictype = $.trim($devAppFormModal.find('input[name="dev-apppictype"]:checked').val());
            if (!pictype) {
                $devAppFormModal.find('[node-type="dev-apppictype"]')
                    .parent('.form-group').addClass('has-error');
                return false;
            }
            if (!appname) {
                $devAppFormModal.find('[node-type="dev-appname"]')
                    .parent('.form-group').addClass('has-error')
                    .find('.control-label').text('请输入App名称！');
                return false;
            }
            if (level == '') {
                $devAppFormModal.find('[node-type="dev-applevel"]')
                    .parent('.form-group').addClass('has-error')
                    .find('.control-label').text('请输入App等级！');
                return false;
            }
            if (!size) {
                $devAppFormModal.find('[node-type="dev-appsize"]')
                    .parent('.form-group').addClass('has-error')
                    .find('.control-label').text('请输入App软件大小！');
                return false;
            }
            if (!language) {
                $devAppFormModal.find('[node-type="dev-applanguage"]')
                    .parent('.form-group').addClass('has-error')
                    .find('.control-label').text('请输入App应用语言！');
                return false;
            }
            if (!system) {
                $devAppFormModal.find('[node-type="dev-appsystem"]')
                    .parent('.form-group').addClass('has-error')
                    .find('.control-label').text('请输入App支持系统！');
                return false;
            }
            if (version == '') {
                $devAppFormModal.find('[node-type="dev-appversion"]')
                    .parent('.form-group').addClass('has-error')
                    .find('.control-label').text('请输入App版本号！');
                return false;
            }
            if (!rate) {
                $devAppFormModal.find('[node-type="dev-apprate"]')
                    .parent('.form-group').addClass('has-error');
                return false;
            }
            if (!ftrade) {
                $devAppFormModal.find('[node-type="dev-appftrade"]')
                    .parent('.form-group').addClass('has-error');
                return false;
            }
            if (!proportion) {
                $devAppFormModal.find('[node-type="dev-appproportion"]')
                    .parent('.form-group').addClass('has-error');
                return false;
            }
            if (!rltimeret) {
                $devAppFormModal.find('[node-type="dev-apprltimeret"]')
                    .parent('.form-group').addClass('has-error');
                return false;
            }
            if (!applogo) {
                $devAppFormModal.find('[node-type="dev-applogo"]')
                    .parent('.form-group').addClass('has-error')
                    .find('.control-label').text('请输入App Logo链接！');
                return false;
            }
            if (!desc) {
                $devAppFormModal.find('[node-type="dev-appdesc"]')
                    .parent('.form-group').addClass('has-error')
                    .find('.control-label').text('请输入App详情！');
                return false;
            }
            if (!dlink) {
                $devAppFormModal.find('[node-type="dev-appdlink"]')
                    .parent('.form-group').addClass('has-error')
                    .find('.control-label').text('请输入推广链接！');
                return false;
            }
            return {
                did: did,
                appid: appid,
                appname: appname,
                applogo: applogo,
                desc: desc,
                level: level,
                version: version,
                size: size,
                language: language,
                system: system,
                dlink: dlink,
                rate: rate,
                ftrade: ftrade,
                proportion: proportion,
                status: status,
                rltimeret: rltimeret,
                pic_type: pictype,
                spread: spread,
                backgroud: backgroud,
                apptime: new Date().getTime() / 1000
            }
        },
        refuseFormValidator: function () {
            $refuseFormModal = $('#refuseFormModal');
            var extra = $.trim($refuseFormModal.find('[node-type="refuse-extra"]').val());
            if (!extra) {
                $refuseFormModal.find('[node-type="refuse-extra"]')
                    .parent('.form-group').addClass('has-error')
                    .find('.control-label').text('请输入拒绝理由！');
                return false;
            }
            return {
                extra: extra
            };
        },
        giveFormValidator: function () {
            $giveMoneyFormModal = $('#giveMoneyFormModal');
            var amount = $.trim($giveMoneyFormModal.find('[node-type="app-money"]').val());
            if (!amount) {
                $refuseFormModal.find('[node-type="app-money"]')
                    .parent('.form-group').addClass('has-error')
                    .find('.control-label').text('请输入收款数额，单位元！');
                return false;
            }
            return {
                amount: amount
            };
        }
    };

    window.adminValidator = adminValidator;
})($);
