(function ($) {

    var pri;
    var pub;
    pri = {
        conf: {
            api: {
                applist: '/cornu/app/list', //获取app列表
                rebateadd: '/cornu/rebate/add', // 添加代理列表
                rebatelist: '/cornu/rebate/list', // 获取代理列表
                appget: '/cornu/app/get', // 获取app详情
                rebateget: '/cornu/rebate/get', // 代理app详情
                transictionlist: '/cornu/transaction/list', // 代理商收入列表
                logout: '/cornu/agent/logout'  // 登出
            },
            startTime: 0,
            endTime: 0,
            currentAPPid: null,
            currentRid: null,
            appstore: {
                page: 1
            },
            transaction: {
                page: 1
            }
        },

        /* 事件绑定 */
        eventHandle: function () {
            $('#navBtn').find('button').on('click', function () {
                var i = $(this).index();
                $(this).siblings('button').removeClass('active');
                $(this).addClass('active');
            });
            var endTime = pri.conf.endTime = new Date();
            var endTimeString = endTime.getFullYear() + '-' + (endTime.getMonth() + 1) + '-' + endTime.getDate();
            $('#enddatetimepicker').val(endTimeString)
                .datetimepicker({
                    minView: 'month',
                    format: 'yyyy-mm-dd',
                    autoclose: true,
                    language: 'zh-CN',
                    todayBtn: true
                }).on('changeDate', function (ev) {
                pri.conf.endTime = ev.date;
            });

            var startTime = pri.conf.startTime = new Date(endTime.getTime() - 7 * 24 * 60 * 60 * 1000);
            var startTimeString = startTime.getFullYear() + '-' + (startTime.getMonth() + 1) + '-' + startTime.getDate();
            $('#startdatetimepicker').val(startTimeString)
                .datetimepicker({
                    minView: 'month',
                    format: 'yyyy-mm-dd',
                    autoclose: true,
                    language: 'zh-CN',
                    todayBtn: true
                }).on('changeDate', function (ev) {
                pri.conf.startTime = ev.date;
            });


            // App大厅按钮
            $('#appStoreButton').on('click', function () {
                pri.currentAPPid = null;
                pri.appStoreInit();
            });
            // app大厅头部按钮
            $('[node-type="header-app-store-button"]').on('click', function () {
                if (pri.currentAPPid && pri.currentRid) {
                    pri.appInit(pri.currentAPPid, pri.currentRid);
                } else {
                    pri.appStoreInit();
                }
            });
            // app大厅上一页
            $('[node-type="appstore-prev-page"]').on('click', function () {
                if (pri.conf.appstore.page > 1) {
                    pri.conf.appstore.page--;
                    pri.getData.appList();
                }
            });

            // app大厅下一页
            $('[node-type="appstore-next-page"]').on('click', function () {
                pri.conf.appstore.page++;
                pri.getData.appList();
            });

            // App列表
            $('#appStoreList').delegate('[node-type="rebateApproveButton"]', 'click', function (event) {
                var appid = $(this).data('app-id');
                var app = window._.findWhere(pri.appList, { appid: appid });
                var $rebateApproveModal = $('#rebateApproveModal');
                window.appRender.rebateApproveModalRender(app);
                $rebateApproveModal.modal('show');
            }).delegate('[node-type="hasRebatedButton"]', 'click', function (event) {
                var appid = $(this).data('app-id');
                var rid = $(this).data('rebate-id');
                pri.currentAPPid = appid;
                pri.currentRid = rid;
                var app = window._.findWhere(pri.rebateAppList, { appid: appid });
                pri.appInit(appid, app.rid);
            });

            // 代理申请弹框表单提交
            $('[node-type="rebateApproveSubmit"]').click(function () {
                var $rebateApproveModal = $('#rebateApproveModal');
                var appid = $.trim($rebateApproveModal.find('[node-type="appid"]').val());
                pri.method.rebateApproveSubmit({
                    appid: appid
                });
            });
            // 单个App按钮
            $('#rebateAppList').delegate('[node-type="rebate-app-button"]', 'click', function () {
                var appid = $(this).data('app-id');
                var rid = $(this).data('rid');
                pri.currentAPPid = appid;
                pri.currentRid = rid;
                $(this).siblings().removeClass('active')
                $(this).addClass('active');
                pri.appInit(appid, rid);
            });
            // 查看明细
            $('#detailButton').on('click', function () {
                var appid = $(this).data('app-id');
                pri.conf.rebateAppId = appid;
                pri.getData.transactionList();
            });
            $('[node-type="header-detail-button"]').on('click', function () {
                var appid = $(this).data('app-id');
                pri.conf.rebateAppId = appid;
                pri.getData.transactionList();
            });
            // 登出
            $('#logout').on('click', function () {
                pri.method.logout();
            });
            $('[node-type="menu-toggle"]').on('click', function () {
                window.appRender.showMenu(true);
                $('#mainContent').on('click', function () {
                    window.appRender.showMenu(false);
                });
                $('#appItems').on('click', function () {
                    window.appRender.showMenu(false);
                });
            });

            // 收益详情查询
            $('[node-type="query-transaction-data"]').on('click', function () {
                pri.conf.transaction.page = 1;
                pri.getData.transactionList();
            });

            // 收益详情上一页
            $('[node-type="transaction-prev-page"]').on('click', function () {
                if (pri.conf.transaction.page > 1) {
                    pri.conf.transaction.page--;
                    pri.getData.transactionList();
                }
            });

            // 收益详情下一页
            $('[node-type="transaction-next-page"]').on('click', function () {
                pri.conf.transaction.page++;
                pri.getData.transactionList();
            });

        },


        /* 初始化及视图更新 */
        appStoreInit: function () {
            pri.getData.appList();
        },
        updateAppStoreView: function (res) {
            res.list.length && window.appRender.appListRender(res.list);
            // 下一页
            $('[node-type="appstore-next-page"]').toggle(!!res.has_more);
            // 上一页
            $('[node-type="appstore-prev-page"]').toggle(pri.conf.appstore.page > 1);

            // $('#mainTitle').hide();
            $('#navBtn').hide();
            $('#mainInfos').hide();
            $('#mainDetails').hide();
            $('#appStoreList').show();
            // $('[node-type="header-detail-button"]').hide();
        },
        appInit: function (appid, rid) {
            pri.method.sendAjax({
                url: pri.conf.api.rebateget,
                data: {
                    appid: appid,
                    rid: rid
                },
                success: function (res) {
                    if (res.list && res.list[0]) {
                        pri.updateAppView(res.list[0]);
                    } else {
                        window.cornu.tip.show({
                            type: 'warn',
                            msg: '没有数据'
                        });
                    }
                }
            });
        },
        updateAppView: function (data) {
            window.appRender.appDetailRender(data);
            $('#appStoreList').hide();
            // $('#mainTitle').text('App详情页').show();
            $('#mainInfos').show();
            $('#mainDetails').hide();
            $('[node-type="header-detail-button"]').data('app-id', data.appid).removeClass('active').show();

            // 观看码复制
            pri.method.bindClipboard({
                copyBtn: $('[node-type="copy-app-vcode"]')[0],
                valueText: $('[node-type="app-vcode"]')
            });

            // 推广方式复制
            pri.method.bindClipboard({
                copyBtn: $('[node-type="copy-app-desc"]')[0],
                valueText: $('[node-type="app-desc"]')
            });
        },
        updateDetailView: function (res) {
            window.appRender.transactionDetailRender(res.list);
            // 收入详情下一页
            $('[node-type="transaction-next-page"]').toggle(!!res.has_more);
            // 收入详情上一页
            $('[node-type="transaction-prev-page"]').toggle(pri.conf.transaction.page > 1);

            $('[node-type="header-detail-button"]').addClass('active');
            $('[node-type="header-app-store-button"]').removeClass('active');
            // $('#mainTitle').text('收入详情页').show();
            $('#mainInfos').hide();
            $('#mainDetails').show();
        },

        /* 获取数据 */
        getData: {
            // 系统app数据
            appList: function () {
                var start = (pri.conf.appstore.page - 1) * 20;
                pri.method.sendAjax({
                    url: pri.conf.api.applist,
                    data: {
                        start: start,
                        limit: 20
                    },
                    success: function (res) {
                        pri.appList = res.list;
                        pri.updateAppStoreView(res);
                    }
                });
            },
            // 代理app数据
            rebateList: function () {
                pri.method.sendAjax({
                    url: pri.conf.api.rebatelist,
                    success: function (res) {
                        pri.rebateAppList = res.list;
                        window.appRender.rebateAppListRender(res.list);
                    }
                });
            },
            // 收入详情
            transactionList: function () {
                var startTime = parseInt(pri.conf.startTime.getTime() / 1000);
                var endTime = parseInt(pri.conf.endTime.getTime() / 1000);
                var start = (pri.conf.transaction.page - 1) * 20;
                var appid = pri.conf.rebateAppId;
                pri.method.sendAjax({
                    url: pri.conf.api.transictionlist,
                    data: {
                        appid: appid,
                        start_time: startTime,
                        end_time: endTime,
                        start: start,
                        limit: 20
                    },
                    success: function (res) {
                        pri.updateDetailView(res);
                    }
                });
            }
        },

        /* 渲染等方法 */
        method: {
            init: function () {
                pri.appStoreInit();
                pri.getData.rebateList();
                var execResize;
                window.appRender.resizeHandle();
                $(window).on('resize', function () {
                    if (execResize) {
                        clearTimeout(execResize);
                    }
                    execResize = setTimeout(window.appRender.resizeHandle, 600);
                });
                pri.eventHandle();
            },
            // 登出
            logout: function () {
                pri.method.sendAjax({
                    url: pri.conf.api.logout,
                    success: function () {
                        location.href = location.protocol + '//' + location.host + '/cornu/login';
                    }
                });
            },
            // 代理申请表单提交
            rebateApproveSubmit: function (data) {
                pri.method.sendAjax({
                    url: pri.conf.api.rebateadd,
                    data: data,
                    success: function () {
                        pri.getData.appList();
                        pri.getData.rebateList();
                    },
                    always: function () {
                        $('#rebateApproveModal').modal('hide');
                    }
                });
            },
            // 绑定复制功能
            bindClipboard: function (options) {
                var copyLinkFn = function () {
                    return options.valueText.val();
                };
                var myClipboard = new MyClipboard(options.copyBtn);
                var clipboardInstance = myClipboard.setText(copyLinkFn());
                if (myClipboard.type === MyClipboard.TYPE_FLASH) {
                    clipboardInstance.setSize(103, 33);
                }
                myClipboard.on('success', function () {
                    window.cornu.tip.show({
                        type: 'success',
                        msg: '复制成功'
                    });
                });
                myClipboard.on('error', function () {
                    valueText.focus().select();
                    window.cornu.tip.show({
                        type: 'warn',
                        msg: '您的浏览器不支持自动复制，请全选后手动进行复制'
                    });
                });
            },
            sendAjax: function (options) {
                $.ajax({
                    url: options.url,
                    data: options.data
                }).then(function (res) {
                    if (res && res.errno == 0) {
                        typeof options.success === 'function' && options.success(res);
                    } else if (res && res.errno) {
                        window.cornu.tip.show({
                            type: 'warn',
                            msg: (window.cornu.errorMsg[res.errno] || '操作异常')
                        });
                    } else {
                        window.cornu.tip.show({
                            type: 'warn',
                            msg: '操作异常'
                        });
                    }
                    typeof options.always === 'function' && options.always(res);
                }, function (res) {
                    window.cornu.tip.show({
                        type: 'failure',
                        msg: '网络异常'
                    });
                    typeof options.error === 'function' && options.error(res);
                    typeof options.always === 'function' && options.always(res);
                });
            }
        }
    };

    pub = {

    };

    pri.method.init();

})($);
