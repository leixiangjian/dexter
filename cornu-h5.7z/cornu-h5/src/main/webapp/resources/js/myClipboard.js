var clipboardAdapter = window.clipboardAdapter;
var util = {};
if (typeof Object.create === 'function') {
    util.inherits = function inherits(ctor, superCtor) {
        ctor.super_ = superCtor;
        ctor.prototype = Object.create(superCtor.prototype, {
            constructor: {
                value: ctor,
                enumerable: false,
                writable: true,
                configurable: true
            }
        });
    };
} else {
    util.inherits = function inherits(ctor, superCtor) {
        ctor.super_ = superCtor;
        var TempCtor = function () {
        };
        TempCtor.prototype = superCtor.prototype;
        ctor.prototype = new TempCtor();
        ctor.prototype.constructor = ctor
    }
}

// 第三方类库实例
var ThirdInstance = null;

/**
 * 剪贴板基类
 * @param {node|string} ele 选择器
 * @constructor
 */
function ClipBase(ele) {
    this.clipboard = null;
    this.element = ClipBase.getElement(ele);
    this.event = {};
    window.EventEmitter.call(this);
}
ClipBase.getElement = function (ele) {
    return $(ele).get(0);
};
util.inherits(ClipBase, window.EventEmitter);

ClipBase.prototype.getClipboardHandler = function () {
    return this;
};
ClipBase.prototype.setText = function (text) {
    this.clipboard.setText(text);
    return this.clipboard;
};

ClipBase.create = function (obj) {
    var F = function (ele) {
        ClipBase.call(this, ele);
    };
    F.prototype = new ClipBase();
    F.prototype.constructor = F;
    for (var n in obj) {
        if (!obj.hasOwnProperty(n)) {
            continue;
        }
        F.prototype[n] = obj[n];
    }
    return F;
};

/**
 * flash 剪贴板
 * @param {node|string} ele 选择器
 * @constructor
 */
var FlashClipboard = ClipBase.create({
    getClipboardHandler: function () {
        if (this.clipboard) {
            return this.clipboard;
        }
        var that = this;
        var element = this.element;
        var flash = new ThirdInstance.Client();
        flash.glue(element, element);
        flash.setHandCursor(true);
        flash.addEventListener('complete', function (text) {
            that.emit('success', text);
        });
        flash.addEventListener('error', function (err) {
            that.emit('error', err);
        });
        this.clipboard = flash;
        return this;
    }
});


/**
 * html5剪贴板
 * @param {node|string} ele 选择器
 * @constructor
 */
var NativeClipboard = ClipBase.create({
    setText: function (text) {
        var that = this;
        this.clipboard = new ThirdInstance(that.element, {
            text: function () {
                return text;
            }
        });
        this.clipboard.on('success', function (e) {
            that.emit('success', e.text);
            e.clearSelection();
        });
        this.clipboard.on('error', function (e) {
            that.emit('error', e);
        });

        return this.clipboard;
    }
});
NativeClipboard.check = function () {
    return !!(window.getSelection && ((document.queryCommandSupported && document.queryCommandSupported('copy'))
    || (document.execCommand && document.execCommand('copy'))));
};

/**
 * ie中的剪贴板
 * @param {node|string} ele 选择器
 * @constructor
 */
var WindowClipboard = ClipBase.create({
    getClipboardHandler: function () {
        this.clipboard = window.clipboardData;
        return this;
    },
    setText: function (text) {
        var that = this;
        if (!!window.attachEvent) {
            that.element.attachEvent('onclick', function () {
                try {
                    that.clipboard.clearData();
                    that.clipboard.setData('Text', text);
                } catch (ex) {
                    that.emit('error', ex);
                    return;
                }
                that.emit('success', text);

            });
        } else {
            that.element.addEventListener('click', function () {
                try {
                    that.clipboard.clearData();
                    that.clipboard.setData('Text', text);
                } catch (ex) {
                    that.emit('error', ex);
                    return;
                }
                that.emit('success', text);

            }, false);
        }
        return this.clipboard;
    }
});
WindowClipboard.check = function () {
    return !!window.clipboardData;
};

/**
 * 剪贴板
 * @param {string|node|nodeList} selector 选择器
 * @constructor
 */
function MyClipboard(selector) {
    if (!selector) {
        return;
    }
    this.type = MyClipboard.initClipboardBean.type;
    this.clipboardIns = MyClipboard.initClipboardBean(selector);
}
MyClipboard.TYPE_HTML5 = 0;
MyClipboard.TYPE_FLASH = 1;
MyClipboard.TYPE_NATIVE = 2;

MyClipboard.prototype = {
    constructor: MyClipboard,
    setText: function (text) {
        return this.clipboardIns.getClipboardHandler().setText(text);
    },
    on: function (event, handler) {
        this.clipboardIns.on(event, handler);
    },
    emit: function () {
        this.clipboardIns.emit.apply(this.clipboardIns, arguments);
    }
};

if (NativeClipboard.check()) {
    ThirdInstance = clipboardAdapter.getHTML5Clipboard();
    MyClipboard.initClipboardBean = function (selector) {
        return new NativeClipboard(selector);
    };
    MyClipboard.initClipboardBean.type = MyClipboard.TYPE_HTML5;
} else if (WindowClipboard.check()) {
    MyClipboard.initClipboardBean = function (selector) {
        return new WindowClipboard(selector);
    };
    MyClipboard.initClipboardBean.type = MyClipboard.TYPE_NATIVE;
} else {
    ThirdInstance = clipboardAdapter.getZeroClipboard();
    MyClipboard.initClipboardBean = function (selector) {
        return new FlashClipboard(selector);
    };
    MyClipboard.initClipboardBean.type = MyClipboard.TYPE_FLASH;
}

window.MyClipboard = MyClipboard;