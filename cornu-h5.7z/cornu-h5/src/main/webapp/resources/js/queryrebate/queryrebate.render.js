(function ($) {
    var queryRebateRender = {
        resizeHandle: function () {
            var w = $(window).width();
            var h = $(window).height();
            // 重置页面高度
            $('.main-h').css({
                'height': h - 60
            });
            $('#mainContent').height(h - 60 - 46);
        },
        // 收入详情列表
        rebateDetailRender: function (list) {
            appTmplArr = [];
            if (list && list.length) {
                for (var i = 0; i < list.length; i++) {
                    var item = list[i];
                    var tmpl = [
                        '<tr>',
                        '    <th scope="row">' + item.appid + '</th>',
                        '    <td>' + item.aid + '</td>',
                        '    <td>' + item.appname + '</td>',
                        '    <td>' + item.tincome + '</td>',
                        '    <td>' + item.vcode + '</td>',
                        '</tr>'
                    ].join('');
                    appTmplArr.push(tmpl);
                }
            } else {
                appTmplArr.push('<tr class="none-list"><td colspan="5">暂无数据</td></tr>');
            }
            $rebateDetails = $('#rebateDetails');
            $rebateDetails.find('[node-type="rebate-detail-list"]').html(appTmplArr.join(''));
        },
    };
    window.queryRebateRender = queryRebateRender;
})($);
