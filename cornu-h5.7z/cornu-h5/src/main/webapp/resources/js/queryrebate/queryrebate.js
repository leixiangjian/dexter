(function ($) {
    var pri;
    pri = {
        conf: {
            api: {
                sysrebateklist: '/cornu/system/rebate/list', // 代理商收入列表
                logout: '/cornu/agent/logout'  // 登出
            },
            rebate: {
                page: 1
            }
        },

        /* 事件绑定 */
        eventHandle: function () {
            // 收益详情查询
            $('[node-type="query-rebate-data"]').on('click', function () {
                pri.conf.rebate.page = 1;
                pri.getData.sysrebateList();
            });

            // 收益详情上一页
            $('[node-type="rebate-prev-page"]').on('click', function () {
                if (pri.conf.rebate.page > 1) {
                    pri.conf.rebate.page--;
                    pri.getData.sysrebateList();
                }
            });

            // 收益详情下一页
            $('[node-type="rebate-next-page"]').on('click', function () {
                pri.conf.rebate.page++;
                pri.getData.sysrebateList();
            });
        },

        updateRebateDetailView: function (res) {
            window.queryRebateRender.rebateDetailRender(res.list);
            // 收入详情下一页
            $('[node-type="rebate-next-page"]').toggle(!!res.has_more);
            // 收入详情上一页
            $('[node-type="rebate-prev-page"]').toggle(pri.conf.rebate.page > 1);
        },

        /* 获取数据 */
        getData: {
            // 收入详情
            sysrebateList: function () {
                var start = (pri.conf.rebate.page - 1) * 20;
                var data = window.SearchValidator.queryRebateFormValidator();
                pri.method.sendAjax({
                    url: pri.conf.api.sysrebateklist,
                    data: {
                        acode: data.acode,
                        start: start,
                        limit: 20
                    },
                    success: function (res) {
                        pri.updateRebateDetailView(res);
                    }
                });
            }
        },

        /* 渲染等方法 */
        method: {
            init: function () {
                pri.eventHandle();
            },
            // 登出
            logout: function () {
                pri.method.sendAjax({
                    url: pri.conf.api.logout,
                    success: function () {
                        location.href = location.protocol + '//' + location.host + '/cornu/login';
                    }
                });
            },

            sendAjax: function (options) {
                $.ajax({
                    url: options.url,
                    data: options.data
                }).then(function (res) {
                    if (res && res.errno == 0) {
                        typeof options.success === 'function' && options.success(res);
                    } else if (res && res.errno) {
                        window.cornu.tip.show({
                            type: 'warn',
                            msg: (window.cornu.errorMsg[res.errno] || '操作异常')
                        });
                    } else {
                        window.cornu.tip.show({
                            type: 'warn',
                            msg: '操作异常'
                        });
                    }
                    typeof options.always === 'function' && options.always(res);
                }, function (res) {
                    window.cornu.tip.show({
                        type: 'failure',
                        msg: '网络异常'
                    });
                    typeof options.error === 'function' && options.error(res);
                    typeof options.always === 'function' && options.always(res);
                });
            }
        }
    };
    pri.method.init();

})($);
