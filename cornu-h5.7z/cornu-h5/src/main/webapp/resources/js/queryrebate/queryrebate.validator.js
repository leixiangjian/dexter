(function ($) {
    var SearchValidator = {
        queryRebateFormValidator: function () {
            $rebateDetails = $('#rebateDetails');
            var acode = $.trim($rebateDetails.find('[node-type="search-agent-acode"]').val());
            return {
                acode: acode,
            };
        },
    };
    window.SearchValidator = SearchValidator;
})($);
