(function ($) {

    var pri;
    var pub;

    pri = {
        conf: {
            loginUrl: '/cornu/agent/login'
        },

        eventHandle: function () {
            $('#phoneNumber').on('focus', function () {
                $(this).parent('.form-group').removeClass('has-error').
                find('.control-label').text('输入手机号');
            });
            $('#passWord').on('focus', function () {
                $(this).parent('.form-group').removeClass('has-error').
                find('.control-label').text('输入密码');
            });
            $('#registerButton').on('click', function () {
		var from = $.trim($('#source_from').val()) 
		var url  = '/cornu/register?fr=login&from=' + from 
                window.open(url);
            });
            $('#submitButton').on('click', function (e) {
                e.preventDefault();
                var pn = $.trim($('#phoneNumber').val());
                var pw = $.trim($('#passWord').val());
                if (!pn) {
                    $('#phoneNumber').parent('.form-group').addClass('has-error').
                    find('.control-label').text('请输入正确的手机号！');
                    return;
                }
                if (!/^.{4,20}$/.test(pw)) {
                    $('#passWord').parent('.form-group').addClass('has-error').
                    find('.control-label').text('请输入正确的密码！');
                    return;
                }
                // pw = window.cornu.MD5(pw);
                pri.method.login(pn, pw);
            });
        },

        method: {
            init: function () {
                pri.eventHandle();
            },

            login: function (pn, pw) {
                $.ajax({
                    url: pri.conf.loginUrl,
                    type: 'POST',
                    data: {
                        phone: pn,
                        passwd: pw
                    },
                    dataType: 'json',
                    success: function (res) {
                        if (res && res.errno == 0) {
                            location.href = location.protocol + '//' + location.host + '/cornu/home';
                        } else if (res && res.errno) {
                            window.cornu.tip.show({
                                type: 'warn',
                                msg: (window.cornu.errorMsg[res.errno] || '操作异常')
                            });
                        } else {
                            window.cornu.tip.show({
                                type: 'warn',
                                msg: '操作异常'
                            });
                        }
                    },
                    error: function () {
                        window.cornu.tip.show({
                            type: 'failure',
                            msg: '网络异常'
                        });
                    }
                });
            },

            countdown: function (c) {
                if (!c) {
                    $('#getVcode').removeClass('disable').text('获取验证码');
                    return;
                }
                c--;
                $('#getVcode').text(c + 's后可重新获取');
                setTimeout(function () {
                    pri.method.countdown(c);
                }, 1000);
            }

        }
    };

    pub = {

    };

    pri.method.init();

})($);
