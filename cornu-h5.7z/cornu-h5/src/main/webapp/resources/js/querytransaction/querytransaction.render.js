(function ($) {
    var searchAgentRender = {
        resizeHandle: function () {
            var w = $(window).width();
            var h = $(window).height();
            // 重置页面高度
            $('.main-h').css({
                'height': h - 60
            });
            $('#mainContent').height(h - 60 - 46);
        },
        // 收入详情列表
        transactionAgentDetailRender: function (list) {
            appTmplArr = [];
            if (list && list.length) {
                for (var i = 0; i < list.length; i++) {
                    var item = list[i];
			if (item.status == 0) {
                            statusText = '已到账';
                        } else if (item.status == 1) {
                            statusText = '借贷中';
                        } else if (item.status == 2) {
                            statusText = '已坏账';
                        } 
                    var tmpl = [
                        '<tr>',
                        '    <th scope="row">' + item.uid + '</th>',
                        '    <td>' + item.uname + '</td>',
                        '    <td>' + (item.recharge/100) + '</td>',
                        '    <td>' + (item.day_for_agent/100)+ '</td>',
                        '    <td>' + window.cornu.parseDate(item.ctime) + '</td>',
                        '    <td>' + window.cornu.parseDate(item.etime) + '</td>',
		            	'    <td>' + statusText + '</td>',
                        '</tr>'
                    ].join('');
                    appTmplArr.push(tmpl);
                }
            } else {
                appTmplArr.push('<tr class="none-list"><td colspan="7">暂无数据</td></tr>');
            }
            $transactionDetails = $('#transactionDetails');
            $transactionDetails.find('[node-type="agent-detail-list"]').html(appTmplArr.join(''));
        },
    };
    window.searchAgentRender = searchAgentRender;
})($);
