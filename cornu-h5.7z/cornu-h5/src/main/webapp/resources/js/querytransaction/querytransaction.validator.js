(function ($) {
    var SearchValidator = {
        agentSearchFormValidator: function () {
            $transactionDetails = $('#transactionDetails');
            var aid = $.trim($transactionDetails.find('[node-type="search-agent-id"]').val());
            var appid = $.trim($transactionDetails.find('[node-type="search-app-id"]').val());
            return {
                aid: aid,
                appid: appid
            };
        },
    };
    window.SearchValidator = SearchValidator;
})($);
