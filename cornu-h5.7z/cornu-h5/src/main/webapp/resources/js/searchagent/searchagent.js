(function ($) {
    var pri;
    pri = {
        conf: {
            api: {
                sysagentlist: '/cornu/system/agent/search', // 代理商收入列表
                logout: '/cornu/agent/logout'  // 登出
            },
            agent: {
                page: 1
            }
        },

        /* 事件绑定 */
        eventHandle: function () {
            // 收益详情查询
            $('[node-type="search-agent-data"]').on('click', function () {
                pri.conf.agent.page = 1;
                pri.getData.searchagentList();
            });

            // 收益详情上一页
            $('[node-type="agent-search-prev-page"]').on('click', function () {
                if (pri.conf.agent.page > 1) {
                    pri.conf.agent.page--;
                    pri.getData.searchagentList();
                }
            });

            // 收益详情下一页
            $('[node-type="agent-search-next-page"]').on('click', function () {
                pri.conf.agent.page++;
                pri.getData.searchagentList();
            });
        },

        updateAgentDetailView: function (res) {
            window.searchAgentRender.agentDetailRender(res.list);
            // 收入详情下一页
            $('[node-type="agent-search-next-page"]').toggle(!!res.has_more);
            // 收入详情上一页
            $('[node-type="agent-search-prev-page"]').toggle(pri.conf.agent.page > 1);
        },

        /* 获取数据 */
        getData: {
            // 收入详情
            searchagentList: function () {
                var start = (pri.conf.agent.page - 1) * 20;
                var data = window.SearchValidator.agentSearchFormValidator();
                pri.method.sendAjax({
                    url: pri.conf.api.sysagentlist,
                    data: {
                        phone: data.phone,
                        start: start,
                        limit: 20
                    },
                    success: function (res) {
                        pri.updateAgentDetailView(res);
                    }
                });
            }
        },

        /* 渲染等方法 */
        method: {
            init: function () {
                pri.eventHandle();
            },
            // 登出
            logout: function () {
                pri.method.sendAjax({
                    url: pri.conf.api.logout,
                    success: function () {
                        location.href = location.protocol + '//' + location.host + '/cornu/login';
                    }
                });
            },

            sendAjax: function (options) {
                $.ajax({
                    url: options.url,
                    data: options.data
                }).then(function (res) {
                    if (res && res.errno == 0) {
                        typeof options.success === 'function' && options.success(res);
                    } else if (res && res.errno) {
                        window.cornu.tip.show({
                            type: 'warn',
                            msg: (window.cornu.errorMsg[res.errno] || '操作异常')
                        });
                    } else {
                        window.cornu.tip.show({
                            type: 'warn',
                            msg: '操作异常'
                        });
                    }
                    typeof options.always === 'function' && options.always(res);
                }, function (res) {
                    window.cornu.tip.show({
                        type: 'failure',
                        msg: '网络异常'
                    });
                    typeof options.error === 'function' && options.error(res);
                    typeof options.always === 'function' && options.always(res);
                });
            }
        }
    };
    pri.method.init();

})($);
