(function ($) {
    var SearchValidator = {
        agentSearchFormValidator: function () {
            $agentDetails = $('#agentDetails');
            var phone = $.trim($agentDetails.find('[node-type="search-agent-phone"]').val());
            return {
                phone: phone,
            };
        },
    };
    window.SearchValidator = SearchValidator;
})($);
