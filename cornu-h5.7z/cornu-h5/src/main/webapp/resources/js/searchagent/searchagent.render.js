(function ($) {
    var searchAgentRender = {
        resizeHandle: function () {
            var w = $(window).width();
            var h = $(window).height();
            // 重置页面高度
            $('.main-h').css({
                'height': h - 60
            });
            $('#mainContent').height(h - 60 - 46);
        },
        // 收入详情列表
        agentDetailRender: function (list) {
            appTmplArr = [];
            if (list && list.length) {
                for (var i = 0; i < list.length; i++) {
                    var item = list[i];
                    var tmpl = [
                        '<tr>',
                        '    <th scope="row">' + item.phone + '</th>',
                        '    <td>' + item.aid + '</td>',
                        '    <td>' + (item.tincome/100) + '</td>',
                        '    <td>' + (item.tocount/100)+ '</td>',
                        '    <td>' + (item.bankname ? item.bankname : '') + '</td>',
                        '    <td>' + (item.cardno ? item.cardno : '') + '</td>',
                        '</tr>'
                    ].join('');
                    appTmplArr.push(tmpl);
                }
            } else {
                appTmplArr.push('<tr class="none-list"><td colspan="6">暂无数据</td></tr>');
            }
            $agentDetails = $('#agentDetails');
            $agentDetails.find('[node-type="search-agent-detail-list"]').html(appTmplArr.join(''));
        },
    };
    window.searchAgentRender = searchAgentRender;
})($);
