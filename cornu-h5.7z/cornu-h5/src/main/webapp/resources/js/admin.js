(function ($) {

    var pri = {
        conf: {
            api: {
                cashSet: '/cornu/system/cash/set', // 提现
                cashList: '/cornu/system/cash/list', // 提现记录
                devList: '/cornu/system/dev/list', // 获取研发商列表
                devGet: '/cornu/dev/get', // 获取研发商详细信息
                devSet: '/cornu/dev/set', // 研发商详细信息
                devRegister: '/cornu/dev/register', // 研发商注册
                devDelete: '/cornu/dev/delete', // 研发商删除
                appList: '/cornu/system/app/list', // 获取app列表
                appSet: '/cornu/system/app/set', // 获取app列表
                agentList: '/cornu/system/agent/list', // 代理商列表
                operList: '/cornu/system/oper/list', // 操作记录列表
                queryList: '/cornu/system/query/list', // 查询功能接口列表
                agentSet: '/cornu/agent/set',   // 代理商编辑
                agentDelete: '/cornu/agent/delete',
                logout: '/cornu/agent/logout' // 登出
            },
            currentPage: 0,
            currentList: null,
            pageLimit: 20,
            currentRender: null,
            currentDid: 0,
            appListCurrentPage: 0,
            appListPageLimit: 10,
            agentListCurrentPage: 0,
            agentListPageLimit: 10
        },
        eventHandle: function () {
            // 左侧nav栏
            $('#functionButton').delegate('button', 'click', function () {
                var nodeType = $(this).attr('node-type');
                $(this).siblings().removeClass('active');
                $(this).addClass('active');
                var mt = $(this).text();
                $('#mainTitle .text').text(mt);
                $('#mainContent .content-tab').hide();
                $('#mainTitle').show();
                pri.conf.currentPage = 0;
                switch (nodeType) {
                    // 重置当前页面
                    case 'get-money-list':
                        // 获取代理商收入列表
                        $('#moneyList').show();
                        $('#devList').hide();
                        $('#appIncomeList').hide();
                        $('#operList').hide();
                        $('#querySystemList').hide();
                        $('#agentList').hide();
                        $('#mainContent .pagenation').show();
                        pri.conf.currentPage = 0;
                        pri.conf.currentRender = pri.getData.getAgentCashList;
                        pri.getData.getAgentCashList();
                        break;
                    case 'dev-app-list':
                        // 获取代理商收入列表
                        $('#moneyList').hide();
                        $('#devList').show();
                        $('#appIncomeList').hide();
                        $('#agentList').hide();
                        $('#querySystemList').hide();
                        $('#operList').hide();
                        $('#mainTitle').hide();
                        $('#mainContent .pagenation').hide();
                        $('#devList .pagenation').show();
                        pri.conf.currentRender = pri.getData.getAppListByDev;
                        pri.getData.getDevList();
                        break;
                    case 'app-income-list':
                        //获取app收入列表
                        $('#moneyList').hide();
                        $('#devList').hide();
                        $('#appIncomeList').show();
                        $('#operList').hide();
                        $('#querySystemList').hide();
                        $('#agentList').hide();
                        $('#mainContent .pagenation').show();
                        pri.conf.currentPage = 0;
                        pri.conf.currentRender = pri.getData.getAppIncomeList;
			            pri.getData.getAppIncomeList();
                        break;
                    case 'oper-list':
                        //获取客户操作记录列表
                        $('#moneyList').hide();
                        $('#devList').hide();
                        $('#appIncomeList').hide();
                        $('#operList').show();
                        $('#querySystemList').hide();
                        $('#agentList').hide();
                        $('#mainContent .pagenation').show();
                        pri.conf.currentPage = 0;
                        pri.conf.currentRender = pri.getData.getOperList;
                        pri.getData.getOperList();
                        break;
                    case 'query-system':
                        //获取客户操作记录列表
                        $('#moneyList').hide();
                        $('#devList').hide();
                        $('#appIncomeList').hide();
                        $('#operList').hide();
                        $('#querySystemList').show();
                        $('#agentList').hide();
                        $('#mainContent .pagenation').show();
                        pri.conf.currentPage = 0;
                        pri.conf.currentRender = pri.getData.getQuerySystemList;
                        pri.getData.getQuerySystemList();
                        break;
                    case 'agent-list':
                        $('#moneyList').hide();
                        $('#devList').hide();
                        $('#appIncomeList').hide();
                        $('#operList').hide();
                        $('#querySystemList').hide();
                        $('#agentList').show();
                        $('#mainContent .pagenation').show();
                        pri.conf.currentPage = 0;
                        pri.conf.currentRender = pri.getData.getAgentList;
                        pri.getData.getAgentList();
                }
            });

            // 代理商详情查看
            var listItem = null;
            var list = null;  // 当前操作列表行
            $('#moneyList').delegate('[node-type="show-agent-detail"]', 'click', function () {
                var list = $(this).closest('tr');
                var index = list.data('index');
                var dataList = pri.conf.currentList;
                var detail = dataList[index];
                window.adminRender.updateAgentInfo(detail);
                // 打钱确认
            }).delegate('[node-type="money-given-button"]', 'click', function () {
                if ($(this).attr('disabled')) {
                    return;
                }
                if (!window.confirm('确认已打款吗？')) {
                    return;
                }
                var self = $(this);
                var list = $(this).closest('tr');
                var aid = list.data('aid');
                var cid = list.data('cid');
                pri.getData.cashSet({
                    aid: aid,
                    cid: cid,
                    status: 2
                }, function () {
                    self.attr('disabled', 'disabled');
                    list.find('td').eq(3).html('已打款');
                });
                // 拒绝打钱
            }).delegate('[node-type="money-given-refuse"]', 'click', function () {
                if ($(this).attr('disabled')) {
                    return;
                }
                var self = $(this);
                list = $(this).closest('tr');
                listItem = self;
                $('#refuseFormModal').modal('show');
            });

            $('#refuseFormModal').delegate('[node-type="refuse-form-submit"]', 'click', function () {
                var data = adminValidator.refuseFormValidator();
                $('#refuseFormModal').modal('hide');
                if (data) {
                    pri.getData.cashSet({
                        aid: list.data('aid'),
                        cid: list.data('cid'),
                        status: 3,
                        extra: data.extra
                    }, function () {
                        list.find('td').eq(4).html(data.extra);
                        listItem.attr('disabled', 'disabled');
                        listItem.siblings().attr('disabled', 'disabled');
                        listItem.closest('tr').find('td').eq(3).html('已拒绝受理');
                    });
                }
            });

            $('#appIncomeList').delegate('[node-type="money-give-cornu"]', 'click', function () {
                var self = $(this);
                list = $(this).closest('tr');
                listItem = self;
                $('#giveMoneyFormModal').modal('show');
            });

            $('#giveMoneyFormModal').delegate('[node-type="money-give-confirm"]', 'click', function () {
                var data = adminValidator.giveFormValidator();
                $('#giveMoneyFormModal').modal('hide');
                if (data) {
                    pri.getData.appSet({
                        appid: list.data('appid'),
                        amount: data.amount
                    }, function () {
                	//$('#giveMoneyFormModal').modal('hide');
                        //var intsum = parseInt(list.data('selfsum'), 10) + parseInt( data.amount, 10);
                        //listItem.closest('tr').find('td').eq(4).html(intsum);
			window.cornu.tip.show({
                            type: 'success',
                            msg: '提交成功'
                        });
			pri.getData.getAppIncomeList();
                    });
                }
            });

            // 代理商详情
            $('#agentDetailApproveModal').delegate('[node-type="agentDetailClose"]', 'click', function () {
                $('#agentDetailApproveModal').modal('hide');
            });

            // 添加研发商
            var devMethod = '';
            $('#devList').delegate('[node-type="dev-add-button"]', 'click', function () {
                devMethod = 'register';
                window.adminRender.updateDevFormModalView(devMethod, {});
                $('#devFormModal').modal('show');
            }).delegate('[node-type="dev-edit-button"]', 'click', function () {
                devMethod = 'set';
                var did = $(this).data('did');
                var devItem = window._.findWhere(pri.conf.devList, { did: did });
                window.adminRender.updateDevFormModalView(devMethod, devItem);
                $('#devFormModal').modal('show');
            }).delegate('[node-type="dev-delete-button"]', 'click', function () {
                var did = $(this).data('did');
                if (window.confirm('确认删除该研发商吗？')) {
                    pri.getData.deleteDev(did);
                }
            }).delegate('[node-type="dev-detail-button"]', 'click', function () {
                var did = $(this).data('did');
                var devItem = window._.findWhere(pri.conf.devList, { did: did });
                window.adminRender.updateDevDetailModalView(devItem);
                $('#devDetailModal').modal('show');
            });
            $('#devDetailModal').delegate('[node-type="devDetailClose"]', 'click', function () {
                $('#devDetailModal').modal('hide');
            });

            // 添加 / 修改研发商
            $('[node-type="dev-form-submit"]').on('click', function () {
                var data = window.adminValidator.devFormValidator(devMethod);
                data && pri.getData.setDev(devMethod, data);
            });

            // 点击研发商列表
            $('[node-type="dev-list"]').delegate('li', 'click', function () {
                var $this = $(this);
                $this.siblings().removeClass('current');
                $this.addClass('current');
                var did = $(this).data('did');
                pri.conf.currentDid = did;
                pri.getData.getAppListByDev(did);
            });

            // 添加app
            var devAppMethod = '';
            $('[node-type="app-add"]').on('click', function () {
                devAppMethod = 'add';
                adminRender.updateDevAppFormModalView(devAppMethod, {
                    did: pri.conf.currentDid
                });
                $('#devAppFormModal').modal('show');
            });

            // 修改app
            $('[node-type="app-list"]').delegate('[node-type="app-edit"]', 'click', function () {
                devAppMethod = 'set'
                var appid = $(this).data('appid');
                var app = _.findWhere(pri.conf.devAppList, { appid: appid });
                app.did = pri.conf.currentDid;
                adminRender.updateDevAppFormModalView(devAppMethod, app);
                $('#devAppFormModal').modal('show');
            });

            $('[node-type="dev-app-form-submit"]').on('click', function () {
                var data = window.adminValidator.devAppFormValidator();
                data && pri.getData.setDevApp(devAppMethod, data);
            });

            $('[node-type="agent-list-content"]').delegate('[node-type="agent-delete"]', 'click', function () {
                if (window.confirm('确认删除此代理商吗？')) {
                    var aid = $(this).data('aid');
                    pri.getData.deleteAgent(aid);
                }
            });

            // 登出
            $('#logout').on('click', function () {
                pri.method.logout();
            });

            // 提现/代理商列表上一页
            $('[node-type="prev-page"]').on('click', function (e) {
                e.preventDefault();
                if (pri.conf.currentPage > 0) {
                    pri.conf.currentPage--;
                    pri.conf.currentRender();
                }
            });
            // 提现/代理商列表下一页
            $('[node-type="next-page"]').on('click', function (e) {
                e.preventDefault();
                pri.conf.currentPage++;
                pri.conf.currentRender();
            });

            // app列表上一页
            $('[node-type="applist-prev-page"]').on('click', function (e) {
                e.preventDefault();
                if (pri.conf.appListCurrentPage > 0) {
                    pri.conf.appListCurrentPage--;
                    pri.conf.currentRender(pri.conf.currentDid);
                }
            });
            // app列表下一页
            $('[node-type="applist-next-page"]').on('click', function (e) {
                e.preventDefault();
                pri.conf.appListCurrentPage++;
                pri.conf.currentRender(pri.conf.currentDid);
            });

            // 左侧栏显示
            $('[node-type="menu-toggle"]').on('click', function () {
                window.adminRender.showMenu(true);
                $('#mainContent').on('click', function () {
                    window.adminRender.showMenu(false);
                });
                $('#appItems').on('click', function () {
                    window.adminRender.showMenu(false);
                });
            });
        },
        getData: {
            // 提现记录list
            getAgentCashList: function () {
                var start = pri.conf.currentPage * pri.conf.pageLimit;
                pri.method.sendAjax({
                    url: pri.conf.api.cashList,
                    data: {
                        start: start,
                        limit: pri.conf.pageLimit
                    },
                    success: function (res) {
                        var list = res && res.list;
                        pri.conf.currentList = list;
                        window.adminRender.updateCashList(list, pri.conf.currentPage, res.has_more);
                    },
                    error: function () {
                        window.adminRender.updateCashList(res);
                    }
                });
            },
            cashSet: function (data, cb) {
                pri.method.sendAjax({
                    url: pri.conf.api.cashSet,
                    data: data,
                    success: function (res) {
                        cb();
                    }
                });
            },
            appSet: function (data, cb) {
                pri.method.sendAjax({
                    url: pri.conf.api.appSet,
                    data: data,
                    success: function (res) {
                        cb();
                    }
                });
            },
            getDevList: function () {
                var start = pri.conf.currentPage * pri.conf.pageLimit;
                pri.method.sendAjax({
                    url: pri.conf.api.devList,
                    data: {
                        start: start,
                        limit: pri.conf.pageLimit
                    },
                    success: function (res) {
                        var list = res.list;
                        window.adminRender.updateDevList(res.list);
                        if (list && list.length) {
                            var firstDid = list[0].did;
                            pri.conf.currentDid = firstDid;
                            pri.getData.getAppListByDev(firstDid);
                        }
                        pri.conf.devList = list;
                    },
                    error: function () {
                        window.adminRender.updateDevList(res);
                    }
                });
            },
            setDev: function (method, data) {
                pri.method.sendAjax({
                    url: '/cornu/dev/' + method,
                    data: data,
                    success: function () {
                        $('#devFormModal').modal('hide');
                        pri.getData.getDevList();
                    }
                })
            },
            deleteDev: function (did) {
                pri.method.sendAjax({
                    url: pri.conf.api.devDelete,
                    data: {
                        did: did
                    },
                    success: function () {
                        pri.getData.getDevList();
                    }
                });
            },
            getAppListByDev: function (did) {
                var start = pri.conf.appListCurrentPage * pri.conf.appListPageLimit;
                pri.method.sendAjax({
                    url: pri.conf.api.appList,
                    data: {
                        did: did,
                        start: start,
                        limit: pri.conf.appListPageLimit
                    },
                    success: function (res) {
                        pri.conf.devAppList = res.list;
                        adminRender.updateDevAppList(res.list, pri.conf.appListCurrentPage, res.has_more);
                    }
                })
            },
            setDevApp: function (method, data) {
                pri.method.sendAjax({
                    url: '/cornu/app/' + method,
                    data: data,
                    success: function () {
                        $('#devAppFormModal').modal('hide');
                        pri.getData.getAppListByDev(data.did);
                    }
                });
            },
            getAgentList: function () {
                var start = pri.conf.currentPage * pri.conf.pageLimit;
                pri.method.sendAjax({
                    url: pri.conf.api.agentList,
                    data: {
                        start: start,
                        limit: pri.conf.pageLimit
                    },
                    success: function (res) {
                        pri.conf.agentList = res.list;
                        adminRender.updateAgentList(res.list, pri.conf.currentPage, res.has_more);
                    }
                })
            },
            getQuerySystemList: function () {
                var start = pri.conf.currentPage * pri.conf.pageLimit;
                pri.method.sendAjax({
                    url: pri.conf.api.queryList,
                    data: {
                        start: start,
                        limit: pri.conf.pageLimit
                    },
                    success: function (res) {
                        pri.conf.querySystemList = res.list;
                        adminRender.updateQuerySystemList(res.list, pri.conf.currentPage, res.has_more);
                    }
                })
            },
            getAppIncomeList: function () {
                var start = pri.conf.currentPage * pri.conf.pageLimit;
                pri.method.sendAjax({
                    url: pri.conf.api.appList,
                    data: {
                        start: start,
                        limit: pri.conf.pageLimit
                    },
                    success: function (res) {
                        var list = res && res.list;
                        pri.conf.currentList = list;
                        adminRender.updateAppIncomeList(res.list, pri.conf.currentPage, res.has_more);
                    }
                })
            },
            getOperList: function () {
                var start = pri.conf.currentPage * pri.conf.pageLimit;
                pri.method.sendAjax({
                    url: pri.conf.api.operList,
                    data: {
                        start: start,
                        limit: pri.conf.pageLimit
                    },
                    success: function (res) {
                        var list = res && res.list;
                        pri.conf.currentList = list;
                        adminRender.updateOperList(res.list, pri.conf.currentPage, res.has_more);
                    }
                })
            },
            deleteAgent: function (aid) {
                pri.method.sendAjax({
                    url: pri.conf.api.agentDelete,
                    data: {
                        aid: aid
                    },
                    success: function () {
                        pri.getData.getAgentList();
                    }
                });
            },
        },
        method: {
            // 登出
            logout: function () {
                pri.method.sendAjax({
                    url: pri.conf.api.logout,
                    success: function () {
                        location.href = location.protocol + '//' + location.host + '/cornu/login';
                    }
                });
            },
            sendAjax: function (options) {
                $.ajax({
                    url: options.url,
                    data: options.data
                }).then(function (res) {
                    if (res && res.errno == 0) {
                        typeof options.success === 'function' && options.success(res);
                    } else if (res && res.errno) {
                        window.cornu.tip.show({
                            type: 'warn',
                            msg: (window.cornu.errorMsg[res.errno] || '操作异常')
                        });
                    } else {
                        window.cornu.tip.show({
                            type: 'warn',
                            msg: '操作异常'
                        });
                    }
                    typeof options.always === 'function' && options.always(res);
                }, function (res) {
                    window.cornu.tip.show({
                        type: 'failure',
                        msg: '网络异常'
                    });
                    typeof options.error === 'function' && options.error(res);
                    typeof options.always === 'function' && options.always(res);
                });
            }
        }
    };

    var pub = {
        init: function () {
            var execResize;
            window.adminRender.resizeHandle();
            $(window).on('resize', function () {
                if (execResize) {
                    clearTimeout(execResize);
                }
                execResize = setTimeout(window.adminRender.resizeHandle, 600);
            });
            pri.eventHandle();
            pri.conf.currentRender = pri.getData.getAgentCashList;
            pri.getData.getAgentCashList();
        }
    };

    pub.init();
})($);
