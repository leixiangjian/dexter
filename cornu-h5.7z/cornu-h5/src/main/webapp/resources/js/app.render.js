(function ($) {
    var appRender = {
        resizeHandle: function () {
            var w = $(window).width();
            var h = $(window).height();
            // 重置页面高度
            $('.main-h').css({
                'height': h - 60
            });
            $('#mainContent').height(h - 60 - 46);
        },
        // 所有app列表渲染
        appListRender: function (list) {
            appTmplArr = [];
            for (var i = 0; i < list.length; i++) {
                var item = list[i];
                var isAgent = '';
                if (item.is_agent == 0) {
                    isAgent = '<button type="button" class="btn btn-primary btn-sm" node-type="rebateApproveButton" data-app-id="' + item.appid + '">申请代理</button>'
                } else if (item.is_agent == 1) {
                    isAgent = '<button type="button" class="btn btn-default btn-sm" node-type="hasRebatedButton" data-app-id="' + item.appid + '" data-rebate-id="' + item.rid + '">已经推广</button>'
                }
                var tmpl = ['<div class="col-md-6 app-sinfo">',
                    '    <div class="logo">',
                    '        <img src="' + item.applogo + '?t=' + Math.random() + '">',
                    '    </div>',
                    '    <div class="name">' + '<span class="name-text">' + item.appname + '</span>',
                    '       ' + isAgent,
                    '    </div>',
                    '    <div class="desc">' + item.desc + '</div>',
                    '    <div class="other">',
                    '        大小：' + item.size + ' 支持系统：' + item.size,
                    '    </div>',
                    '    <div class="border-bottom"></div>',
                    '</div>'
                ].join('');
                appTmplArr.push(tmpl);
            }
            $('[node-type="app-list-container"]').html(appTmplArr.join(''));
        },
        // 申请代理app弹框渲染
        rebateApproveModalRender: function (app) {
            var $modal = $('#rebateApproveModal');
            $modal.find('[node-type="appid"]').val(app.appid);
            $modal.find('[node-type="app-applogo"]').attr('src', app.applogo);
            $modal.find('[node-type="app-version"]').text(app.version);
            $modal.find('[node-type="app-apptime"]').text(window.cornu.parseDate(app.apptime));
            $modal.find('[node-type="app-size"]').text(app.size);
            $modal.find('[node-type="app-system"]').text(app.system);
            $modal.find('[node-type="app-language"]').text(app.language);
            $modal.find('[node-type="app-info-desc"]').text(app.desc);
            $modal.find('[node-type="app-info-rltimeret"]').text(app.rltimeret);
            $modal.find('[node-type="app-ft-rade"]').text(app.ftrade/100);
            $modal.find('[node-type="agent-rate"]').text(app.agent_rate);
            $modal.find('[node-type="app-proportion"]').text(app.proportion);
        },
        // app详情渲染
        appDetailRender: function (data) {
            var appinfo = data.appinfo;
            var $mainInfos = $('#mainInfos');
            $mainInfos.find('[node-type="app-applogo"]').attr('src', appinfo.applogo);
            $mainInfos.find('[node-type="app-version"]').text(appinfo.version);
            $mainInfos.find('[node-type="app-apptime"]').text(window.cornu.parseDate(appinfo.apptime));
            $mainInfos.find('[node-type="app-size"]').text(appinfo.size);
            $mainInfos.find('[node-type="app-system"]').text(appinfo.system);
            $mainInfos.find('[node-type="app-language"]').text(appinfo.language);
            $mainInfos.find('[node-type="app-status"]').text(appinfo.status ? '正常' : '已下架');
            $mainInfos.find('[node-type="app-appname"]').text(appinfo.appname);
            $mainInfos.find('[node-type="app-day_for_agent"]').text(data['day_for_agent']);
            $mainInfos.find('[node-type="app-tincome"]').text(data.tincome);
            $mainInfos.find('[node-type="app-vcode"]').val(data.vcode);
            $mainInfos.find('[node-type="app-info-desc"]').text(appinfo.desc);
            $mainInfos.find('[node-type="app-info-rltimeret"]').text(appinfo.rltimeret);
            $mainInfos.find('[node-type="app-pic"]').attr('src', data.pic_data);
            $mainInfos.find('[node-type="app-desc"]').text(data.desc);
            $mainInfos.find('[node-type="app-rtype"]').text(data.rtype);
            $mainInfos.find('[node-type="detail-button"]').data('app-id', data.appid);
            $('#navBtn').show();
        },
        // 左侧已代理app列表
        rebateAppListRender: function (list) {
            appTmplArr = [];
            for (var i = 0; i < list.length; i++) {
                var item = list[i];
                var tmpl = [
                    '<button type="button" class="list-group-item" node-type="rebate-app-button" data-rid="' + item.rid + '" data-app-id="' + item.appid + '">' + item.appname + '</button>'
                ].join('');
                appTmplArr.push(tmpl);
            }
            $('#rebateAppList').html(appTmplArr.join(''));
        },
        // 收入详情列表
        transactionDetailRender: function (list) {
            appTmplArr = [];
            if (list && list.length) {
                for (var i = 0; i < list.length; i++) {
                    var item = list[i];
			if (item.status == 0) {
                            statusText = '已到账';
                        } else if (item.status == 1) {
                            statusText = '借贷中';
                        } else if (item.status == 2) {
                            statusText = '已坏账';
                        } 
                    var tmpl = [
                        '<tr>',
                        '    <th scope="row">' + item.uid + '</th>',
                        '    <td>' + item.uname + '</td>',
                        '    <td>' + (item.recharge/100) + '</td>',
                        '    <td>' + (item.day_for_agent/100)+ '</td>',
                        '    <td>' + window.cornu.parseDate(item.ctime) + '</td>',
                        '    <td>' + window.cornu.parseDate(item.etime) + '</td>',
		            	'    <td>' + statusText + '</td>',
                        '</tr>'
                    ].join('');
                    appTmplArr.push(tmpl);
                }
            } else {
                appTmplArr.push('<tr class="none-list"><td colspan="7">暂无数据</td></tr>');
            }
            $mainDetails = $('#mainDetails');
            $mainDetails.find('[node-type="detail-list"]').html(appTmplArr.join(''));
        },
        // 收起，展示左侧列表
        showMenu: function (flag) {
            if (flag) {
                $('#appItems').animate({
                    left: '0rem'
                });
                $('#logo').animate({
                    left: '0rem'
                });
            } else {
                $('#appItems').animate({
                    left: '-15rem'
                });
                $('#logo').animate({
                    left: '-15rem'
                });
            }
        }
    };

    window.appRender = appRender;
})($);
