package com.cornu.h5.validators;

import com.alibaba.fastjson.JSONObject;
import com.cornu.h5.contants.ResponseObject;

public interface IValidator {
	abstract ResponseObject validator(JSONObject r_params);
}
