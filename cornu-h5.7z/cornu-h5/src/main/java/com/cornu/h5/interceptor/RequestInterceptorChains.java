package com.cornu.h5.interceptor;

import java.lang.reflect.InvocationTargetException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.method.HandlerMethod;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.cornu.h5.contants.ResponseObject;
import com.cornu.h5.context.WebContext;
import com.cornu.h5.context.WebContextThreadLocal;
import com.cornu.h5.exception.WebException;
import com.cornu.h5.interceptor.chains.InterceptorChain;
import com.cornu.h5.request.Request;
import com.cornu.h5.response.Response;
import com.cornu.h5.validators.IValidator;

public class RequestInterceptorChains extends BaseInterceptor {
	private static final Logger LOG = LoggerFactory.getLogger(RequestInterceptorChains.class);

	private List<InterceptorChain> requestBeforeChains;

	public void setRequestBeforeChains(List<InterceptorChain> requestBeforeChains) {
		this.requestBeforeChains = requestBeforeChains;
	}

	@Override
	public boolean preHandle(HttpServletRequest req, HttpServletResponse res, Object obj) throws Exception {
		Response response = null;
		HandlerMethod method = null;
		try {
			if (obj instanceof HandlerMethod) {
				method = (HandlerMethod) obj;
				if (!isMatch(method)) {
					return true;
				}
				if (super.preHandle(req, res, obj)) {
					response = invoke(method, req);
					writeData(this.buildRes(response, ResponseObject.OK_CODE_1000, "成功"), res);
					return false;
				}
			}
		} catch (WebException e) {
			writeData(this.buildRes(response, e.getErrCode(), e.getErrDesc()), res);
			return false;
		} catch (Exception e) {
			LOG.error(e.getMessage(), e);
			writeData(this.buildRes(null, ResponseObject.ERROR_CODE_1001, "系统错误"), res);
			return false;
		}
		return true;
	}

	private String buildRes(Response response, String resutlCode, String resultMsg) {
		JSONObject json = new JSONObject();
		json.put("res_code", resutlCode);
		json.put("res_msg", resultMsg);
		json.put("res_time", System.currentTimeMillis());

		if (response != null) {
			json.put("res_data", response.getResponseBody());
		}
		return json.toJSONString();
	}

	private Response invoke(HandlerMethod method, HttpServletRequest req) {
		WebContext context = WebContextThreadLocal.get();

		try {
			this.excuteChain(requestBeforeChains, method,req);
			String rMethod = context.getrBody().getString("r_method");
			
			JSONObject r_params = context.getrBody().getJSONObject("r_params");

			Request request = (Request) JSON.parseObject(r_params.toJSONString(),
					method.getMethodParameters()[0].getParameterType());
			
			Class<IValidator> iValidatorClass = request.getValidatorType();
			Response response = new Response();
			if(null != iValidatorClass){
				IValidator iValidator = (IValidator)Class.forName(iValidatorClass.getName()).newInstance();
			
				ResponseObject responseObject = iValidator.validator(r_params);
				if (responseObject.getCode().equals(ResponseObject.OK_CODE_1000)) {
					response.setResponseKey(rMethod);
					response.setResponseBody(responseObject);
					return response;
				}
			}
			
			Request.ValidateRes validateRes = request.validator();
			
			if (validateRes.getRes_code().equals(Request.ValidateRes.ERROR)) {
				response.setResponseKey(rMethod);
				response.setResponseBody(validateRes);
				return response;
			}

			request.setR_method(rMethod);
			Object invokeResult = method.getMethod().invoke(method.getBean(), request);
			response.setResponseKey(rMethod);
			response.setResponseBody(invokeResult);
			return response;
		} catch (IllegalAccessException e) {
			LOG.error("{} 方法访问受限", method.getMethod().getName(), e);
			throw new WebException(e.getMessage(), e, ResponseObject.ERROR_CODE_1002);
		} catch (IllegalArgumentException e) {
			LOG.error("{} 方法参数错误", method.getMethod().getName(), e);
			throw new WebException(e.getMessage(), e, ResponseObject.ERROR_CODE_1001);
		} catch (InvocationTargetException e) {
			if (e.getTargetException() != null && e.getTargetException() instanceof WebException) {
				throw (WebException) e.getTargetException();
			}
			LOG.error(e.getMessage(), e);
			throw new RuntimeException(e.getMessage(), e);
		} catch (InstantiationException e) {
			LOG.error("{} 实例化错误", method.getMethod().getName(), e);
			throw new WebException(e.getMessage(), e, ResponseObject.ERROR_CODE_1001);
		} catch (ClassNotFoundException e) {
			LOG.error("{} 实例化错误", method.getMethod().getName(), e);
			throw new WebException(e.getMessage(), e, ResponseObject.ERROR_CODE_1001);
		}
	}

	private void excuteChain(List<InterceptorChain> chains,HandlerMethod method, Object obj) {
		if (null == chains || chains.size() == 0) {
			return;
		}
		for (InterceptorChain chain : chains) {
			chain.execute(method,obj);
		}
	}

	private boolean isMatch(HandlerMethod method) {
		// 返回类型不为Response的衍生类,直接跳过
		if (!Response.class.isAssignableFrom(method.getReturnType().getParameterType())) {
			if (LOG.isInfoEnabled()) {
				LOG.info("method:{},返回类型不为Response", method.getMethod().getName());
			}
			return false;
		}
		if (method.getMethodParameters() == null || method.getMethodParameters().length == 0) {
			if (LOG.isInfoEnabled()) {
				LOG.info("method:{},入参为空", method.getMethod().getName());
			}
			return false;
		}
		int length = method.getMethodParameters().length;
		if (length > 1) {
			if (LOG.isInfoEnabled()) {
				LOG.info("method:{},入参个数为:{}.", method.getMethod().getName(), length);
			}
			return false;
		}
		// 入参类型不为Request的衍生类,直接跳过
		if (!Request.class.isAssignableFrom(method.getMethodParameters()[0].getParameterType())) {
			if (LOG.isInfoEnabled()) {
				LOG.info("method:{},入参类型不为Request", method.getMethod().getName());
			}
			return false;
		}
		return true;
	}
}
