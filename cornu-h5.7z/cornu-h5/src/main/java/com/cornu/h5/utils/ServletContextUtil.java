package com.cornu.h5.utils;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

public class ServletContextUtil implements ApplicationContextAware {
    
    /** Spring的ApplicationContext对象 */
    private static ApplicationContext context;// 声明一个静态变量保存
    
    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        context = applicationContext;
    }
    
    /**
     * @return ApplicationContext
     */
    public static ApplicationContext getApplicationContext() {
        return context;
    }
    
    /**
     * 这是一个便利的方法，帮助我们快速得到一个BEAN
     * 
     * @param beanId bean的ID
     * @return 返回一个bean对象
     */
    public static Object getBean(String beanId) {
        return context.getBean(beanId);
    }
    
    /**
     * 根据bean名字和返回类型获取对应的bean
     * 
     * @param <T> 返回类型
     * @param requiredType 需要的返回类型
     * @return requiredType类型的bean
     */
    public static <T> T getBean(Class<T> requiredType) {
        return context.getBean(requiredType);
    }
    
    /**
     * 根据bean名字和返回类型获取对应的bean
     * 
     * @param <T> 返回类型
     * @param beanId bean名字
     * @param requiredType 需要的返回类型
     * @return requiredType类型的bean
     */
    public static <T> T getBean(String beanId, Class<T> requiredType) {
        return context.getBean(beanId, requiredType);
    }
}
