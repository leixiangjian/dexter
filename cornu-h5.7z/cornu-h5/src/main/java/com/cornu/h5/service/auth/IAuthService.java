package com.cornu.h5.service.auth;

import com.cornu.h5.contants.ResponseObject;
import com.cornu.h5.service.auth.dto.AuthServiceBean;

public interface IAuthService {
	public ResponseObject login(AuthServiceBean authServiceBean);

	public ResponseObject checkAccessToken(AuthServiceBean authServiceBean);

	public ResponseObject logout(AuthServiceBean authServiceBean);
}
