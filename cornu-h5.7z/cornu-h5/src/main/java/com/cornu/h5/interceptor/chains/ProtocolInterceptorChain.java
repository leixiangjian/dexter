package com.cornu.h5.interceptor.chains;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.method.HandlerMethod;

import com.alibaba.fastjson.JSONObject;
import com.cornu.h5.contants.ResponseObject;
import com.cornu.h5.context.WebContext;
import com.cornu.h5.context.WebContextThreadLocal;
import com.cornu.h5.exception.WebException;

/**
 * 协议检查
 * 
{
    "r_head":{
       "r_time":1111222,
       "random_key":"2342343255",
       "client_os":"android",
       "access_token":"4123664ddc274865917c1f5446164c3c"
    },
    "r_body":{
       "r_method":"test",
       "r_params":{
          "trade_money":10,
          "trades":[{"expect":"2017060747","lot_id":151,"code_list":[{"play_id":"RX3","code":"05,08,11","beishu":5}],"zhushu":1,"total_money":10,"beishu":5,"is_zhuihao":0,"is_award_stop":1,"select":1}],
          "touzz_info":"江西省南昌市钱入袋投注站,江西省南昌市钱入袋投注站,501,701,701-dg,702,702-dg,502,151"
       }
    }
}

 * 
 * @author lenovo01
 *
 */
public class ProtocolInterceptorChain extends AbstractInterceptorChain{

	private static final Logger LOG = LoggerFactory.getLogger(ProtocolInterceptorChain.class);
	
	@Override
	public void execute(HandlerMethod method,Object obj) throws WebException {
		try 
		{
			WebContext context=WebContextThreadLocal.get();
			JSONObject requestBody =  context.getRequestBody();
			
			//检查请求协议
			if(!requestBody.containsKey("r_head")||!requestBody.containsKey("r_body")){
				throw new WebException("请求协议格式不正确。",ResponseObject.ERROR_CODE_1009);
			}
			JSONObject rHead = requestBody.getJSONObject("r_head");
			
	        //请求随机数
	        String random_key = rHead.getString("random_key");
	        if(!rHead.containsKey("random_key") || StringUtils.isBlank(random_key)){
				throw new WebException("请求协议中属性random_key值为空",ResponseObject.ERROR_CODE_1009);
			}
	        
	        //客户端系统
	        String client_os = rHead.getString("client_os");
	        if(!rHead.containsKey("client_os") || StringUtils.isBlank(client_os)){
				throw new WebException("请求协议中属性client_os值为空",ResponseObject.ERROR_CODE_1009);
			}
	        
	        JSONObject rBody = requestBody.getJSONObject("r_body");
	        //请求方法
	        String r_method = rBody.getString("r_method");
	        if(!rBody.containsKey("r_method")||StringUtils.isBlank(r_method)){
	        	throw new WebException("请求协议中属性r_method值为空",ResponseObject.ERROR_CODE_1009);
	        }
	        
	        //请求参数
	        if(!rBody.containsKey("r_params")){
	        	throw new WebException("请求协议中属性r_params不存在",ResponseObject.ERROR_CODE_1009);
	        }
	        
	        bindHead(rHead,rBody,context);
		} catch (WebException e) 
		{
			LOG.error(e.getMessage(), e);
			throw e;
		} catch (Exception e) {
			LOG.error(e.getMessage(), e);
			throw new WebException("请求协议格式不正确",ResponseObject.ERROR_CODE_1009);
		}
	}
	
	private void bindHead(JSONObject rHead,JSONObject rBody,WebContext context){
		context.setrHead(rHead);
		context.setrBody(rBody);
	}
}
