package com.cornu.h5.service.auth.impl.self;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.cornu.h5.contants.ResponseObject;
import com.cornu.h5.dao.bean.UserBean;
import com.cornu.h5.service.auth.dto.AuthServiceBean;
import com.cornu.h5.service.auth.impl.AbsAuthService;
import com.cornu.h5.utils.Md5Utils;

@Service("selfAuthService")
public class SelfAuthService extends AbsAuthService {

	protected static final Logger logger = LoggerFactory.getLogger(SelfAuthService.class);

	protected ResponseObject loginHandler(AuthServiceBean authServiceBean) {
		logger.debug("用户登录操作", authServiceBean.getUserName());
		String username = authServiceBean.getUserName();
		String pwd = authServiceBean.getPwd();

		ResponseObject response = new ResponseObject();
		response.code = ResponseObject.ERROR_CODE_1005;
		try {
			if (StringUtils.isEmpty(username)) {
				response.desc = "USERNAME参数为空异常";
				return response;
			}

			if (StringUtils.isEmpty(pwd)) {
				response.desc = "PWD参数为空异常";
				return response;
			}

			logger.info("登录操作, mobile={}", username);
			
			UserBean userBeanParams = new UserBean();
			userBeanParams.setLoginName(username);
			UserBean userBean = userService.queryUser(userBeanParams);
			if (null == userBean) {
				response.code = ResponseObject.ERROR_CODE_1006;
				response.desc = "用户或密码错误";
				return response;
			}

			String password = (String) userBean.getPassword();

			// 明文加密
			String passwordMD5 = Md5Utils.encodePassword(pwd, (String) userBean.getSalt());
			if (!passwordMD5.equals(password)) {
				response.code = ResponseObject.ERROR_CODE_1006;
				response.desc = "用户或密码错误";
				return response;
			}

			String userCd = (String) userBean.getUserCd();

			Map<String, Object> resMap = new HashMap<String, Object>();
			resMap.put("userCd", userCd);
			response.setResMap(resMap);
			response.code = ResponseObject.OK_CODE_1000;
		} catch (Exception e) {
			logger.error("系统异常", e);
			response.code = ResponseObject.ERROR_CODE_1004;
			response.desc = "系统异常";
		}
		return response;
	}

	protected ResponseObject logoutHandler(AuthServiceBean authServiceBean) {
		ResponseObject response = new ResponseObject();
		response.code = ResponseObject.OK_CODE_1000;
		return response;
	}
}
