package com.cornu.h5.interceptor.chains;

import org.springframework.web.method.HandlerMethod;

import com.cornu.h5.exception.WebException;

public interface InterceptorChain {
	abstract void execute(HandlerMethod method,Object obj) throws WebException;
}
