package com.cornu.h5.controllers.sys;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cornu.h5.annotation.WriteLog;
import com.cornu.h5.annotation.WriteLog.WriteType;
import com.cornu.h5.controllers.BaseController;
import com.cornu.h5.request.LoginRequest;
import com.cornu.h5.response.LoginResponse;

@Controller
@RequestMapping({ "/agent" })
public class SystemController extends BaseController{
//	private static final Logger LOG = LoggerFactory.getLogger(DemoController.class);

	@RequestMapping("/login")
	@WriteLog(funcationType = WriteType.QUERY, funcation = "登陆", desc = "登陆")
	public LoginResponse login(LoginRequest request)
	{
		LoginResponse loginResponse = new LoginResponse();
		return loginResponse;
	}
}
