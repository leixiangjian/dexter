package com.cornu.h5.service.auth.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class AuthBean implements Serializable{
	private static final long serialVersionUID = -3620997598867603053L;
	private String accessToken;
	private String refreshToken;
	private String authToken;
	private int  vaildTime;	// 有限时间，单位小时
	
	private Object userObj;
	
	private List<AuthBean> tokenBeanList;

	public AuthBean(){}
	public AuthBean(String authToken,String accessToken,Object userObj)
	{
		this.accessToken=accessToken;
		this.authToken=authToken;
		this.userObj=userObj;
	}

	public String getAuthToken() {
		return authToken;
	}

	public void setAuthToken(String authToken) {
		this.authToken = authToken;
	}

	public Object getUserObj() {
		return userObj;
	}

	public void setUserObj(Object userObj) {
		this.userObj = userObj;
	}

	public String getAccessToken() {
		return accessToken;
	}

	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}

	public String getRefreshToken() {
		return refreshToken;
	}

	public void setRefreshToken(String refreshToken) {
		this.refreshToken = refreshToken;
	}

	public List<AuthBean> getTokenBeanList() {
		return tokenBeanList;
	}

	public void setTokenBeanList(List<AuthBean> tokenBeanList) {
		this.tokenBeanList = tokenBeanList;
	}

	public int getVaildTime() {
		return vaildTime;
	}
	public void setVaildTime(int vaildTime) {
		this.vaildTime = vaildTime;
	}
	public void addTokenBean(AuthBean bean)
	{
		if(tokenBeanList==null)
		{
			tokenBeanList=new ArrayList<AuthBean>();
		}
		tokenBeanList.add(bean);
	}
}
