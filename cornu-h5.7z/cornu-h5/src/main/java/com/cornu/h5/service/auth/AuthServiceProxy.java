package com.cornu.h5.service.auth;

import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * 主要用来选择相关的授权方 比如:自有系统、支付宝、微信、百度
 * 
 * @author Administrator
 *
 */
@Service("authServiceProxy")
public class AuthServiceProxy {

	@Autowired
	@Resource(name = "authServiceMap")
	Map<String, IAuthService> authServiceMap;

	public static final String LOGIN_TYPE_SELF = "00";

	/**
	 * 根据提供类型编码获取对应的授权方实现Bean 
	 * 00:自有登陆
	 * 
	 * @param loginTypeCode
	 * @return
	 */
	public IAuthService getAuthServiceImplBean(String loginTypeCode) {
		IAuthService authService = null;
		if (StringUtils.isEmpty(loginTypeCode)) {
			authService = authServiceMap.get(LOGIN_TYPE_SELF);
		} else {
			authService = authServiceMap.get(loginTypeCode);
		}

		if (null == authService) {
			throw new RuntimeException("登录渠道目前不支持,请检查");
		}
		return authService;
	}

}
