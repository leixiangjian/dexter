package com.cornu.h5.annotation;  

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**  
 * ClassName:WriteLog <br/>  
 * Function: TODO ADD FUNCTION. <br/>  
 * Reason:   TODO ADD REASON. <br/>  
 * Date:     2016年3月16日 上午10:05:59 <br/>  
 * @author  雷湘剑 
 * @version    
 * @since    JDK 1.7  
 * @see        
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(value={ElementType.METHOD})
public @interface WriteLog {
	public WriteType funcationType();
	
	public String funcation();
	
	public String desc();
	
	public enum WriteType{
        QUERY,
        ADD,
        DELETE,
        MODIFY,
        VIEW
    }
}
  
