package com.cornu.h5.service.auth;

import java.util.Map;

import com.cornu.h5.contants.ResponseObject;

public interface IAuthAccess {
	public ResponseObject checkAccessToken(Map<String, String> params);

	public ResponseObject login(Map<String, String> params);

	public ResponseObject logout(Map<String, String> params);
}
