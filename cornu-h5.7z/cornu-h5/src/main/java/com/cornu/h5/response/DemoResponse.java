package com.cornu.h5.response;

public class DemoResponse extends Response {
	private static final long serialVersionUID = -407306921757276015L;

}
