package com.cornu.h5.interceptor;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.cornu.h5.context.WebContext;
import com.cornu.h5.context.WebContextThreadLocal;
import com.cornu.h5.exception.WebException;

public abstract class BaseInterceptor implements HandlerInterceptor {

	private static final Logger LOG = LoggerFactory.getLogger(BaseInterceptor.class);

	private String defaultResChartSet = "UTF-8";

	@Override
	public void afterCompletion(HttpServletRequest req, HttpServletResponse res, Object result, Exception exception)
			throws Exception {
		if (null != exception) {
			if (exception instanceof WebException) {
				LOG.error(exception.getMessage(), exception);
			} else {
				LOG.error(exception.getMessage(), exception);
				res.setStatus(403);
				return;
			}
		}
	}

	@Override
	public void postHandle(HttpServletRequest req, HttpServletResponse res, Object arg2, ModelAndView arg3)
			throws Exception {

	}

	@Override
	public boolean preHandle(HttpServletRequest req, HttpServletResponse res, Object arg2) throws Exception {
		res.setCharacterEncoding(defaultResChartSet);
		res.setContentType("application/json;charset=" + defaultResChartSet);
		bindContext(req, res);
		return true;
	}

	private void bindContext(HttpServletRequest request, HttpServletResponse response) {
		final WebContext context = new WebContext();
		context.setRequest(request);
		context.setResponse(response);
		context.setRequestTime(System.currentTimeMillis());
		context.setRequestBody(this.getRequestBody(request));
		WebContextThreadLocal.put(context);
	}

	private JSONObject getRequestBody(HttpServletRequest req) {
		String requestStr = null;
		try {
			byte[] byteArray = IOUtils.toByteArray(req.getInputStream());
			requestStr = new String(byteArray,
					StringUtils.isEmpty(req.getCharacterEncoding()) ? "UTF-8" : req.getCharacterEncoding());

			return JSONObject.parseObject(requestStr);
		} catch (IOException e) {
			LOG.error(e.getMessage(), e);
		} catch (JSONException ex) {
			LOG.error("请求报文异常，无法解析: ", requestStr);
		}
		return null;
	}

	public void setDefaultResChartSet(String defaultResChartSet) {
		this.defaultResChartSet = defaultResChartSet;
	}

	public String getDefaultResChartSet() {
		return defaultResChartSet;
	}

	protected void writeData(String result, HttpServletResponse res) {
		try {
			res.getWriter().write(result);
		} catch (IOException e) {
			LOG.error(e.getMessage(), e);
		}
	}
}
