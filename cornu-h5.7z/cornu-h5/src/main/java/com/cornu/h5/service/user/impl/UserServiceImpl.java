package com.cornu.h5.service.user.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.cornu.h5.dao.bean.UserBean;
import com.cornu.h5.exception.ServiceException;
import com.cornu.h5.service.user.IUserService;

@Service("userService")
public class UserServiceImpl implements IUserService {
	private static final Logger LOG = LoggerFactory
			.getLogger(UserServiceImpl.class);

	@Override
	public UserBean queryUser(UserBean userBean) throws ServiceException {
		// TODO Auto-generated method stub
		return null;
	}





}
