package com.cornu.h5.service.auth.impl;

import org.apache.amber.oauth2.as.issuer.MD5Generator;
import org.apache.amber.oauth2.as.issuer.OAuthIssuer;
import org.apache.amber.oauth2.as.issuer.OAuthIssuerImpl;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;

import com.alibaba.fastjson.JSON;
import com.cornu.h5.contants.ResponseObject;
import com.cornu.h5.contants.TairConstants;
import com.cornu.h5.service.auth.IAuthService;
import com.cornu.h5.service.auth.dto.AuthBean;
import com.cornu.h5.service.auth.dto.AuthServiceBean;
import com.cornu.h5.service.user.IUserService;
import com.cornu.h5.utils.TairManager;

public abstract class AbsAuthService implements IAuthService {

	@Autowired
	@Qualifier("tairManager")
	protected TairManager tairManager;

	protected Integer tairVerion = 0;

	@Value("${auth.accessToken.expireTime}")
	protected String accessTokenExpireTime;

	@Value("${auth.code.expireTime}")
	protected String codeExpireTime;

	@Autowired
	@Qualifier("userService")
	protected IUserService userService;

	protected static final Logger logger = LoggerFactory.getLogger(AbsAuthService.class);

	public ResponseObject checkAccessToken(AuthServiceBean authServiceBean) {
		String accessToken = authServiceBean.getAccessToken();

		ResponseObject response = new ResponseObject();
		try {
			String authBeanStr = tairManager.getValue(TairConstants.NS_AUTH,
					String.format("%s%s", TairConstants.TAIR_KEY_AUTH_ACCESS_FIX, accessToken));
			AuthBean authBean = JSON.parseObject(authBeanStr, AuthBean.class);
			if (authBean == null) {
				response.code = ResponseObject.ERROR_CODE_1007;
				response.desc = "token非法或已过期";
				return response;
			}

			tairManager.putCache(TairConstants.NS_AUTH,
					String.format("%s%s", TairConstants.TAIR_KEY_AUTH_ACCESS_FIX, authBean.getAccessToken()),
					JSON.toJSONString(authBean), tairVerion, Integer.valueOf(accessTokenExpireTime));
			response.code = ResponseObject.OK_CODE_1000;
			response.desc = "成功";
			response.putToResMap("U_USERNAME", (String) authBean.getUserObj());
		} catch (Exception e) {
			logger.error("系统异常", e);
			response.code = ResponseObject.ERROR_CODE_1004;
			response.desc = "系统错误";
		}
		return response;
	}

	protected abstract ResponseObject loginHandler(AuthServiceBean authServiceBean);

	public ResponseObject login(AuthServiceBean authServiceBean) {
		ResponseObject response = new ResponseObject();
		response.setCode(ResponseObject.ERROR_CODE_1005);

		try {
			response = loginHandler(authServiceBean);
			if (!ResponseObject.OK_CODE_1000.equals(response.getCode())) {
				return response;
			}

			String userCd = (String) response.getResMap().get("userCd");

			OAuthIssuer oauthIssuer = new OAuthIssuerImpl(new MD5Generator());
			String authToken = oauthIssuer.authorizationCode();

			OAuthIssuer oauthAccessIssuer = new OAuthIssuerImpl(new MD5Generator());
			String accessToken = oauthAccessIssuer.accessToken();

			if (StringUtils.isEmpty(userCd)) {
				response.desc = "用户编码参数为空";
				return response;
			}

			String oldCode = tairManager.getValue(TairConstants.NS_AUTH,
					String.format("%s%s", TairConstants.TAIR_KEY_AUTH_USER_FIX, userCd));
			if (!StringUtils.isEmpty(oldCode)) {
				String authBeanStr = tairManager.getValue(TairConstants.NS_AUTH,
						String.format("%s%s", TairConstants.TAIR_KEY_AUTH_CODE_FIX, oldCode));
				AuthBean authBean = JSON.parseObject(authBeanStr, AuthBean.class);
				if (authBean != null) {
					if (!StringUtils.isEmpty(authBean.getAccessToken())) {
						tairManager.delete(TairConstants.NS_AUTH, String.format("%s%s",
								TairConstants.TAIR_KEY_AUTH_ACCESS_FIX, authBean.getAccessToken()));
					}
					tairManager.delete(TairConstants.NS_AUTH,
							String.format("%s%s", TairConstants.TAIR_KEY_AUTH_CODE_FIX, oldCode));
				}
			}
			AuthBean authBean = new AuthBean();
			authBean.setAuthToken(authToken);
			authBean.setUserObj(userCd);

			tairManager.putCache(TairConstants.NS_AUTH,
					String.format("%s%s", TairConstants.TAIR_KEY_AUTH_USER_FIX, userCd), authToken, tairVerion,
					Integer.valueOf(codeExpireTime));

			tairManager.putCache(TairConstants.NS_AUTH,
					String.format("%s%s", TairConstants.TAIR_KEY_AUTH_CODE_FIX, authBean.getAuthToken()),
					JSON.toJSONString(authBean), tairVerion, Integer.valueOf(codeExpireTime));

			// 对access_token的处理
			authBean.setAccessToken(accessToken);
			tairManager.putCache(TairConstants.NS_AUTH,
					String.format("%s%s", TairConstants.TAIR_KEY_AUTH_ACCESS_FIX, authBean.getAccessToken()),
					JSON.toJSONString(authBean), tairVerion, Integer.valueOf(accessTokenExpireTime));
			response.code = ResponseObject.OK_CODE_1000;
			response.putToResMap("access_token", authBean.getAccessToken());

			response.data = userCd;
			response.putToResMap("authToken", authToken);
			response.code = ResponseObject.OK_CODE_1000;
		} catch (Exception e) {
			logger.error("系统异常", e);
			response.code = ResponseObject.ERROR_CODE_1004;
			response.desc = "系统错误";
		}

		return response;
	}

	protected abstract ResponseObject logoutHandler(AuthServiceBean authServiceBean);

	public ResponseObject logout(AuthServiceBean authServiceBean) {
		ResponseObject resLogout = logoutHandler(authServiceBean);
		if (!ResponseObject.OK_CODE_1000.equals(resLogout.getCode())) {
			return resLogout;
		}

		String accessToken = authServiceBean.getAccessToken();

		ResponseObject response = new ResponseObject();
		response.code = ResponseObject.OK_CODE_1000;
		response.desc = "成功";
		try {
			String authBeanStr = tairManager.getValue(TairConstants.NS_AUTH,
					String.format("%s%s", TairConstants.TAIR_KEY_AUTH_ACCESS_FIX, accessToken));

			AuthBean authBean = JSON.parseObject(authBeanStr, AuthBean.class);

			if (authBean != null) {
				tairManager.delete(TairConstants.NS_AUTH,
						String.format("%s%s", TairConstants.TAIR_KEY_AUTH_USER_FIX, authBean.getUserObj()));
				tairManager.delete(TairConstants.NS_AUTH,
						String.format("%s%s", TairConstants.TAIR_KEY_AUTH_CODE_FIX, authBean.getAuthToken()));
				tairManager.delete(TairConstants.NS_AUTH,
						String.format("%s%s", TairConstants.TAIR_KEY_AUTH_ACCESS_FIX, accessToken));
				response.data = authBean.getUserObj();
			} else {
				response.data = null;
			}
		} catch (Exception e) {
			logger.error("注销异常", e);
		}
		return response;
	}
}
