package com.cornu.h5.request;

import com.cornu.h5.validators.IValidator;

public class LoginRequest extends Request {
	private static final long serialVersionUID = 2366005950187198768L;

	@Override
	public ValidateRes validator() {
		return null;
	}

	@Override
	public Class<IValidator> getValidatorType() {
		return null;
	}

}
