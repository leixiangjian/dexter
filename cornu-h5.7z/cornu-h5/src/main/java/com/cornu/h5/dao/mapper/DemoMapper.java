package com.cornu.h5.dao.mapper;

public interface DemoMapper {

}
