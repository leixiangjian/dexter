package com.cornu.h5.service.auth.impl;

import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.cornu.h5.contants.ResponseObject;
import com.cornu.h5.service.auth.AuthServiceProxy;
import com.cornu.h5.service.auth.IAuthAccess;
import com.cornu.h5.service.auth.IAuthService;
import com.cornu.h5.service.auth.dto.AuthServiceBean;

@Service("authAccessImpl")
public class AuthAccessImpl implements IAuthAccess {
	@Autowired
	@Qualifier("authServiceProxy")
	private AuthServiceProxy authServiceProxy;

	private final static String DEFAULT_LOGIN_TYPE = "00";

	public ResponseObject checkAccessToken(Map<String, String> params) {
		AuthServiceBean authServiceBean = new AuthServiceBean();
		authServiceBean.setAccessToken((String) params.get("access_token"));
		return getAuthService((String) params.get("login_type")).checkAccessToken(authServiceBean);
	}

	public ResponseObject login(Map<String, String> params) {
		AuthServiceBean authServiceBean = new AuthServiceBean();
		authServiceBean.setUserName((String) params.get("username"));
		authServiceBean.setPwd((String) params.get("password"));
		authServiceBean.setAuthToken((String) params.get("auth_token"));

		return getAuthService((String) params.get("login_type")).login(authServiceBean);
	}

	public ResponseObject logout(Map<String, String> params) {
		AuthServiceBean authServiceBean = new AuthServiceBean();
		authServiceBean.setAccessToken((String) params.get("access_token"));
		return getAuthService((String) params.get("login_type")).logout(authServiceBean);
	}

	private IAuthService getAuthService(String loginTypeCode) {
		if (StringUtils.isEmpty(loginTypeCode)) {
			loginTypeCode = DEFAULT_LOGIN_TYPE;
		}
		return authServiceProxy.getAuthServiceImplBean(loginTypeCode);
	}

}
