package com.cornu.h5.contants;

public interface TairConstants {
	int NS_AUTH = 0;
	int NS_DATA = 1;

	String TAIR_KEY_AUTH_FIX = "AUTH_";
	String TAIR_KEY_AUTH_CODE_FIX = "AC_";
	String TAIR_KEY_AUTH_ACCESS_FIX = "AA_";
	String TAIR_KEY_AUTH_USER_FIX = "AU_";
	int TMP_EXPIRE_TIME = 120;
}
