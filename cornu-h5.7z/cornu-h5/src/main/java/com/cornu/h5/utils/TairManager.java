package com.cornu.h5.utils;

import java.io.Serializable;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.cornu.h5.contants.TairConstants;
import com.taobao.tair.DataEntry;
import com.taobao.tair.Result;
import com.taobao.tair.ResultCode;
import com.taobao.tair.impl.DefaultTairManager;

public class TairManager extends DefaultTairManager {

	private String servers;
	
	private String sysFix;

	public String getServers() {
		return servers;
	}

	public void setServers(String servers) {
		this.servers = servers;
	}

	
	public void setSysFix(String sysFix) {
		this.sysFix = sysFix;
	}

	@Override
	public void init() {
		String[] arr = servers.split(","); 
		configServerList = Arrays.asList(arr);

		super.init();
	}
	
	public <T> T getValue(int lotId, int namespace, Serializable key) {
		return this.getValue( namespace, lotId+"_"+key);
	}
	
	public <T> T getValue(Serializable key) {
		return this.getValue( TairConstants.NS_DATA, key);
	}
	
	
	public <T> T getValue(int namespace, Serializable key) {
		Result<DataEntry> resultEntry = super.get(namespace, this.getKey(key));
		if (resultEntry.isSuccess()) {
			DataEntry dataEntry = resultEntry.getValue();
			return null != dataEntry ? (T) dataEntry.getValue() : null;
		}
		return null;
	}
	
	public <T> T getValueRealKey(int namespace, Serializable key) {
		Result<DataEntry> resultEntry = super.get(namespace, key);
		if (resultEntry.isSuccess()) {
			DataEntry dataEntry = resultEntry.getValue();
			return null != dataEntry ? (T) dataEntry.getValue() : null;
		}
		return null;
	}
	
	
	public void putTmpDataCache(Serializable key, Serializable value){
		putCache(TairConstants.NS_DATA, key, value, 0, TairConstants.TMP_EXPIRE_TIME);
	}
	
	
	public void putCache(Serializable key, Serializable value) {
		 putCache(TairConstants.NS_DATA, key, value, 0, 0);
	}
	
	public void putDataCache(Serializable key, Serializable value, int expireTime){
		putCache(TairConstants.NS_DATA, key, value, 0, expireTime);
	}
 
	public void putCache(int namespace, Serializable key, Serializable value) {
		 putCache(namespace, key, value, 0, 0);
	}
	
	public void putCache(int lotId,int namespace, Serializable key, Serializable value) {
		 putCache(namespace, lotId+"_"+key, value, 0, 0);
	}

	public void putCache(int namespace, Serializable key, Serializable value,
						  int version) {
		 putCache(namespace, key, value, version, 0);
	}
	
	public ResultCode put(int namespace,Serializable key, Serializable value, int version, int expireTime){
		ResultCode resultCode  = super.put(nameSpaceMap.get(namespace+"")==null?TairConstants.NS_AUTH:nameSpaceMap.get(namespace+""), this.getKey(key), value, version, expireTime);
		return resultCode;
	}
	
	public void putCache(int namespace, Serializable key, Serializable value,
			  int version, int expireTime){
		ResultCode resultCode  = super.put(nameSpaceMap.get(namespace+"")==null?TairConstants.NS_AUTH:nameSpaceMap.get(namespace+""), this.getKey(key), value, version, expireTime);
		if(!resultCode.isSuccess()){
			throw new RuntimeException("putTair error...ResultCode:"+resultCode.getCode());
		}
	}
	

	@Override
	public ResultCode delete(int namespace, Serializable key) {
		return super.delete(namespace, this.getKey(key));
	}
	
	@Override
	public Result<DataEntry> get(int namespace, Serializable key) {
		return super.get(namespace, this.getKey(key));
	}
	
	@Override
	public Result<Integer> incr(int namespace, Serializable key, int value,int defaultValue, int expireTime)
	{
		return super.incr(namespace, this.getKey(key), value, defaultValue, expireTime);
	}
	@Override
	public Result<Integer> getItemCount(int namespace, Serializable key)
	{
		return super.getItemCount(namespace, this.getKey(key));
	}
	@Override
	public ResultCode removeItems(int namespace, Serializable key, int offset,int count)
	{
		return super.removeItems(namespace, this.getKey(key), offset, count);
	}
	@Override
	public Result<DataEntry> getItems(int namespace,Serializable key, int offset, int count) {
		return super.getItems(namespace, this.getKey(key), offset, count);
	}
	@Override
	public Result<DataEntry> getAndRemove(int namespace,
			Serializable key, int offset, int count) {
		return super.getAndRemove(namespace, this.getKey(key), offset, count);
	}
	@Override
	public ResultCode addItems(int namespace, Serializable key,
			List<? extends Object> items, int maxCount, int version,
			int expireTime) {
		return super.addItems(namespace, this.getKey(key), items, maxCount, version, expireTime);
	}
	@Override
	public Result<Integer> decr(int namespace, Serializable key, int value,int defaultValue, int expireTime)
	{
		return super.decr(namespace, this.getKey(key), value, defaultValue, expireTime);
	}
	@Override
	public ResultCode invalid(int namespace, Serializable key) {
		return super.invalid(namespace, this.getKey(key));
	}

	
	public static final Map<String,Integer> nameSpaceMap = new HashMap<String, Integer>();
	static{
		nameSpaceMap.put("151", TairConstants.NS_DATA);
		nameSpaceMap.put("152", TairConstants.NS_DATA);
		nameSpaceMap.put("153", TairConstants.NS_DATA);
		nameSpaceMap.put("501", TairConstants.NS_DATA);
		nameSpaceMap.put("601", TairConstants.NS_DATA);
		nameSpaceMap.put("701", TairConstants.NS_DATA);
		nameSpaceMap.put("702", TairConstants.NS_DATA);
		nameSpaceMap.put("1", TairConstants.NS_DATA);
	}
	
	private Serializable getKey(Serializable key)
	{
		if((key instanceof String) && !StringUtils.isEmpty(this.sysFix))
		{
			return this.sysFix+(String)key;
		}
		return key;
	}
}
