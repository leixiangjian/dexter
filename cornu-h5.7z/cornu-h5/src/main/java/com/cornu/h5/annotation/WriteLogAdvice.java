package com.cornu.h5.annotation;

import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSONObject;
import com.cornu.h5.annotation.WriteLog.WriteType;
import com.cornu.h5.context.WebContextThreadLocal;

@Aspect
public class WriteLogAdvice {
	private static final Logger LOG = LoggerFactory
			.getLogger(WriteLogAdvice.class);
	
	@AfterReturning(pointcut = "execution(* com.cornu.h5.controllers..*.*(..))", returning = "response")
	public void logRecord(JoinPoint joinPoint, Object response) {
		Signature signature = joinPoint.getSignature();
		MethodSignature methodSignature = (MethodSignature) signature;  
		Method method = methodSignature.getMethod(); 
		WriteLog annotation = method.getAnnotation(WriteLog.class);
		if (annotation != null) {
			String userCd = WebContextThreadLocal.get().getUserCd();
			JSONObject logjson = new JSONObject();
			logjson.put("optFun", annotation.funcation());
			logjson.put("optFunDesc", annotation.desc());
			WriteType writeType = annotation.funcationType();
			String optType = null;
			if (writeType.equals(WriteType.ADD)) {
				optType = "ADD";
			} else if (writeType.equals(WriteType.DELETE)) {
				optType = "DELETE";
			} else if (writeType.equals(WriteType.MODIFY)) {
				optType = "MODIFY";
			} else if (writeType.equals(WriteType.QUERY)) {
				optType = "QUERY";
			} else if (writeType.equals(WriteType.VIEW)) {
				optType = "VIEW";
			}

			logjson.put("optType", optType);
			logjson.put("optRes",JSONObject.toJSONString(response));
			logjson.put("optUser", userCd == null ?"":userCd);
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			logjson.put("optTime", simpleDateFormat.format(new Date(System.currentTimeMillis())));
			LOG.info("{}", logjson);
		}
	}

}
