package com.cornu.h5.request;

import com.cornu.h5.validators.IValidator;

public class DemoRequest extends Request {
	private static final long serialVersionUID = -4643343064078786440L;

	@Override
	public ValidateRes validator() {
		ValidateRes validateRes = new  ValidateRes();
		validateRes.setRes_code(ValidateRes.SUCCESS);
		validateRes.setRes_msg("检查通过");
		return validateRes;
	}

	@Override
	public Class<IValidator> getValidatorType() {
		return null;
	}

}
