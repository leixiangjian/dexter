package com.cornu.h5.contants;

public final class CodeConstant {
	private CodeConstant(){}

}
