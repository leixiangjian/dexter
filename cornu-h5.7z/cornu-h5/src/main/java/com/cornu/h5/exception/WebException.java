package com.cornu.h5.exception;

public class WebException extends RuntimeException {
	private static final long serialVersionUID = 1L;

	private String errCode;

	private String errDesc;

	private Object object;

	public Object getObject() {
		return object;
	}

	public String getErrDesc() {
		return errDesc;
	}

	public String getErrCode() {
		return errCode;
	}

	public WebException() {
		super();
	}

	public WebException(String message) {
		super(message);
	}

	public WebException(String message, String errorCode) {
		super(message);
		this.errCode = errorCode;
		this.errDesc = message;
	}

	public WebException(String message, Throwable cause) {
		super(message, cause);
		this.errDesc = message;
	}

	public WebException(String message, Throwable cause, String errorCode) {
		super(message, cause);
		this.errCode = errorCode;
		this.errDesc = message;
	}

	public WebException(String message, String errorCode, Object object) {
		super(message);
		this.errCode = errorCode;
		this.object = object;
		this.errDesc = message;
	}

	public WebException(String message, Throwable cause, String errorCode, Object object) {
		super(message, cause);
		this.errCode = errorCode;
		this.object = object;
		this.errDesc = message;
	}

	public WebException(Throwable cause, String errorCode) {
		super(cause);
		this.errCode = errorCode;
	}
}
