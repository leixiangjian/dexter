package com.cornu.h5.interceptor.chains;

import javax.servlet.http.Cookie;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.method.HandlerMethod;

import com.cornu.h5.contants.ResponseObject;
import com.cornu.h5.context.WebContext;
import com.cornu.h5.context.WebContextThreadLocal;
import com.cornu.h5.exception.WebException;
import com.taobao.tair.TairManager;

public class ClientInterceptorChain extends AbstractInterceptorChain
{
	private static final Logger LOG = LoggerFactory.getLogger(ClientInterceptorChain.class);
	
	@Autowired
	@Qualifier("tairManager")
	protected TairManager tairManager;
	
	@Override
	public void execute(HandlerMethod method,Object obj) throws WebException {
		try 
		{
			WebContext context=WebContextThreadLocal.get();
			
			//效验消息是否重复
			Cookie[] cookies = context.getRequest().getCookies();
	        String cookieKv = this.getParameterFromCookies(cookies, "request_s_token");
	        LOG.debug("request_s_token :{}",cookieKv);
	        if (StringUtils.isNotEmpty(cookieKv)) 
	        {
	            if (cookieKv.equals(context.getHeadValue("random_key"))) 
	            {
	            	throw new WebException("请勿重复提交",ResponseObject.ERROR_CODE_1003);
	            }
	        }
			Cookie cookie = new Cookie("request_s_token", context.getHeadValue("random_key"));
			context.getResponse().addCookie(cookie);
		} catch (WebException e) 
		{
			throw e;
		} catch (Exception e) {
			LOG.error(e.getMessage(), e);
			throw new WebException("调用服务异常",ResponseObject.ERROR_CODE_1004,null);
		}
	}

}
