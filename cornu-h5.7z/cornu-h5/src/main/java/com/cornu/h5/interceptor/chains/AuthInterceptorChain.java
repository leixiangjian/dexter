package com.cornu.h5.interceptor.chains;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.method.HandlerMethod;

import com.cornu.h5.contants.ResponseObject;
import com.cornu.h5.context.WebContext;
import com.cornu.h5.context.WebContextThreadLocal;
import com.cornu.h5.exception.WebException;
import com.cornu.h5.service.auth.IAuthAccess;
import com.taobao.tair.TairManager;

public class AuthInterceptorChain extends AbstractInterceptorChain {
	private static final Logger LOG = LoggerFactory.getLogger(AuthInterceptorChain.class);

	@Autowired
	@Qualifier("tairManager")
	protected TairManager tairManager;
	
	@Autowired
	@Qualifier("authAccessImpl")
	protected IAuthAccess authAccess;

	@Override
	public void execute(HandlerMethod method,Object obj) throws WebException {
		WebContext context = WebContextThreadLocal.get();
		String r_method = context.getrBody().getString("r_method");
		if (this.isPassAuth(method,r_method)) {
			// 不需要鉴权
			LOG.info("无需鉴权:方法{}", r_method);
			return;
		}
		
		String userCd = (String) context.getUserCd();
		
		String accessToken = (String) context.getHeadValue("access_token");
		String loginType = (String) context.getHeadValue("login_type");

		LOG.info("AuthInterceptorChain判断accessToken,accessToken={}", accessToken);
		if (StringUtils.isBlank(accessToken)) {
			throw new WebException("access_token不能为空", ResponseObject.ERROR_CODE_1001, r_method);
		}
		
		if (StringUtils.isBlank(loginType)) {
			throw new WebException("login_type不能为空", ResponseObject.ERROR_CODE_1001, r_method);
		}

		// 鉴权处理
		Map<String,String> params = new HashMap<String,String>();
		params.put("access_token", accessToken);
		params.put("login_type", loginType);
		
		ResponseObject responseObject = authAccess.checkAccessToken(params);
		if(responseObject.code.equals(ResponseObject.OK_CODE_1000)){
			Map<String, Object> data = responseObject.getResMap();
			userCd = (String)data.get("userCd");
			LOG.debug("鉴权成功：accessToken:{},loginType:{},usercd:{}",accessToken,loginType,userCd);
			context.setUserCd(userCd);
		}else{
			LOG.error("鉴权失败：{}",responseObject.code);
			throw new WebException((String)responseObject.getDesc(),(String) responseObject.getCode(),r_method);
		}
		
	}

}
