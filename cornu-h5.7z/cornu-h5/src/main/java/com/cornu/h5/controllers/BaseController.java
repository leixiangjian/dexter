package com.cornu.h5.controllers;

import com.cornu.h5.context.WebContext;
import com.cornu.h5.context.WebContextThreadLocal;

public class BaseController {
	public WebContext getWebContext(){
		return WebContextThreadLocal.get();
	}
}
