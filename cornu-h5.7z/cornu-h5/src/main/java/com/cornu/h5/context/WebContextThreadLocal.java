
package com.cornu.h5.context;

/**
 * 
 * @author dexter
 *
 */
public final class WebContextThreadLocal {
	
	private static final ThreadLocal<WebContext> context = new ThreadLocal<WebContext>();
	
	public static final void put(WebContext webContext){
		context.set(webContext);
	}
	
	public static final WebContext get(){
		return context.get();
	}
	
	public static final void remove(){
		context.remove();
	}
	
	private WebContextThreadLocal(){
		
	}

}
