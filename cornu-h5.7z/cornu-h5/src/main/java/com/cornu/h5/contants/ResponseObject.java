package com.cornu.h5.contants;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ResponseObject implements Serializable{
	private static final long serialVersionUID = -8232752373997652469L;
	//OK
	public static final String OK_CODE_1000 = "1000";
	
	//参数问题
	public static final String ERROR_CODE_1001 = "1001";
	
	//方法访问受限
	public static final String ERROR_CODE_1002 = "1002";
	
	//该请求已经提交，请勿重复提交
	public static final String ERROR_CODE_1003 = "1003";
	
	//系统异常
	public static final String ERROR_CODE_1004 = "1004";
	
	//鉴权异常
	public static final String ERROR_CODE_1005 = "1005";
	
	//用户名/密码错误
	public static final String ERROR_CODE_1006 = "1006";
	
	//accessToken非法或已过期
	public static final String ERROR_CODE_1007 = "1007";
	
	//用户被锁定
	public static final String ERROR_CODE_1008 = "1008";
	
	//请求协议格式不正确
	public static final String ERROR_CODE_1009 = "1009";
	
	
	public String code; // required
	public String desc; // required
	public Map<String, Object> resMap; // required
	public List<Map<String, Object>> resList; // required
	public Object data;

	public int getResMapSize() {
		return (this.resMap == null) ? 0 : this.resMap.size();
	}

	public void putToResMap(String key, Object val) {
		if (this.resMap == null) {
			this.resMap = new HashMap<String, Object>();
		}
		this.resMap.put(key, val);
	}

	public void setResMap(Map<String, Object> resMap) {
		this.resMap = resMap;
	}

	public Map<String, Object> getResMap() {
		return this.resMap;
	}

	public String getDesc() {
		return this.desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public void clear() {
		this.code = null;
		this.desc = null;
		this.resMap = null;
		this.resList = null;
	}

	public String getCode() {
		return this.code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public void addToResList(Map<String, Object> elem) {
		if (this.resList == null) {
			this.resList = new ArrayList<Map<String, Object>>();
		}
		this.resList.add(elem);
	}

	public List<Map<String, Object>> getResList() {
		return this.resList;
	}

	public void setResList(List<Map<String, Object>> resList) {
		this.resList = resList;
	}
	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}
	public String toString(){
		return "{code:"+code+", desc:"+desc+ "}";
	}
	
	@Override    
	public ResponseObject clone() throws CloneNotSupportedException{    
	    return (ResponseObject) super.clone();    
	} 
}
