package com.cornu.h5.service.user;

import com.cornu.h5.dao.bean.UserBean;
import com.cornu.h5.exception.ServiceException;

public interface IUserService {
	public UserBean queryUser(UserBean userBean) throws ServiceException;
}
