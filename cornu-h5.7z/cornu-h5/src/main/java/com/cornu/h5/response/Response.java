
package com.cornu.h5.response;

import java.io.Serializable;

import com.alibaba.fastjson.annotation.JSONField;

public class Response implements Serializable {

	private static final long serialVersionUID = 1L;

	@JSONField(name="responseKey")
	private String responseKey;
	
	@JSONField(name = "responseBody")
	private Object responseBody;

	@JSONField(name = "result_code")
	private String resultCode;

	@JSONField(name = "result_msg")
	private String resultMsg;

	public String getResponseKey() {
		return responseKey;
	}

	public void setResponseKey(String responseKey) {
		this.responseKey = responseKey;
	}

	public Object getResponseBody() {
		return responseBody;
	}

	public void setResponseBody(Object responseBody) {
		this.responseBody = responseBody;
	}

	public String getResultCode() {
		return resultCode;
	}

	public void setResultCode(String resultCode) {
		this.resultCode = resultCode;
	}

	public String getResultMsg() {
		return resultMsg;
	}

	public void setResultMsg(String resultMsg) {
		this.resultMsg = resultMsg;
	}

}
