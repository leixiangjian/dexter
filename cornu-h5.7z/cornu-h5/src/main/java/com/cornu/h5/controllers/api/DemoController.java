package com.cornu.h5.controllers.api;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cornu.h5.annotation.NoPassAuth;
import com.cornu.h5.annotation.WriteLog;
import com.cornu.h5.annotation.WriteLog.WriteType;
import com.cornu.h5.controllers.BaseController;
import com.cornu.h5.request.DemoRequest;
import com.cornu.h5.response.DemoResponse;

@Controller
@RequestMapping({ "/demo" })
public class DemoController extends BaseController {
//	private static final Logger LOG = LoggerFactory.getLogger(DemoController.class);

	@RequestMapping("/test")
	@NoPassAuth
	@WriteLog(funcationType = WriteType.QUERY, funcation = "测试", desc = "测试")
	public DemoResponse test(DemoRequest request)
	{
		DemoResponse DemoResponse = new DemoResponse();
		return DemoResponse;
	}
}
