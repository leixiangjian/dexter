package com.cornu.h5.interceptor.chains;

import javax.servlet.http.Cookie;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.method.HandlerMethod;

import com.cornu.h5.annotation.NoPassAuth;

public abstract class AbstractInterceptorChain implements InterceptorChain {
	private static final Logger LOG = LoggerFactory.getLogger(AbstractInterceptorChain.class);

	public String getParameterFromCookies(Cookie[] cookies, String key) {
		if (StringUtils.isNotEmpty(key) && cookies != null) {
			for (Cookie cookie : cookies) {
				if (key.equals(cookie.getName())) {
					return cookie.getValue();
				}
			}
		}
		return null;
	}


	protected boolean isPassAuth(HandlerMethod method,String r_method) {
		NoPassAuth pass = method.getMethodAnnotation(NoPassAuth.class);
		if (null != pass) {
			if (LOG.isInfoEnabled()) {
				LOG.info("method:{},允许无需通过鉴权", method.getMethod().getName());
			}
			return true;
		}

		return false;
	}
}
