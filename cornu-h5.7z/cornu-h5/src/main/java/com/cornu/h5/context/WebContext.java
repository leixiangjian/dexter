package com.cornu.h5.context;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSONObject;

public class WebContext {
	private static final Logger LOG = LoggerFactory.getLogger(WebContext.class);

	private HttpServletRequest request;
	private HttpServletResponse response;
	private JSONObject requestBody;
	
	private JSONObject rHead;
	private JSONObject rBody;
	
	private long requestTime;
	private String userCd;

	public HttpServletRequest getRequest() {
		return request;
	}

	public void setRequest(HttpServletRequest request) {
		this.request = request;
	}

	public HttpServletResponse getResponse() {
		return response;
	}

	public void setResponse(HttpServletResponse response) {
		this.response = response;
	}
	
	public JSONObject getRequestBody() {
		return requestBody;
	}

	public void setRequestBody(JSONObject requestBody) {
		this.requestBody = requestBody;
	}

	public void setrHead(JSONObject rHead) {
		this.rHead = rHead;
	}
	
	public String getHeadValue(String key) {
		if (this.rHead == null || this.rHead.get(key) == null) {
			return null;
		}
		return this.rHead.get(key).toString();
	}
	
	public JSONObject getrBody() {
		return rBody;
	}

	public void setrBody(JSONObject rBody) {
		this.rBody = rBody;
	}

	public void setRequestTime(long requestTime){
		this.requestTime = requestTime;
	}

	public long getRequestTime() {
		return this.requestTime;
	}

	public String getRequestIP() {
		if (LOG.isDebugEnabled()) {
			LOG.debug("request.getRemoteAddr={}, x-forwarded-for={}, Proxy-Client-IP={}, WL-Proxy-Client-IP={}",
					request.getRemoteAddr(), request.getHeader("x-forwarded-for"), request.getHeader("Proxy-Client-IP"),
					request.getHeader("WL-Proxy-Client-IP"));
		}

		String requestIP = request.getHeader("x-forwarded-for");
		if (requestIP == null || requestIP.length() == 0 || "unknown".equalsIgnoreCase(requestIP)) {
			requestIP = request.getHeader("Proxy-Client-IP");
		}
		if (requestIP == null || requestIP.length() == 0 || "unknown".equalsIgnoreCase(requestIP)) {
			requestIP = request.getHeader("WL-Proxy-Client-IP");
		}
		if (requestIP == null || requestIP.length() == 0 || "unknown".equalsIgnoreCase(requestIP)) {
			requestIP = request.getRemoteAddr();
		}
		if (requestIP != null && requestIP.length() > 15) {
			if (requestIP.indexOf(",") > 0) {
				requestIP = requestIP.substring(0, requestIP.indexOf(","));
			}
		}
		return requestIP;
	}

	public String getUserCd() {
		return userCd;
	}

	public void setUserCd(String userCd) {
		this.userCd = userCd;
	}
	
}
