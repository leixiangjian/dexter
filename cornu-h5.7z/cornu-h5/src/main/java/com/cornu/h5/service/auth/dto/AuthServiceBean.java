package com.cornu.h5.service.auth.dto;

public class AuthServiceBean implements java.io.Serializable {
	private static final long serialVersionUID = -54039565193233067L;
	private String authToken;
	private String accessToken;
	private String userName;
	private String pwd;

	public String getAuthToken() {
		return authToken;
	}

	public void setAuthToken(String authToken) {
		this.authToken = authToken;
	}

	public String getAccessToken() {
		return accessToken;
	}

	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

}
