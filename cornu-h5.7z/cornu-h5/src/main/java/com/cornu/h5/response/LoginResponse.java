package com.cornu.h5.response;

public class LoginResponse extends Response{
	private static final long serialVersionUID = 3660301586612925829L;

}
