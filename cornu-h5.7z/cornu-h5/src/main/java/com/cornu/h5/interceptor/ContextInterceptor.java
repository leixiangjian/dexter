package com.cornu.h5.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cornu.h5.context.WebContextThreadLocal;

public class ContextInterceptor extends BaseInterceptor {

	private static final Logger LOG = LoggerFactory.getLogger(ContextInterceptor.class);

	@Override
	public void afterCompletion(HttpServletRequest request,
			HttpServletResponse response, Object obj, Exception exception)
			throws Exception {
		try {
			super.afterCompletion(request, response, obj, exception);
		} catch (Exception e) {
			LOG.error(e.getMessage(),e);
		}finally{
			WebContextThreadLocal.remove();
		}
	}
	
	@Override
	public boolean preHandle(HttpServletRequest req, HttpServletResponse res, Object arg2) throws Exception {
		return true;
	}
	
}
