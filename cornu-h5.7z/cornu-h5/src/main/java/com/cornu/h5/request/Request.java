
package com.cornu.h5.request;

import java.io.Serializable;

import com.cornu.h5.validators.IValidator;

public abstract class Request implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private String r_method;

	public String getR_method() {
		return r_method;
	}

	public void setR_method(String r_method) {
		this.r_method = r_method;
	}

	public abstract ValidateRes validator();
	
	public abstract Class<IValidator> getValidatorType();

	public class ValidateRes implements Serializable{
		private static final long serialVersionUID = 1L;
		public static final String SUCCESS = "SUCCESS";
		public static final String ERROR = "ERROR";
		
		private String res_code;
		private String res_msg;

		public String getRes_code() {
			return res_code;
		}

		public void setRes_code(String res_code) {
			this.res_code = res_code;
		}

		public String getRes_msg() {
			return res_msg;
		}

		public void setRes_msg(String res_msg) {
			this.res_msg = res_msg;
		}

	}

}
